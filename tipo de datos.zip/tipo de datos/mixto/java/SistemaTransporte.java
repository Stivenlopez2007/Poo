package sistema_transporte;

import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Date;

// =================================================================
// 1. INTERFACES (5 Ejemplos)
// =================================================================

interface IFuncionalidad {
    void encender();
    void apagar();
}

interface IMecanica {
    void reparar();
    void diagnosticar();
}

interface ICertificacion {
    void validarLicencia();
    void registrarHoras();
}

interface ILegal {
    void renovar();
    void expirar();
}

interface IInfraestructura {
    void abrirTaller();
    void cerrarTaller();
}

// =================================================================
// 2. CLASES ABSTRACTAS (5 Ejemplos con 4 Constructores Reutilizados)
// =================================================================

abstract class VehiculoBase {
    protected String idVehiculo;

    // 1. Default: Llama al constructor con parámetros
    public VehiculoBase() {
        this("VEH-GENERICO");
    }

    // 2. Con Parámetro (Principal)
    public VehiculoBase(String id) {
        this.idVehiculo = id;
    }

    // 3. Sobrecargado: En este caso, redirige al principal
    public VehiculoBase(String id, int codigoArea) {
        this(id + "-" + codigoArea);
    }

    // 4. Copia: Llama al principal usando los datos del otro objeto
    public VehiculoBase(VehiculoBase otro) {
        this(otro.idVehiculo);
    }

    public abstract void mostrarInfoBase();
}

abstract class ComponenteBase {
    protected String numeroSerie;

    public ComponenteBase() {
        this("SN-0000");
    }
    public ComponenteBase(String serial) {
        this.numeroSerie = serial;
    }
    public ComponenteBase(String serial, String lote) {
        this(serial + "-" + lote);
    }
    public ComponenteBase(ComponenteBase otro) {
        this(otro.numeroSerie);
    }
    public abstract void mostrarEstado();
}

abstract class PersonaBase {
    protected String nombreCompleto;

    public PersonaBase() {
        this("Sin Nombre");
    }
    public PersonaBase(String nombre) {
        this.nombreCompleto = nombre;
    }
    public PersonaBase(String nombre, String apellido) {
        this(nombre + " " + apellido);
    }
    public PersonaBase(PersonaBase otro) {
        this(otro.nombreCompleto);
    }
    public abstract void presentar();
}

abstract class DocumentoBase {
    protected String codigoDocumento;

    public DocumentoBase() {
        this("DOC-NULL");
    }
    public DocumentoBase(String codigo) {
        this.codigoDocumento = codigo;
    }
    public DocumentoBase(int numero) {
        this("DOC-" + numero);
    }
    public DocumentoBase(DocumentoBase otro) {
        this(otro.codigoDocumento);
    }
    public abstract void imprimir();
}

abstract class LugarBase {
    protected String direccion;

    public LugarBase() {
        this("Dirección desconocida");
    }
    public LugarBase(String dir) {
        this.direccion = dir;
    }
    public LugarBase(String calle, int numero) {
        this(calle + " #" + numero);
    }
    public LugarBase(LugarBase otro) {
        this(otro.direccion);
    }
    public abstract void describirLugar();
}

// =================================================================
// 3. CLASES NORMALES (5 Ejemplos con Constructores Encadenados)
// =================================================================

// CLASE 1: Carro (Refactorizada según tus requerimientos y campos)
class Carro extends VehiculoBase implements IFuncionalidad {
    // --- 5 PUBLICOS ---
    public String marca;
    public String modelo;
    public double precio;
    public int puertas;
    public boolean disponible;

    // --- 5 PRIVADOS ---
    private String color;
    private boolean encendido;
    private char tipoCombustible;
    private byte[] codigoBinario;
    private Map<String, Object> datosTecnicos;

    // --- 5 PROTECTED ---
    protected String tipoTransmision;
    protected int anioFabricacion;
    protected double kilometraje;
    protected boolean enMantenimiento;
    protected String paisOrigen;

    // --- MÉTODOS DE APOYO PARA INICIALIZACIÓN ---
    private void inicializarPrivados() {
        this.color = "Blanco";
        this.encendido = false;
        this.tipoCombustible = 'G'; // Gasolina
        this.codigoBinario = new byte[]{0, 1, 0, 1};
        this.datosTecnicos = new HashMap<>();
        this.datosTecnicos.put("motor", "2.0L");
        
        this.tipoTransmision = "Manual";
        this.anioFabricacion = 2024;
        this.kilometraje = 0.0;
        this.enMantenimiento = false;
        this.paisOrigen = "Japón";
    }

    // --- 4 CONSTRUCTORES CON REUTILIZACIÓN (this) ---

    // 1. Constructor Full (Principal): Inicializa todo
    public Carro(String marca, String modelo, double precio, int puertas, boolean disponible) {
        super("CAR-" + marca.toUpperCase()); // Llama al constructor base
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.puertas = puertas;
        this.disponible = disponible;
        inicializarPrivados(); // Lógica común
    }

    // 2. Constructor Simple: Llama al Full con valores por defecto
    public Carro(String marca, String modelo) {
        this(marca, modelo, 0.0, 4, true);
    }

    // 3. Constructor Default: Llama al Simple
    public Carro() {
        this("Marca Genérica", "Modelo Base");
    }

    // 4. Constructor Copia: Llama al Full extrayendo datos del objeto original
    public Carro(Carro otro) {
        this(otro.marca, otro.modelo, otro.precio, otro.puertas, otro.disponible);
        // Copia profunda o específica de campos privados si es necesario
        this.color = otro.getColor();
        this.anioFabricacion = otro.anioFabricacion;
    }

    // --- Getters y Setters necesarios ---
    public String getColor() { return color; }

    // --- Implementación de Interfaces y Abstractos ---
    @Override
    public void encender() {
        this.encendido = true;
        System.out.println("El carro " + marca + " está encendido.");
    }

    @Override
    public void apagar() {
        this.encendido = false;
        System.out.println("El carro " + marca + " está apagado.");
    }

    @Override
    public void mostrarInfoBase() {
        System.out.println("Vehículo ID: " + idVehiculo + " | Modelo: " + modelo);
    }
}

// CLASE 2: Motor (Componente)
class Motor extends ComponenteBase implements IMecanica {
    public int caballosFuerza;
    public String tipo;
    
    private boolean funcional;

    private void init() { this.funcional = true; }

    // 3. Full
    public Motor(String serial, int hp, String tipo) {
        super(serial);
        this.caballosFuerza = hp;
        this.tipo = tipo;
        init();
    }
    // 2. Simple
    public Motor(String serial) {
        this(serial, 100, "V4");
    }
    // 1. Default
    public Motor() {
        this("SN-UNKNOWN", 0, "Generico");
    }
    // 4. Copia
    public Motor(Motor otro) {
        this(otro.numeroSerie, otro.caballosFuerza, otro.tipo);
    }

    @Override
    public void reparar() {
        System.out.println("Reparando motor " + numeroSerie);
        this.funcional = true;
    }
    @Override
    public void diagnosticar() {
        System.out.println("Diagnóstico motor: " + (funcional ? "OK" : "FALLA"));
    }
    @Override
    public void mostrarEstado() {
        System.out.println("Motor " + tipo + " (" + caballosFuerza + "HP)");
    }
}

// CLASE 3: Mecanico (Persona)
class Mecanico extends PersonaBase implements ICertificacion {
    public String especialidad;
    public int añosExperiencia;

    // 3. Full
    public Mecanico(String nombre, String especialidad, int exp) {
        super(nombre);
        this.especialidad = especialidad;
        this.añosExperiencia = exp;
    }
    // 2. Simple
    public Mecanico(String nombre) {
        this(nombre, "General", 0);
    }
    // 1. Default
    public Mecanico() {
        this("Aprendiz", "Ayudante", 0);
    }
    // 4. Copia
    public Mecanico(Mecanico otro) {
        this(otro.nombreCompleto, otro.especialidad, otro.añosExperiencia);
    }

    @Override
    public void validarLicencia() {
        System.out.println("Licencia de " + nombreCompleto + " validada.");
    }
    @Override
    public void registrarHoras() {
        System.out.println("Horas registradas para " + nombreCompleto);
    }
    @Override
    public void presentar() {
        System.out.println("Soy " + nombreCompleto + ", mecánico de " + especialidad);
    }
}

// CLASE 4: Seguro (Documento)
class Seguro extends DocumentoBase implements ILegal {
    public String aseguradora;
    public double cobertura;

    // 3. Full
    public Seguro(String codigo, String empresa, double monto) {
        super(codigo);
        this.aseguradora = empresa;
        this.cobertura = monto;
    }
    // 2. Simple
    public Seguro(String codigo) {
        this(codigo, "Estatal", 5000.0);
    }
    // 1. Default
    public Seguro() {
        this("SEG-000", "Sin Aseguradora", 0.0);
    }
    // 4. Copia
    public Seguro(Seguro otro) {
        this(otro.codigoDocumento, otro.aseguradora, otro.cobertura);
    }

    @Override
    public void renovar() {
        System.out.println("Póliza " + codigoDocumento + " renovada.");
    }
    @Override
    public void expirar() {
        System.out.println("Póliza " + codigoDocumento + " ha expirado.");
    }
    @Override
    public void imprimir() {
        System.out.println("Seguro: " + aseguradora + " | Cobertura: $" + cobertura);
    }
}

// CLASE 5: Taller (Lugar)
class Taller extends LugarBase implements IInfraestructura {
    public String nombreTaller;
    public int capacidadAutos;

    // 3. Full
    public Taller(String nombre, String direccion, int capacidad) {
        super(direccion);
        this.nombreTaller = nombre;
        this.capacidadAutos = capacidad;
    }
    // 2. Simple
    public Taller(String nombre) {
        this(nombre, "Zona Industrial", 10);
    }
    // 1. Default
    public Taller() {
        this("Taller Genérico", "Sin dirección", 1);
    }
    // 4. Copia
    public Taller(Taller otro) {
        this(otro.nombreTaller, otro.direccion, otro.capacidadAutos);
    }

    @Override
    public void abrirTaller() {
        System.out.println("Taller " + nombreTaller + " abierto.");
    }
    @Override
    public void cerrarTaller() {
        System.out.println("Taller " + nombreTaller + " cerrado.");
    }
    @Override
    public void describirLugar() {
        System.out.println("Taller: " + nombreTaller + " en " + direccion);
    }
}

// =================================================================
// MAIN CLASS
// =================================================================

public class SistemaTransporte {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE TRANSPORTE EN JAVA ===");

        System.out.println("\n--- 1. PRUEBA CARRO (Reutilización de constructores) ---");
        Carro c1 = new Carro(); // Default
        Carro c2 = new Carro("Mazda", "3"); // Simple
        Carro c3 = new Carro("Ford", "Mustang", 50000, 2, true); // Full
        Carro c4 = new Carro(c3); // Copia

        c3.encender();
        c3.mostrarInfoBase();
        c4.apagar(); // La copia funciona independiente

        System.out.println("\n--- 2. PRUEBA MOTOR ---");
        Motor m1 = new Motor("V8-Turbo", 450, "Deportivo");
        m1.mostrarEstado();
        m1.diagnosticar();

        System.out.println("\n--- 3. PRUEBA MECÁNICO ---");
        Mecanico mec = new Mecanico("Luis", "Frenos", 10);
        mec.presentar();
        mec.validarLicencia();

        System.out.println("\n--- 4. PRUEBA SEGURO ---");
        Seguro seg = new Seguro("POL-12345", "Mapfre", 20000);
        seg.imprimir();
        seg.renovar();

        System.out.println("\n--- 5. PRUEBA TALLER ---");
        Taller t = new Taller("Los Santos Customs");
        t.describirLugar();
        t.abrirTaller();
    }
}