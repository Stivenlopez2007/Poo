package sistema_medico;

import java.util.Map;
import java.util.HashMap;
import java.util.Date;
import java.util.Arrays;

// =================================================================
// 1. INTERFACES (Contratos)
// =================================================================

interface IMonitoreo {
    void registrarSignosVitales();
    void calcularProgreso();
}

interface IGestionMedica {
    void asignarPaciente();
    void darAlta();
}

interface IDiagnostico {
    void analizarResultados();
    void emitirDictamen();
}

interface IInfraestructura {
    void habilitarSala();
    void realizarMantenimiento();
}

interface IReporte {
    void generarInforme();
    void archivarHistorial();
}

// =================================================================
// 2. CLASES ABSTRACTAS (5 Ejemplos con Encadenamiento this(...) estricto)
// =================================================================

// Clase Base 1: Registro
abstract class RegistroMedicoBase {
    protected String codigoRegistro;

    // 1. Default -> Delega a C2
    public RegistroMedicoBase() { this("REG-GENERICO"); }

    // 3. Sobrecargado -> Delega a C2
    public RegistroMedicoBase(String prefijo, int correlativo) { this(prefijo + "-" + correlativo); }

    // 4. Copia -> Delega a C2
    public RegistroMedicoBase(RegistroMedicoBase otro) { this(otro.codigoRegistro); }

    // 2. Principal (Lógica de asignación centralizada)
    public RegistroMedicoBase(String codigo) {
        this.codigoRegistro = codigo;
    }
    public abstract void mostrarInfoRegistro();
}

// Clase Base 2: Persona
abstract class PersonaBase {
    protected String documentoIdentidad;

    public PersonaBase() { this("SIN-DOC"); }
    public PersonaBase(String tipo, String numero) { this(tipo + "-" + numero); }
    public PersonaBase(PersonaBase otro) { this(otro.documentoIdentidad); }

    // Principal
    public PersonaBase(String doc) {
        this.documentoIdentidad = doc;
    }
    public abstract void presentarse();
}

// Clase Base 3: Estudio
abstract class EstudioBase {
    protected String tipoEstudio;

    public EstudioBase() { this("General"); }
    public EstudioBase(String area, String especificidad) { this(area + ": " + especificidad); }
    public EstudioBase(EstudioBase otro) { this(otro.tipoEstudio); }

    // Principal
    public EstudioBase(String tipo) {
        this.tipoEstudio = tipo;
    }
    public abstract void describirEstudio();
}

// Clase Base 4: Lugar
abstract class LugarBase {
    protected String nombreLugar;

    public LugarBase() { this("Lugar Desconocido"); }
    public LugarBase(String ciudad, String sede) { this(ciudad + " - " + sede); }
    public LugarBase(LugarBase otro) { this(otro.nombreLugar); }

    // Principal
    public LugarBase(String nombre) {
        this.nombreLugar = nombre;
    }
    public abstract void mostrarUbicacion();
}

// Clase Base 5: Tratamiento
abstract class TratamientoBase {
    protected String nombreMedicamento;

    public TratamientoBase() { this("Placebo"); }
    public TratamientoBase(String nombre, int dosisMg) { this(nombre + " " + dosisMg + "mg"); }
    public TratamientoBase(TratamientoBase otro) { this(otro.nombreMedicamento); }

    // Principal
    public TratamientoBase(String nombre) {
        this.nombreMedicamento = nombre;
    }
    public abstract void aplicar();
}

// =================================================================
// 3. CLASES NORMALES (5 Ejemplos con Encadenamiento estricto a Constructor Principal)
// =================================================================

// CLASE 1: ControlEmbarazo
class ControlEmbarazo extends RegistroMedicoBase implements IMonitoreo {

    // --- 5 PUBLICOS ---
    public String nombreMadre;
    public int edadMadre;
    public double pesoActual;
    public int semanasGestacion;
    public boolean riesgoAlto;

    // --- 5 PRIVADOS ---
    private String tipoSangre;
    private boolean vitaminasTomadas;
    private double presionArterial;
    private byte[] ecografiaBinaria;
    private Map<String, Object> historialClinico;

    // --- 5 PROTECTED ---
    protected String medicoEncargado;
    protected String hospitalReferencia;
    protected boolean seguimientoActivo;
    protected int controlesRealizados;
    protected double nivelHemoglobina;

    // --- Método auxiliar de inicialización (Se llama SOLO desde el constructor Principal) ---
    private void inicializarPrivados() {
        // Inicialización de campos de estado internos y protegidos por defecto
        this.tipoSangre = "O+";
        this.vitaminasTomadas = false;
        this.presionArterial = 120.80;
        this.ecografiaBinaria = new byte[0];
        this.historialClinico = new HashMap<>();

        this.medicoEncargado = "Dr. Turno";
        this.hospitalReferencia = "Central";
        this.seguimientoActivo = true;
        this.controlesRealizados = 0;
        this.nivelHemoglobina = 12.5;
    }

    // --- 4 CONSTRUCTORES ---

    // 3. Default -> Delega a C2
    public ControlEmbarazo() {
        this("Madre Anónima", 0);
    }

    // 2. Simple -> Delega a C1 (Principal)
    public ControlEmbarazo(String nombreMadre, int edadMadre) {
        this(nombreMadre, edadMadre, 60.0, 1, false);
    }

    // 4. Copia -> Delega a C1 (Principal) y luego ajusta el estado copiado
    public ControlEmbarazo(ControlEmbarazo otro) {
        // 1. Delega al Principal para establecer valores base y llamar a inicializarPrivados
        this(otro.nombreMadre, otro.edadMadre, otro.pesoActual, otro.semanasGestacion, otro.riesgoAlto);
        // 2. Copia de campos de estado que deberían persistir (sobrescribiendo los defaults de inicializarPrivados)
        this.controlesRealizados = otro.controlesRealizados;
        this.nivelHemoglobina = otro.nivelHemoglobina;
        this.presionArterial = otro.presionArterial;
        this.tipoSangre = otro.tipoSangre; // Ejemplo de copia de privado
    }

    // 1. Full (Principal): Único lugar donde se llama a super() y inicializarPrivados()
    public ControlEmbarazo(String nombreMadre, int edadMadre, double pesoActual, int semanasGestacion, boolean riesgoAlto) {
        super("CTRL-" + nombreMadre.toUpperCase().replace(" ", "")); // Llama a constructor base
        this.nombreMadre = nombreMadre;
        this.edadMadre = edadMadre;
        this.pesoActual = pesoActual;
        this.semanasGestacion = semanasGestacion;
        this.riesgoAlto = riesgoAlto;
        inicializarPrivados(); // ÚNICA llamada a la inicialización de estado
    }


    // --- Métodos propios ---
    public void registrarControl(double nuevoPeso, double presion, double hemoglobina) {
        this.pesoActual = nuevoPeso;
        this.presionArterial = presion;
        this.nivelHemoglobina = hemoglobina;
        this.controlesRealizados++;
        System.out.println("Control registrado. Total: " + controlesRealizados);
    }

    public void evaluarRiesgo() {
        if (presionArterial > 140 || nivelHemoglobina < 11) {
            riesgoAlto = true;
            System.out.println("RIESGO ALTO DETECTADO.");
        } else {
            riesgoAlto = false;
            System.out.println(" Estado estable.");
        }
    }

    public void mostrarResumen() {
        System.out.println("\n----- Resumen del Control de Embarazo -----");
        System.out.println("Registro: " + codigoRegistro);
        System.out.println("Madre: " + nombreMadre + " (Edad: " + edadMadre + ")");
        System.out.println("Semanas: " + semanasGestacion + " | Peso: " + pesoActual + "kg");
        System.out.println("Riesgo Alto: " + (riesgoAlto ? "SÍ" : "NO"));
        System.out.println("Presión Arterial: " + presionArterial + " | Hemoglobina: " + nivelHemoglobina);
    }

    // --- Implementación de Interfaces/Abstractos ---
    @Override
    public void mostrarInfoRegistro() {
        System.out.println("Expediente prenatal: " + codigoRegistro);
    }

    @Override
    public void registrarSignosVitales() {
        System.out.println("Registrando signos vitales de la madre...");
    }

    @Override
    public void calcularProgreso() {
        System.out.println("Progreso del embarazo: " + (semanasGestacion / 40.0 * 100) + "%");
    }
}

// CLASE 2: Obstetra
class Obstetra extends PersonaBase implements IGestionMedica {
    public String especialidad;
    public int guardiaSemanal;

    // 1. Default -> Delega a C2
    public Obstetra() {
        this("MED-000");
    }
    // 2. Simple -> Delega a C3 (Principal)
    public Obstetra(String doc) {
        this(doc, "Obstetricia General", 24);
    }
    // 4. Copia -> Delega a C3 (Principal)
    public Obstetra(Obstetra otro) {
        this(otro.documentoIdentidad, otro.especialidad, otro.guardiaSemanal);
    }
    // 3. Full (Principal)
    public Obstetra(String doc, String especialidad, int horas) {
        super(doc);
        this.especialidad = especialidad;
        this.guardiaSemanal = horas;
    }

    @Override
    public void presentarse() {
        System.out.println("Soy el especialista en " + especialidad + " | Documento: " + documentoIdentidad);
    }
    @Override
    public void asignarPaciente() {
        System.out.println("Paciente asignada al doctor.");
    }
    @Override
    public void darAlta() {
        System.out.println("Alta médica firmada.");
    }
}

// CLASE 3: Ecografia
class Ecografia extends EstudioBase implements IDiagnostico {
    public int semanasEstimadas;
    public boolean morfologiaNormal;

    // 1. Default -> Delega a C2
    public Ecografia() {
        this("Ecografía Standard");
    }
    // 2. Simple -> Delega a C3 (Principal)
    public Ecografia(String tipo) {
        this(tipo, 0, true);
    }
    // 4. Copia -> Delega a C3 (Principal)
    public Ecografia(Ecografia otra) {
        this(otra.tipoEstudio, otra.semanasEstimadas, otra.morfologiaNormal);
    }
    // 3. Full (Principal)
    public Ecografia(String tipo, int semanas, boolean normal) {
        super(tipo);
        this.semanasEstimadas = semanas;
        this.morfologiaNormal = normal;
    }

    @Override
    public void describirEstudio() {
        System.out.println("Estudio: " + tipoEstudio + " (" + semanasEstimadas + " semanas)");
    }
    @Override
    public void analizarResultado( ) {
        System.out.println("Analizando imágenes ecográficas...");
    }
    @Override
    public void emitirDictamen() {
        System.out.println("Dictamen: " + (morfologiaNormal ? "Normal" : "Observación requerida"));
    }
}

// CLASE 4: ClinicaMaternidad
class ClinicaMaternidad extends LugarBase implements IInfraestructura {
    public int camasDisponibles;
    public boolean tieneNeonatologia;

    // 1. Default -> Delega a C2
    public ClinicaMaternidad() {
        this("Clínica General");
    }
    // 2. Simple -> Delega a C3 (Principal)
    public ClinicaMaternidad(String nombre) {
        this(nombre, 50, true);
    }
    // 4. Copia -> Delega a C3 (Principal)
    public ClinicaMaternidad(ClinicaMaternidad otra) {
        this(otra.nombreLugar, otra.camasDisponibles, otra.tieneNeonatologia);
    }
    // 3. Full (Principal)
    public ClinicaMaternidad(String nombre, int camas, boolean neo) {
        super(nombre);
        this.camasDisponibles = camas;
        this.tieneNeonatologia = neo;
    }

    @Override
    public void mostrarUbicacion() {
        System.out.println("Clínica: " + nombreLugar + " [Neo: " + (tieneNeonatologia?"Sí":"No") + "]");
    }
    @Override
    public void habilitarSala() {
        System.out.println("Sala de partos habilitada.");
    }
    @Override
    public void realizarMantenimiento() {
        System.out.println("Mantenimiento de incubadoras en curso.");
    }
}

// CLASE 5: Suplemento (Tratamiento)
class Suplemento extends TratamientoBase implements IReporte {
    public String compuesto;

    // 1. Default -> Delega a C2
    public Suplemento() {
        this("Ácido Fólico");
    }
    // 2. Simple -> Delega a C3 (Principal)
    public Suplemento(String nombre) {
        this(nombre, "Multivitamínico");
    }
    // 4. Copia -> Delega a C3 (Principal)
    public Suplemento(Suplemento otro) {
        this(otro.nombreMedicamento, otro.compuesto);
    }
    // 3. Full (Principal)
    public Suplemento(String nombre, String compuesto) {
        super(nombre);
        this.compuesto = compuesto;
    }

    @Override
    public void aplicar() {
        System.out.println("Tomar " + nombreMedicamento + " (" + compuesto + ") diariamente.");
    }
    @Override
    public void generarInforme() {
        System.out.println("Informe de adherencia al tratamiento generado.");
    }
    @Override
    public void archivarHistorial() {
        System.out.println("Receta archivada.");
    }
}

// =================================================================
// MAIN CLASS
// =================================================================

public class SistemaControlEmbarazo {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE CONTROL DE EMBARAZO (Constructores Optimizados) ===");

        System.out.println("\n--- 1. PRUEBA CONTROL EMBARAZO ---");
        // 1. Constructor Full (Principal)
        ControlEmbarazo madre1 = new ControlEmbarazo("Laura Gomez", 28, 65.5, 20, false);

        // 2. Constructor Simple
        ControlEmbarazo madre2 = new ControlEmbarazo("Andrea Pérez", 35);

        madre1.registrarControl(66.2, 110.70, 12.0); // Todo normal
        madre1.mostrarResumen();
        madre2.mostrarResumen();

        System.out.println("\n--- Prueba Constructor Copia ---");
        ControlEmbarazo madreCopia = new ControlEmbarazo(madre1);
        madreCopia.registrarControl(67.0, 150.90, 10.5); // Simula alteración en la copia
        madreCopia.evaluarRiesgo(); // Debería dar ALTO RIESGO
        madreCopia.mostrarResumen();

        System.out.println("\n--- 2. PRUEBA OBSTETRA ---");
        Obstetra doc = new Obstetra("DOC-9988", "Embarazo de Alto Riesgo", 36);
        Obstetra docDefault = new Obstetra(); // Default -> Simple -> Principal
        doc.presentarse();
        docDefault.presentarse();

        System.out.println("\n--- 3. PRUEBA ECOGRAFÍA ---");
        Ecografia eco = new Ecografia("Doppler", 20, true);
        eco.describirEstudio();

        System.out.println("\n--- 4. PRUEBA CLÍNICA ---");
        ClinicaMaternidad clinica = new ClinicaMaternidad("Maternidad Santa Rosa", 100, true);
        clinica.mostrarUbicacion();

        System.out.println("\n--- 5. PRUEBA SUPLEMENTO ---");
        Suplemento hierro = new Suplemento("Hierro Plus", "Sulfato Ferroso");
        hierro.aplicar();
    }
}