package sistema_motor;

import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Date;

// =================================================================
// 1. INTERFACES (5 Ejemplos)
// =================================================================

interface IFuncionamiento {
    void encender();
    void apagar();
}

interface IDiagnostico {
    void escanearCodigo();
    void reportarEstado();
}

interface IMantenimiento {
    void realizarCambioAceite();
    void verificarDesgaste();
}

interface IPerformance {
    void medirRevoluciones();
    void calcularConsumo();
}

interface IFabricacion {
    void asignarLote();
    void controlCalidad();
}

// =================================================================
// 2. CLASES ABSTRACTAS (5 Ejemplos con 4 Constructores Reutilizados)
// =================================================================

// Clase Base 1: ComponenteMecanicoBase
abstract class ComponenteMecanicoBase {
    protected String idComponente;

    // 1. Default
    public ComponenteMecanicoBase() {
        this("COMP-UNK");
    }
    // 2. Con Parámetro (Principal)
    public ComponenteMecanicoBase(String id) {
        this.idComponente = id;
    }
    // 3. Sobrecargado
    public ComponenteMecanicoBase(String prefijo, int serie) {
        this(prefijo + "-" + serie);
    }
    // 4. Copia
    public ComponenteMecanicoBase(ComponenteMecanicoBase otro) {
        this(otro.idComponente);
    }
    public abstract void mostrarFichaTecnica();
}

// Clase Base 2: SistemaElectricoBase
abstract class SistemaElectricoBase {
    protected double voltaje;

    public SistemaElectricoBase() { this(12.0); }
    public SistemaElectricoBase(double v) { this.voltaje = v; }
    public SistemaElectricoBase(int celdas, double vPorCelda) { this(celdas * vPorCelda); }
    public SistemaElectricoBase(SistemaElectricoBase otro) { this(otro.voltaje); }
    public abstract void verificarVoltaje();
}

// Clase Base 3: FluidoBase
abstract class FluidoBase {
    protected String tipoFluido;

    public FluidoBase() { this("Aceite Genérico"); }
    public FluidoBase(String tipo) { this.tipoFluido = tipo; }
    public FluidoBase(String marca, String viscosidad) { this(marca + " " + viscosidad); }
    public FluidoBase(FluidoBase otro) { this(otro.tipoFluido); }
    public abstract void medirNivel();
}

// Clase Base 4: SensorBase
abstract class SensorBase {
    protected String ubicacion;

    public SensorBase() { this("Motor"); }
    public SensorBase(String loc) { this.ubicacion = loc; }
    public SensorBase(String zona, int pin) { this(zona + "-PIN" + pin); }
    public SensorBase(SensorBase otro) { this(otro.ubicacion); }
    public abstract void leerDatos();
}

// Clase Base 5: PiezaBase
abstract class PiezaBase {
    protected String material;

    public PiezaBase() { this("Acero"); }
    public PiezaBase(String mat) { this.material = mat; }
    public PiezaBase(String aleacion, int grado) { this(aleacion + "-G" + grado); }
    public PiezaBase(PiezaBase otro) { this(otro.material); }
    public abstract void pruebaResistencia();
}

// =================================================================
// 3. CLASES NORMALES (5 Ejemplos con Constructores Encadenados)
// =================================================================

// CLASE 1: Motor (La clase solicitada, refactorizada)
class Motor extends ComponenteMecanicoBase implements IFuncionamiento {

    // ===== ATRIBUTOS PÚBLICOS =====
    public String tipoMotor;
    public int cilindros;
    public double potenciaHP;
    public boolean enFuncionamiento;
    public String fabricante;

    // ===== ATRIBUTOS PRIVADOS =====
    private double temperatura;
    private boolean aceiteCorrecto;
    private byte[] codigoDiagnostico;
    private Map<String, Object> sensores; // Reemplaza JSONObject
    private String numeroSerie;

    // ===== ATRIBUTOS PROTEGIDOS =====
    protected int revolucionesPorMinuto;
    protected double consumoCombustible;
    protected String tipoCombustible;
    protected boolean necesitaMantenimiento;
    protected String paisFabricacion;

    // --- Método auxiliar de inicialización ---
    private void inicializarPrivados() {
        this.temperatura = 25.0;
        this.aceiteCorrecto = true;
        this.codigoDiagnostico = new byte[]{0, 0, 0, 0};
        this.sensores = new HashMap<>();
        this.sensores.put("estado", "OK");
        this.numeroSerie = "SN-" + System.currentTimeMillis();
        
        this.revolucionesPorMinuto = 0;
        this.consumoCombustible = 8.5;
        this.tipoCombustible = "Gasolina";
        this.necesitaMantenimiento = false;
        this.paisFabricacion = "Alemania";
    }

    // --- 4 CONSTRUCTORES (Reutilización con this) ---

    // 1. Constructor Full (Principal)
    public Motor(String tipoMotor, int cilindros, double potenciaHP, String fabricante, boolean enFuncionamiento) {
        super("MTR-" + tipoMotor); // Llama al constructor base
        this.tipoMotor = tipoMotor;
        this.cilindros = cilindros;
        this.potenciaHP = potenciaHP;
        this.fabricante = fabricante;
        this.enFuncionamiento = enFuncionamiento;
        inicializarPrivados();
    }

    // 2. Constructor Simple (Llama al Full con valores por defecto)
    public Motor(String tipoMotor, int cilindros) {
        this(tipoMotor, cilindros, 150.0, "Genérico", false);
    }

    // 3. Constructor Default (Llama al Simple)
    public Motor() {
        this("V4", 4);
    }

    // 4. Constructor Copia (Llama al Full con datos del original)
    public Motor(Motor otro) {
        this(otro.tipoMotor, otro.cilindros, otro.potenciaHP, otro.fabricante, otro.enFuncionamiento);
        // Copia de campos privados específicos si es necesario
        this.temperatura = otro.getTemperatura();
        this.aceiteCorrecto = otro.isAceiteCorrecto();
    }

    // --- Getters necesarios para la copia ---
    public double getTemperatura() { return temperatura; }
    public boolean isAceiteCorrecto() { return aceiteCorrecto; }

    // --- Métodos de Acción ---
    @Override
    public void encender() {
        if (aceiteCorrecto) {
            enFuncionamiento = true;
            temperatura += 10;
            revolucionesPorMinuto = 800; // Ralentí
            System.out.println("✅ Motor encendido. RPM: " + revolucionesPorMinuto);
        } else {
            System.out.println("❌ Error: Aceite incorrecto.");
        }
    }

    @Override
    public void apagar() {
        enFuncionamiento = false;
        temperatura = 25.0;
        revolucionesPorMinuto = 0;
        System.out.println("🛑 Motor apagado.");
    }

    @Override
    public void mostrarFichaTecnica() {
        System.out.println("\n===== Ficha Motor =====");
        System.out.println("ID Componente: " + idComponente);
        System.out.println("Tipo: " + tipoMotor + " (" + cilindros + " cil)");
        System.out.println("Potencia: " + potenciaHP + " HP | Fabricante: " + fabricante);
        System.out.println("Estado: " + (enFuncionamiento ? "ON" : "OFF") + " | Temp: " + temperatura + "°C");
    }
}

// CLASE 2: Bateria
class Bateria extends SistemaElectricoBase implements IDiagnostico {
    public int capacidadAmperios;
    public boolean cargaCompleta;

    // 3. Full
    public Bateria(double voltaje, int amperios, boolean carga) {
        super(voltaje);
        this.capacidadAmperios = amperios;
        this.cargaCompleta = carga;
    }
    // 2. Simple
    public Bateria(int amperios) {
        this(12.5, amperios, true);
    }
    // 1. Default
    public Bateria() {
        this(60);
    }
    // 4. Copia
    public Bateria(Bateria otra) {
        this(otra.voltaje, otra.capacidadAmperios, otra.cargaCompleta);
    }

    @Override
    public void verificarVoltaje() {
        System.out.println("Voltaje actual: " + voltaje + "V");
    }
    @Override
    public void escanearCodigo() {
        System.out.println("Escaneando estado de celdas de batería...");
    }
    @Override
    public void reportarEstado() {
        System.out.println("Estado de carga: " + (cargaCompleta ? "100%" : "Cargando..."));
    }
}

// CLASE 3: AceiteMotor
class AceiteMotor extends FluidoBase implements IMantenimiento {
    public int vidaUtilKm;
    public boolean sintetico;

    // 3. Full
    public AceiteMotor(String tipo, int vida, boolean esSintetico) {
        super(tipo);
        this.vidaUtilKm = vida;
        this.sintetico = esSintetico;
    }
    // 2. Simple
    public AceiteMotor(String viscosidad) {
        this("Aceite " + viscosidad, 10000, true);
    }
    // 1. Default
    public AceiteMotor() {
        this("10W-30");
    }
    // 4. Copia
    public AceiteMotor(AceiteMotor otro) {
        this(otro.tipoFluido, otro.vidaUtilKm, otro.sintetico);
    }

    @Override
    public void medirNivel() {
        System.out.println("Nivel de aceite: Óptimo.");
    }
    @Override
    public void realizarCambioAceite() {
        System.out.println("Drenando aceite viejo (" + tipoFluido + ")... Nuevo aceite cargado.");
    }
    @Override
    public void verificarDesgaste() {
        System.out.println("Viscosidad actual dentro de parámetros.");
    }
}

// CLASE 4: SensorOxigeno
class SensorOxigeno extends SensorBase implements IPerformance {
    public double lecturaLambda;
    public boolean calentadorActivo;

    // 3. Full
    public SensorOxigeno(String ubicacion, double lambda, boolean calentador) {
        super(ubicacion);
        this.lecturaLambda = lambda;
        this.calentadorActivo = calentador;
    }
    // 2. Simple
    public SensorOxigeno(String ubicacion) {
        this(ubicacion, 1.0, true);
    }
    // 1. Default
    public SensorOxigeno() {
        this("Banco 1 Sensor 1");
    }
    // 4. Copia
    public SensorOxigeno(SensorOxigeno otro) {
        this(otro.ubicacion, otro.lecturaLambda, otro.calentadorActivo);
    }

    @Override
    public void leerDatos() {
        System.out.println("Lectura Lambda: " + lecturaLambda);
    }
    @Override
    public void medirRevoluciones() {
        System.out.println("Sincronizando con RPM del motor para lectura de gases.");
    }
    @Override
    public void calcularConsumo() {
        System.out.println("Ajustando mezcla aire/combustible según lectura.");
    }
}

// CLASE 5: Piston
class Piston extends PiezaBase implements IFabricacion {
    public double diametroMm;
    public int anillos;

    // 3. Full
    public Piston(String material, double diametro, int anillos) {
        super(material);
        this.diametroMm = diametro;
        this.anillos = anillos;
    }
    // 2. Simple
    public Piston(double diametro) {
        this("Aluminio Forjado", diametro, 3);
    }
    // 1. Default
    public Piston() {
        this(86.0);
    }
    // 4. Copia
    public Piston(Piston otro) {
        this(otro.material, otro.diametroMm, otro.anillos);
    }

    @Override
    public void pruebaResistencia() {
        System.out.println("Prueba de compresión superada en pistón de " + material);
    }
    @Override
    public void asignarLote() {
        System.out.println("Lote asignado: PIST-2024-X");
    }
    @Override
    public void controlCalidad() {
        System.out.println("Medición de tolerancias: Aprobado.");
    }
}

// =================================================================
// MAIN CLASS
// =================================================================

public class SistemaMotor {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE MOTOR EN JAVA ===");

        System.out.println("\n--- 1. PRUEBA MOTOR (Tu clase refactorizada) ---");
        // Constructor Full
        Motor m1 = new Motor("V8 Turbo", 8, 450.0, "Ferrari", false);
        
        m1.encender(); // De IFuncionamiento
        m1.mostrarFichaTecnica(); // De ComponenteMecanicoBase

        System.out.println("\n--- Prueba Constructor Copia ---");
        Motor mCopia = new Motor(m1);
        // La copia empieza con valores del original, pero su propio estado interno reseteado por la lógica del constructor si se desea, 
        // o copiamos el estado exacto. En este ejemplo copiamos temperatura y aceite.
        System.out.println("Copia Fabricante: " + mCopia.fabricante);
        System.out.println("Copia Temp Inicial: " + mCopia.getTemperatura());
        mCopia.apagar(); // La copia funciona independiente

        System.out.println("\n--- 2. PRUEBA BATERÍA ---");
        Bateria bat = new Bateria(12.8, 700, true);
        bat.verificarVoltaje();
        bat.reportarEstado();

        System.out.println("\n--- 3. PRUEBA ACEITE ---");
        AceiteMotor aceite = new AceiteMotor("5W-40 Sintético", 15000, true);
        aceite.medirNivel();
        aceite.realizarCambioAceite();

        System.out.println("\n--- 4. PRUEBA SENSOR O2 ---");
        SensorOxigeno o2 = new SensorOxigeno("Escape Trasero");
        o2.leerDatos();
        o2.calcularConsumo();

        System.out.println("\n--- 5. PRUEBA PISTÓN ---");
        Piston p = new Piston("Titanio", 90.5, 3);
        p.pruebaResistencia();
        p.controlCalidad();
    }
}