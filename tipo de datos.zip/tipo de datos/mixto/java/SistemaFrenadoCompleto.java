package sistema_frenado;

import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;

// =================================================================
// 1. INTERFACES (Definición de Comportamientos)
// =================================================================

interface IFrenado {
    void aplicarFreno();
    void liberarFreno();
}

interface IMonitoreo {
    void chequearNiveles();
    void reportarEstado();
}

interface IMantenimiento {
    void inspeccionarDesgaste();
    void reemplazar();
}

interface IElectronica {
    void leerSensores();
    void activarSeguridad();
}

interface IHidraulica {
    void verificarPresion();
    void purgarLiquido();
}

// =================================================================
// 2. CLASES ABSTRACTAS (Con 4 Constructores Reutilizados)
// =================================================================

// Clase Base 1: ComponenteSeguridad
abstract class ComponenteSeguridad {
    protected String idComponente;

    // 1. Default
    public ComponenteSeguridad() {
        this("SEG-GENERICO");
    }
    // 2. Con Parámetro
    public ComponenteSeguridad(String id) {
        this.idComponente = id;
    }
    // 3. Sobrecargado
    public ComponenteSeguridad(String tipo, int serie) {
        this(tipo + "-" + serie);
    }
    // 4. Copia
    public ComponenteSeguridad(ComponenteSeguridad otro) {
        this(otro.idComponente);
    }
    public abstract void fichaTecnica();
}

// Clase Base 2: FluidoTecnico
abstract class FluidoTecnico {
    protected String especificacion;

    public FluidoTecnico() { this("Estándar"); }
    public FluidoTecnico(String espec) { this.especificacion = espec; }
    public FluidoTecnico(String base, int grado) { this(base + "-G" + grado); }
    public FluidoTecnico(FluidoTecnico otro) { this(otro.especificacion); }
    public abstract void analizarCalidad();
}

// Clase Base 3: MaterialFriccion
abstract class MaterialFriccion {
    protected String compuesto;

    public MaterialFriccion() { this("Cerámica"); }
    public MaterialFriccion(String comp) { this.compuesto = comp; }
    public MaterialFriccion(String base, String aditivo) { this(base + "/" + aditivo); }
    public MaterialFriccion(MaterialFriccion otro) { this(otro.compuesto); }
    public abstract void calcularVidaUtil();
}

// Clase Base 4: DispositivoElectronico
abstract class DispositivoElectronico {
    protected double voltajeOperacion;

    public DispositivoElectronico() { this(12.0); }
    public DispositivoElectronico(double v) { this.voltajeOperacion = v; }
    public DispositivoElectronico(int celdas, double vCelda) { this(celdas * vCelda); }
    public DispositivoElectronico(DispositivoElectronico otro) { this(otro.voltajeOperacion); }
    public abstract void diagnosticarCircuito();
}

// Clase Base 5: MecanismoPresion
abstract class MecanismoPresion {
    protected int capacidadPSI;

    public MecanismoPresion() { this(2000); }
    public MecanismoPresion(int psi) { this.capacidadPSI = psi; }
    public MecanismoPresion(int bar, boolean esBar) { this(bar * 14); } // Aprox BAR a PSI
    public MecanismoPresion(MecanismoPresion otro) { this(otro.capacidadPSI); }
    public abstract void pruebaEstres();
}

// =================================================================
// 3. CLASES NORMALES (Implementación y Reutilización)
// =================================================================

// CLASE 1: SistemaFrenado (Tu clase solicitada, adaptada)
class SistemaFrenado extends ComponenteSeguridad implements IFrenado {

    // --- 5 PUBLICOS ---
    public String tipoFreno;
    public boolean frenoActivo;
    public int presionActual;
    public String fabricante;
    public double distanciaDetencion;

    // --- 5 PRIVADOS ---
    private boolean nivelLiquidoCorrecto;
    private double temperaturaPastillas;
    private Map<String, Object> sensores; // Reemplazo de JSONObject
    private byte[] codigoError;
    private String numeroSerie;

    // --- 5 PROTECTED ---
    protected double desgastePastillas;
    protected boolean necesitaCambio;
    protected String tipoLiquido;
    protected int presionMaxima;
    protected String paisFabricacion;

    // --- Método auxiliar de inicialización ---
    private void inicializarPrivados() {
        this.nivelLiquidoCorrecto = true;
        this.temperaturaPastillas = 30.0;
        this.sensores = new HashMap<>();
        this.sensores.put("ABS", "OK");
        this.codigoError = new byte[]{0};
        this.numeroSerie = "SN-" + System.nanoTime();
        
        this.desgastePastillas = 0.0;
        this.necesitaCambio = false;
        this.tipoLiquido = "DOT4";
        this.presionMaxima = 2500;
        this.paisFabricacion = "Japón";
    }

    // --- 4 CONSTRUCTORES (Reutilización con this) ---

    // 1. Full (Principal)
    public SistemaFrenado(String tipoFreno, String fabricante, double distanciaDetencion, int presionActual, boolean frenoActivo) {
        super("BRK-" + tipoFreno); // Llama al constructor base
        this.tipoFreno = tipoFreno;
        this.fabricante = fabricante;
        this.distanciaDetencion = distanciaDetencion;
        this.presionActual = presionActual;
        this.frenoActivo = frenoActivo;
        inicializarPrivados();
    }

    // 2. Simple
    public SistemaFrenado(String tipoFreno, String fabricante) {
        this(tipoFreno, fabricante, 45.5, 0, false);
    }

    // 3. Default
    public SistemaFrenado() {
        this("Disco Estándar", "Genérico");
    }

    // 4. Copia
    public SistemaFrenado(SistemaFrenado otro) {
        this(otro.tipoFreno, otro.fabricante, otro.distanciaDetencion, otro.presionActual, otro.frenoActivo);
        // Copia de campos específicos
        this.temperaturaPastillas = otro.getTemperaturaPastillas();
        this.nivelLiquidoCorrecto = true; // Reinicia estado en la copia
    }

    // --- Getters necesarios para la copia ---
    public double getTemperaturaPastillas() { return temperaturaPastillas; }

    // --- Métodos de Acción ---
    @Override
    public void aplicarFreno() {
        if (nivelLiquidoCorrecto && desgastePastillas < 80) {
            frenoActivo = true;
            presionActual += 500;
            distanciaDetencion -= 2.0;
            temperaturaPastillas += 20;
            System.out.println("🛑 Frenando... Presión: " + presionActual + " PSI");
        } else {
            System.out.println("⚠️ FALLO DE FRENOS: Revisar sistema.");
        }
    }

    @Override
    public void liberarFreno() {
        frenoActivo = false;
        presionActual = 0;
        temperaturaPastillas -= 5;
        System.out.println("✅ Frenos liberados.");
    }

    public void mostrarEstado() {
        System.out.println("\n--- ESTADO DEL SISTEMA DE FRENADO ---");
        System.out.println("ID: " + idComponente + " | Tipo: " + tipoFreno);
        System.out.println("Fabricante: " + fabricante + " | Presión: " + presionActual);
        System.out.println("Temp. Pastillas: " + temperaturaPastillas + "°C");
    }

    @Override
    public void fichaTecnica() {
        System.out.println("Ficha Técnica: Sistema " + tipoFreno + " fabricado en " + paisFabricacion);
    }
}

// CLASE 2: LiquidoFrenos
class LiquidoFrenos extends FluidoTecnico implements IHidraulica {
    public int puntoEbullicion;
    public boolean higroscopico;

    // 3. Full
    public LiquidoFrenos(String espec, int ebullicion, boolean higro) {
        super(espec);
        this.puntoEbullicion = ebullicion;
        this.higroscopico = higro;
    }
    // 2. Simple
    public LiquidoFrenos(String espec) {
        this(espec, 230, true);
    }
    // 1. Default
    public LiquidoFrenos() {
        this("DOT3");
    }
    // 4. Copia
    public LiquidoFrenos(LiquidoFrenos otro) {
        this(otro.especificacion, otro.puntoEbullicion, otro.higroscopico);
    }

    @Override
    public void verificarPresion() {
        System.out.println("Presión hidráulica estable en líneas de " + especificacion);
    }
    @Override
    public void purgarLiquido() {
        System.out.println("Purgando sistema... Burbujas eliminadas.");
    }
    @Override
    public void analizarCalidad() {
        System.out.println("Calidad del fluido " + especificacion + ": Aceptable.");
    }
}

// CLASE 3: PastillaFreno
class PastillaFreno extends MaterialFriccion implements IMantenimiento {
    public double espesorMm;
    public boolean sensorDesgaste;

    // 3. Full
    public PastillaFreno(String compuesto, double espesor, boolean sensor) {
        super(compuesto);
        this.espesorMm = espesor;
        this.sensorDesgaste = sensor;
    }
    // 2. Simple
    public PastillaFreno(String compuesto) {
        this(compuesto, 12.0, true);
    }
    // 1. Default
    public PastillaFreno() {
        this("Semimetálica");
    }
    // 4. Copia
    public PastillaFreno(PastillaFreno otro) {
        this(otro.compuesto, otro.espesorMm, otro.sensorDesgaste);
    }

    @Override
    public void inspeccionarDesgaste() {
        System.out.println("Espesor actual: " + espesorMm + "mm.");
    }
    @Override
    public void reemplazar() {
        System.out.println("Reemplazando pastillas de " + compuesto + "...");
        this.espesorMm = 12.0;
    }
    @Override
    public void calcularVidaUtil() {
        System.out.println("Vida útil estimada: 20,000 km restantes.");
    }
}

// CLASE 4: SensorABS
class SensorABS extends DispositivoElectronico implements IElectronica {
    public String posicionRueda;
    public boolean señalActiva;

    // 3. Full
    public SensorABS(double voltaje, String pos, boolean señal) {
        super(voltaje);
        this.posicionRueda = pos;
        this.señalActiva = señal;
    }
    // 2. Simple
    public SensorABS(String pos) {
        this(5.0, pos, true);
    }
    // 1. Default
    public SensorABS() {
        this("Delantera Izquierda");
    }
    // 4. Copia
    public SensorABS(SensorABS otro) {
        this(otro.voltajeOperacion, otro.posicionRueda, otro.señalActiva);
    }

    @Override
    public void leerSensores() {
        System.out.println("Leyendo velocidad angular en rueda " + posicionRueda);
    }
    @Override
    public void activarSeguridad() {
        System.out.println("ABS Activado: Evitando bloqueo de rueda " + posicionRueda);
    }
    @Override
    public void diagnosticarCircuito() {
        System.out.println("Circuito sensor ABS: Continuidad correcta.");
    }
}

// CLASE 5: ServoFreno
class ServoFreno extends MecanismoPresion implements IMonitoreo {
    public double diametroDiafragma;
    public boolean vacioCorrecto;

    // 3. Full
    public ServoFreno(int psi, double diametro, boolean vacio) {
        super(psi);
        this.diametroDiafragma = diametro;
        this.vacioCorrecto = vacio;
    }
    // 2. Simple
    public ServoFreno(double diametro) {
        this(800, diametro, true);
    }
    // 1. Default
    public ServoFreno() {
        this(10.5);
    }
    // 4. Copia
    public ServoFreno(ServoFreno otro) {
        this(otro.capacidadPSI, otro.diametroDiafragma, otro.vacioCorrecto);
    }

    @Override
    public void chequearNiveles() {
        System.out.println("Nivel de vacío en booster: " + (vacioCorrecto ? "OK" : "Fuga detectada"));
    }
    @Override
    public void reportarEstado() {
        System.out.println("Asistencia de frenado: " + (vacioCorrecto ? "Activa" : "Inactiva"));
    }
    @Override
    public void pruebaEstres() {
        System.out.println("Prueba de presión en servo (" + capacidadPSI + " PSI): Aprobada.");
    }
}

// =================================================================
// MAIN CLASS
// =================================================================

public class SistemaFrenadoCompleto {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE FRENADO AUTOMOTRIZ EN JAVA ===");

        System.out.println("\n--- 1. PRUEBA SISTEMA FRENADO (Tu clase) ---");
        // Constructor Full
        SistemaFrenado freno1 = new SistemaFrenado("ABS Deportivo", "Brembo", 35.0, 0, false);
        freno1.mostrarEstado();
        freno1.aplicarFreno();
        freno1.fichaTecnica(); // De la clase abstracta

        System.out.println("\n--- Prueba Constructor Copia ---");
        SistemaFrenado frenoCopia = new SistemaFrenado(freno1);
        frenoCopia.liberarFreno(); // La copia actúa independientemente
        System.out.println("Presión Original: " + freno1.presionActual);
        System.out.println("Presión Copia: " + frenoCopia.presionActual);

        System.out.println("\n--- 2. PRUEBA LIQUIDO FRENOS ---");
        LiquidoFrenos dot4 = new LiquidoFrenos("DOT4", 260, true);
        dot4.analizarCalidad();
        dot4.purgarLiquido();

        System.out.println("\n--- 3. PRUEBA PASTILLA FRENO ---");
        PastillaFreno pastilla = new PastillaFreno("Cerámica-Carbono", 14.0, true);
        pastilla.inspeccionarDesgaste();
        pastilla.calcularVidaUtil();

        System.out.println("\n--- 4. PRUEBA SENSOR ABS ---");
        SensorABS sensorFD = new SensorABS("Trasera Derecha"); // Usa simple
        sensorFD.leerSensores();
        sensorFD.activarSeguridad();

        System.out.println("\n--- 5. PRUEBA SERVO FRENO ---");
        ServoFreno booster = new ServoFreno(1200, 11.0, true);
        booster.chequearNiveles();
        booster.pruebaEstres();
    }
}