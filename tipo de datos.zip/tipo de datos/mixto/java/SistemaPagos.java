package sistema_pagos;

import java.util.Map;
import java.util.HashMap;
import java.util.Date;
import java.util.Arrays;

// =================================================================
// 1. INTERFACES (5 Ejemplos)
// =================================================================

interface IProcesamientoPago {
    void procesar();
    void cancelar();
}

interface ISeguridad {
    void verificarIdentidad();
    void encriptarDatos();
}

interface INotificacion {
    void enviarRecibo();
    void alertarFraude();
}

interface IContabilidad {
    void registrarLibro();
    void calcularImpuestos();
}

interface IAuditoria {
    void generarLog();
    void validarIntegridad();
}

// =================================================================
// 2. CLASES ABSTRACTAS (5 Ejemplos con 4 Constructores Reutilizados)
// =================================================================

// Clase Base 1: TransaccionBase
abstract class TransaccionBase {
    protected String idTransaccion;

    // 1. Default
    public TransaccionBase() {
        this("TX-000000");
    }
    // 2. Con Parámetro (Principal)
    public TransaccionBase(String id) {
        this.idTransaccion = id;
    }
    // 3. Sobrecargado
    public TransaccionBase(String prefijo, int numero) {
        this(prefijo + "-" + numero);
    }
    // 4. Copia
    public TransaccionBase(TransaccionBase otro) {
        this(otro.idTransaccion);
    }
    public abstract void mostrarInfoBase();
}

// Clase Base 2: UsuarioBase
abstract class UsuarioBase {
    protected String nombreUsuario;

    public UsuarioBase() { this("Invitado"); }
    public UsuarioBase(String nombre) { this.nombreUsuario = nombre; }
    public UsuarioBase(String nombre, String apellido) { this(nombre + " " + apellido); }
    public UsuarioBase(UsuarioBase otro) { this(otro.nombreUsuario); }
    public abstract void mostrarPerfil();
}

// Clase Base 3: DocumentoFinancieroBase
abstract class DocumentoFinancieroBase {
    protected String codigoDocumento;

    public DocumentoFinancieroBase() { this("DOC-NULL"); }
    public DocumentoFinancieroBase(String codigo) { this.codigoDocumento = codigo; }
    public DocumentoFinancieroBase(int serie, int folio) { this("F-" + serie + "-" + folio); }
    public DocumentoFinancieroBase(DocumentoFinancieroBase otro) { this(otro.codigoDocumento); }
    public abstract void imprimirEncabezado();
}

// Clase Base 4: ServicioFinancieroBase
abstract class ServicioFinancieroBase {
    protected String nombreServicio;

    public ServicioFinancieroBase() { this("Servicio Genérico"); }
    public ServicioFinancieroBase(String nombre) { this.nombreServicio = nombre; }
    public ServicioFinancieroBase(String proveedor, String tipo) { this(proveedor + " " + tipo); }
    public ServicioFinancieroBase(ServicioFinancieroBase otro) { this(otro.nombreServicio); }
    public abstract void describirServicio();
}

// Clase Base 5: DispositivoSeguridadBase
abstract class DispositivoSeguridadBase {
    protected String serialDispositivo;

    public DispositivoSeguridadBase() { this("SN-UNKNOWN"); }
    public DispositivoSeguridadBase(String serial) { this.serialDispositivo = serial; }
    public DispositivoSeguridadBase(String modelo, int lote) { this(modelo + "-L" + lote); }
    public DispositivoSeguridadBase(DispositivoSeguridadBase otro) { this(otro.serialDispositivo); }
    public abstract void estadoDispositivo();
}

// =================================================================
// 3. CLASES NORMALES (5 Ejemplos con Constructores Encadenados)
// =================================================================

// CLASE 1: MetodoPagoEnLinea (Refactorizada según tu solicitud)
class MetodoPagoEnLinea extends TransaccionBase implements IProcesamientoPago {

    // --- 5 PUBLICOS ---
    public String nombreTitular;
    public String tipoPago;
    public double monto;
    public boolean transaccionExitosa;
    public int numeroTransaccion;

    // --- 5 PRIVADOS ---
    private String numeroTarjeta;
    private String codigoSeguridad;
    private boolean verificacion2FA;
    private byte[] comprobanteBinario;
    private Map<String, Object> detallePago; // Reemplaza JSONObject

    // --- 5 PROTECTED ---
    protected String paisOrigen;
    protected double tasaImpuesto;
    protected boolean requiereFactura;
    protected String metodoMoneda;
    protected int tiempoProcesamiento;

    // --- Método auxiliar de inicialización ---
    private void inicializarPrivados() {
        this.numeroTarjeta = "****-****-****-0000";
        this.codigoSeguridad = "***";
        this.verificacion2FA = false;
        this.comprobanteBinario = new byte[0];
        this.detallePago = new HashMap<>();
        this.detallePago.put("estado", "pendiente");
        
        this.paisOrigen = "Global";
        this.tasaImpuesto = 0.19;
        this.requiereFactura = false;
        this.metodoMoneda = "USD";
        this.tiempoProcesamiento = 0;
    }

    // --- 4 CONSTRUCTORES (Reutilización con this) ---

    // 1. Full (Principal)
    public MetodoPagoEnLinea(String nombreTitular, String tipoPago, double monto, int numeroTransaccion, boolean transaccionExitosa) {
        super("TX-" + numeroTransaccion); // Llama a base
        this.nombreTitular = nombreTitular;
        this.tipoPago = tipoPago;
        this.monto = monto;
        this.numeroTransaccion = numeroTransaccion;
        this.transaccionExitosa = transaccionExitosa;
        inicializarPrivados();
    }

    // 2. Simple
    public MetodoPagoEnLinea(String nombreTitular, double monto) {
        this(nombreTitular, "Tarjeta Crédito", monto, 0, false);
    }

    // 3. Default
    public MetodoPagoEnLinea() {
        this("Cliente Anónimo", 0.0);
    }

    // 4. Copia
    public MetodoPagoEnLinea(MetodoPagoEnLinea otro) {
        this(otro.nombreTitular, otro.tipoPago, otro.monto, otro.numeroTransaccion, otro.transaccionExitosa);
        // Copia de campos privados/protegidos específicos
        this.verificacion2FA = otro.isVerificacion2FA();
        this.metodoMoneda = otro.metodoMoneda;
        this.tiempoProcesamiento = otro.tiempoProcesamiento;
    }

    // --- Getters y Setters necesarios ---
    public boolean isVerificacion2FA() { return verificacion2FA; }
    public void setVerificacion2FA(boolean v) { this.verificacion2FA = v; }

    // --- Métodos de Acción ---
    public void generarComprobante() {
        if (transaccionExitosa) {
            System.out.println("Comprobante generado para la transacción #" + numeroTransaccion);
        } else {
            System.out.println("No se puede generar comprobante: pago fallido.");
        }
    }

    public void mostrarResumen() {
        System.out.println("\n----- Resumen del Pago en Línea -----");
        System.out.println("Titular: " + nombreTitular);
        System.out.println("Tipo: " + tipoPago + " | Monto: $" + monto + " " + metodoMoneda);
        System.out.println("Estado: " + (transaccionExitosa ? "EXITOSO" : "FALLIDO"));
        System.out.println("Impuesto: " + (tasaImpuesto * 100) + "%");
    }

    // --- Implementación de Interfaces/Abstractos ---
    @Override
    public void mostrarInfoBase() {
        System.out.println("Transacción ID Base: " + idTransaccion);
    }

    @Override
    public void procesar() {
        if (verificacion2FA && monto > 0) {
            transaccionExitosa = true;
            tiempoProcesamiento = 5;
            System.out.println("Pago procesado exitosamente.");
        } else {
            transaccionExitosa = false;
            System.out.println("Error al procesar: Verifique 2FA o monto.");
        }
    }

    @Override
    public void cancelar() {
        transaccionExitosa = false;
        System.out.println("Transacción cancelada por el usuario.");
    }
}

// CLASE 2: ClienteBancario
class ClienteBancario extends UsuarioBase implements ISeguridad {
    public String tipoCuenta;
    public double saldo;

    // 3. Full
    public ClienteBancario(String nombre, String tipo, double saldo) {
        super(nombre);
        this.tipoCuenta = tipo;
        this.saldo = saldo;
    }
    // 2. Simple
    public ClienteBancario(String nombre) {
        this(nombre, "Ahorros", 0.0);
    }
    // 1. Default
    public ClienteBancario() {
        this("Usuario Nuevo");
    }
    // 4. Copia
    public ClienteBancario(ClienteBancario otro) {
        this(otro.nombreUsuario, otro.tipoCuenta, otro.saldo);
    }

    @Override
    public void verificarIdentidad() {
        System.out.println("Identidad de " + nombreUsuario + " verificada biométricamente.");
    }
    @Override
    public void encriptarDatos() {
        System.out.println("Datos del cliente encriptados con AES-256.");
    }
    @Override
    public void mostrarPerfil() {
        System.out.println("Cliente: " + nombreUsuario + " [" + tipoCuenta + "]");
    }
}

// CLASE 3: FacturaDigital
class FacturaDigital extends DocumentoFinancieroBase implements IContabilidad {
    public String emisor;
    public double total;

    // 3. Full
    public FacturaDigital(String codigo, String emisor, double total) {
        super(codigo);
        this.emisor = emisor;
        this.total = total;
    }
    // 2. Simple
    public FacturaDigital(String emisor) {
        this("FAC-TEMP", emisor, 0.0);
    }
    // 1. Default
    public FacturaDigital() {
        this("Empresa Genérica");
    }
    // 4. Copia
    public FacturaDigital(FacturaDigital otra) {
        this(otra.codigoDocumento, otra.emisor, otra.total);
    }

    @Override
    public void registrarLibro() {
        System.out.println("Factura " + codigoDocumento + " registrada en libro contable.");
    }
    @Override
    public void calcularImpuestos() {
        System.out.println("IVA calculado: $" + (total * 0.19));
    }
    @Override
    public void imprimirEncabezado() {
        System.out.println("FACTURA ELECTRÓNICA: " + codigoDocumento + " - Emisor: " + emisor);
    }
}

// CLASE 4: PasarelaPago
class PasarelaPago extends ServicioFinancieroBase implements INotificacion {
    public String protocolo;
    public boolean activa;

    // 3. Full
    public PasarelaPago(String nombre, String protocolo, boolean activa) {
        super(nombre);
        this.protocolo = protocolo;
        this.activa = activa;
    }
    // 2. Simple
    public PasarelaPago(String nombre) {
        this(nombre, "HTTPS/TLS 1.3", true);
    }
    // 1. Default
    public PasarelaPago() {
        this("Pasarela Default");
    }
    // 4. Copia
    public PasarelaPago(PasarelaPago otra) {
        this(otra.nombreServicio, otra.protocolo, otra.activa);
    }

    @Override
    public void enviarRecibo() {
        System.out.println("Recibo enviado por email desde " + nombreServicio);
    }
    @Override
    public void alertarFraude() {
        System.out.println("¡Alerta! Actividad sospechosa detectada en la pasarela.");
    }
    @Override
    public void describirServicio() {
        System.out.println("Pasarela: " + nombreServicio + " (Protocolo: " + protocolo + ")");
    }
}

// CLASE 5: TokenDigital
class TokenDigital extends DispositivoSeguridadBase implements IAuditoria {
    public int vidaUtilSegundos;
    public boolean expirado;

    // 3. Full
    public TokenDigital(String serial, int vidaUtil, boolean expirado) {
        super(serial);
        this.vidaUtilSegundos = vidaUtil;
        this.expirado = expirado;
    }
    // 2. Simple
    public TokenDigital(String serial) {
        this(serial, 60, false);
    }
    // 1. Default
    public TokenDigital() {
        this("TOKEN-SOFT");
    }
    // 4. Copia
    public TokenDigital(TokenDigital otro) {
        this(otro.serialDispositivo, otro.vidaUtilSegundos, otro.expirado);
    }

    @Override
    public void generarLog() {
        System.out.println("Log generado para token: " + serialDispositivo);
    }
    @Override
    public void validarIntegridad() {
        System.out.println("Integridad del token verificada. Expirado: " + expirado);
    }
    @Override
    public void estadoDispositivo() {
        System.out.println("Token " + serialDispositivo + " - Vida útil: " + vidaUtilSegundos + "s");
    }
}

// =================================================================
// MAIN CLASS
// =================================================================

public class SistemaPagos {
    public static void main(String[] args) {
        System.out.println("=== SISTEMA DE PAGOS EN LÍNEA ===");

        System.out.println("\n--- 1. PRUEBA METODO PAGO (Tu clase refactorizada) ---");
        // Constructor Full
        MetodoPagoEnLinea pago1 = new MetodoPagoEnLinea("Juan Perez", "PayPal", 150.00, 998877, false);
        
        // Configuración y uso
        pago1.setVerificacion2FA(true); // Habilitar para que procese
        pago1.procesar();
        pago1.mostrarResumen();
        pago1.generarComprobante();

        System.out.println("\n--- Prueba Constructor Copia ---");
        MetodoPagoEnLinea pagoCopia = new MetodoPagoEnLinea(pago1);
        pagoCopia.cancelar(); // Cancelamos la copia, el original sigue exitoso
        System.out.println("Original exitoso: " + pago1.transaccionExitosa);
        System.out.println("Copia exitosa: " + pagoCopia.transaccionExitosa);

        System.out.println("\n--- 2. PRUEBA CLIENTE BANCARIO ---");
        ClienteBancario cliente = new ClienteBancario("Maria Lopez", "Corriente", 5000.0);
        cliente.mostrarPerfil();
        cliente.encriptarDatos();

        System.out.println("\n--- 3. PRUEBA FACTURA DIGITAL ---");
        FacturaDigital fac = new FacturaDigital("F001-2023", "Tech Store", 1200.50);
        fac.imprimirEncabezado();
        fac.calcularImpuestos();

        System.out.println("\n--- 4. PRUEBA PASARELA PAGO ---");
        PasarelaPago gw = new PasarelaPago("Stripe Connect");
        gw.describirServicio();
        gw.alertarFraude();

        System.out.println("\n--- 5. PRUEBA TOKEN DIGITAL ---");
        TokenDigital token = new TokenDigital("RSA-Key-99", 30, false);
        token.estadoDispositivo();
        token.validarIntegridad();
    }
}