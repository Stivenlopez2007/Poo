using System;
using System.Text.Json;

namespace SistemaFarmaceutico
{
    // ================== 5 INTERFACES ==================
    public interface INegocio
    {
        void Abrir();
        void Cerrar();
    }

    public interface IVentas
    {
        void RegistrarVenta();
        void CancelarVenta();
    }

    public interface IInventario
    {
        void AgregarProducto();
        void QuitarProducto();
    }

    public interface IEmpleados
    {
        void Contratar();
        void Despedir();
    }

    public interface IProveedor
    {
        void RealizarPedido();
        void RecibirPedido();
    }

    // ================== CLASES ABSTRACTAS CON REUTILIZACIÓN (Constructores) ==================

    public abstract class EstablecimientoBase
    {
        public string NombreEstablecimiento;

        // 1. Constructor sin parámetros (Llama al constructor principal)
        public EstablecimientoBase() : this("Establecimiento generico", 0) { }

        // 2. Constructor sobrecargado (Nombre)
        public EstablecimientoBase(string nombre) : this(nombre, 0) { }

        // 3. Constructor con parámetros (PRINCIPAL)
        public EstablecimientoBase(string nombre, int codigo)
        {
            NombreEstablecimiento = (codigo > 0) ? $"Establecimiento numero {codigo} - {nombre}" : nombre;
        }

        // 4. Constructor de Copia (Delegado al principal, pero mantiene la firma)
        public EstablecimientoBase(EstablecimientoBase otro) : this(otro.NombreEstablecimiento, 0) { }

        public abstract void MostrarInformacion();
    }

    public abstract class ProductoBase
    {
        public string NombreProducto;

        public ProductoBase() : this("Producto generico", 0) { }
        public ProductoBase(string nombre) : this(nombre, 0) { }
        public ProductoBase(string nombre, int codigo)
        {
            NombreProducto = (codigo > 0) ? $"Producto codigo {codigo} - {nombre}" : nombre;
        }
        public ProductoBase(ProductoBase otro) : this(otro.NombreProducto, 0) { }

        public abstract void MostrarDetalles();
    }

    public abstract class PersonalBase
    {
        public string NombrePersonal;

        public PersonalBase() : this("Personal sin nombre", 0) { }
        public PersonalBase(string nombre) 
        : this(nombre, 0) { }
        public PersonalBase(string nombre, int legajo)
        {
            NombrePersonal = (legajo > 0) ? $"Personal legajo {legajo} - {nombre}" : nombre;
        }
        public PersonalBase(PersonalBase otro) : this(otro.NombrePersonal, 0) { }

        public abstract void MostrarDatos();
    }

    public abstract class ServicioBase
    {
        public string TipoServicio;

        public ServicioBase() : this("Servicio basico", 0) { }
        public ServicioBase(string tipo) : this(tipo, 0) { }
        public ServicioBase(string tipo, int nivel)
        {
            TipoServicio = (nivel > 0) ? $"Servicio nivel {nivel} - {tipo}" : tipo;
        }
        public ServicioBase(ServicioBase otro) : this(otro.TipoServicio, 0) { }

        public abstract void Ejecutar();
    }

    public abstract class SistemaBase
    {
        public string NombreSistema;

        public SistemaBase() : this("Sistema generico", 0) { }
        public SistemaBase(string nombre) : this(nombre, 0) { }
        public SistemaBase(string nombre, int version)
        {
            NombreSistema = (version > 0) ? $"Sistema version {version} - {nombre}" : nombre;
        }
        public SistemaBase(SistemaBase otro) : this(otro.NombreSistema, 0) { }

        public abstract void Inicializar();
    }

    // ================== CLASES NORMALES (5 EJEMPLOS) ==================

    // Clase Normal 1: Farmacia (Establecimiento + INegocio)
    public class Farmacia : EstablecimientoBase, INegocio
    {
        // Propiedades Public
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public bool Abierta { get; set; }
        public int NumeroEmpleados { get; set; }

        // Campos Private
        private double ingresosDiarios;
        private int ventasRealizadas;
        private bool sistemaActivo;
        private byte[] logoFarmacia;
        private JsonDocument registroVentas;

        // Campos Protected
        protected double PrecioPromedio;
        protected int ProductosDisponibles;
        protected bool TurnoNoche;
        protected string TipoFarmacia;
        protected string ProveedorPrincipal;

        // Reutilización por encadenamiento de constructores con :this()
        public Farmacia() : this("Farmacia Generica", "Sin direccion", "Sin encargado", 3) { }

        public Farmacia(string nombre, string direccion, string encargado)
            : this(nombre, direccion, encargado, 3) { }

        // Constructor principal que llama a InicializarDatos() solo una vez
        public Farmacia(string nombre, string direccion, string encargado, int empleados)
            : base(nombre) // Llama al constructor de EstablecimientoBase(string nombre)
        {
            Nombre = nombre;
            Direccion = direccion;
            Encargado = encargado;
            NumeroEmpleados = empleados;
            InicializarDatos();
        }

        // Constructor de Copia (Mantiene la firma requerida)
        public Farmacia(Farmacia otra)
            : this(otra.Nombre, otra.Direccion, otra.Encargado, otra.NumeroEmpleados) // Delega la inicialización
        {
            // Copia explícita de campos privados/protegidos (donde no se puede reutilizar)
            ingresosDiarios = otra.ingresosDiarios;
            ventasRealizadas = otra.ventasRealizadas;
            sistemaActivo = otra.sistemaActivo;
            PrecioPromedio = otra.PrecioPromedio;
            // ... (otros campos privados/protected deben copiarse aquí si es necesario)
        }

        private void InicializarDatos()
        {
            Abierta = false;
            ingresosDiarios = 0;
            ventasRealizadas = 0;
            sistemaActivo = true;
            logoFarmacia = Array.Empty<byte>();
            registroVentas = JsonDocument.Parse("{}");
            PrecioPromedio = 25000;
            ProductosDisponibles = 150;
            TurnoNoche = false;
            TipoFarmacia = "Popular";
            ProveedorPrincipal = "Distribuidora Salud Total";
        }

        // Implementación de la Interfaz INegocio
        public void Abrir()
        {
            Abierta = true;
            Console.WriteLine("La farmacia ha abierto.");
        }

        public void Cerrar()
        {
            Abierta = false;
            Console.WriteLine("La farmacia ha cerrado.");
        }

        // Implementación de la clase abstracta
        public override void MostrarInformacion()
        {
            Console.WriteLine($"Farmacia: {NombreEstablecimiento} - Encargado: {Encargado}");
        }
    }

    // Clase Normal 2: Drogueria (Establecimiento + INegocio)
    public class Drogueria : EstablecimientoBase, INegocio
    {
        // Propiedades Public (Ejemplo simplificado, similar a Farmacia)
        public string Ciudad { get; set; }
        public string Gerente { get; set; }
        public int Sucursales { get; set; }

        // Campos Private
        private double capitalInvertido;
        private int clientesMensuales;
        // ... (otros campos) ...

        // Campos Protected
        protected double MargenGanancia;
        // ... (otros campos) ...

        // Reutilización por encadenamiento de constructores con :this()
        public Drogueria() : this("Drogueria Generica", "Sin ciudad", "Sin gerente", 1) { }

        public Drogueria(string nombre, string ciudad, string gerente)
            : this(nombre, ciudad, gerente, 1) { }

        public Drogueria(string nombre, string ciudad, string gerente, int sucursales)
            : base(nombre)
        {
            Ciudad = ciudad;
            Gerente = gerente;
            Sucursales = sucursales;
            InicializarDatos();
        }

        public Drogueria(Drogueria otra)
            : this(otra.NombreEstablecimiento, otra.Ciudad, otra.Gerente, otra.Sucursales)
        {
            capitalInvertido = otra.capitalInvertido;
            // ... (copia de campos privados) ...
        }

        private void InicializarDatos()
        {
            capitalInvertido = 0;
            clientesMensuales = 0;
            MargenGanancia = 30;
        }

        public void Abrir() => Console.WriteLine("La drogueria esta operativa.");
        public void Cerrar() => Console.WriteLine("La drogueria ha cerrado.");

        public override void MostrarInformacion()
        {
            Console.WriteLine($"{NombreEstablecimiento} - Ciudad: {Ciudad}, Sucursales: {Sucursales}");
        }
    }

    // Clase Normal 3: Medicamento (Producto + IInventario)
    public class Medicamento : ProductoBase, IInventario
    {
        public string NombreComercial { get; set; }
        public string Laboratorio { get; set; }
        public double Precio { get; set; }

        private int unidadesStock;
        private string lote;

        protected int DiasVencimiento;

        public Medicamento() : this("Medicamento Generico", "Sin Lab", 0.0, 100) { }

        public Medicamento(string nombre, string laboratorio, double precio)
            : this(nombre, laboratorio, precio, 100) { }

        public Medicamento(string nombre, string laboratorio, double precio, int stock)
            : base(nombre)
        {
            NombreComercial = nombre;
            Laboratorio = laboratorio;
            Precio = precio;
            InicializarDatos(stock);
        }

        public Medicamento(Medicamento otro)
            : this(otro.NombreComercial, otro.Laboratorio, otro.Precio, otro.unidadesStock)
        {
            lote = otro.lote;
        }

        private void InicializarDatos(int stock)
        {
            unidadesStock = stock;
            lote = "LOTE-DEF";
            DiasVencimiento = 365;
        }

        public void AgregarProducto()
        {
            unidadesStock += 50;
            Console.WriteLine("Stock incrementado.");
        }

        public void QuitarProducto()
        {
            if (unidadesStock > 0)
            {
                unidadesStock--;
                Console.WriteLine("Producto vendido.");
            }
        }

        public override void MostrarDetalles()
        {
            Console.WriteLine($"{NombreProducto} - Precio: ${Precio}, Stock: {unidadesStock}");
        }
    }

    // Clase Normal 4: Farmaceutico (Personal + IEmpleados)
    public class Farmaceutico : PersonalBase, IEmpleados
    {
        public string Nombre { get; set; }
        public string Especialidad { get; set; }
        public double Salario { get; set; }

        private string tarjetaProfesional;
        private int horasTrabajadas;

        protected string Turno;

        public Farmaceutico() : this("Farmaceutico Generico", "General", 2000000, "TP-0000") { }

        public Farmaceutico(string nombre, string especialidad, double salario)
            : this(nombre, especialidad, salario, "TP-0000") { }

        public Farmaceutico(string nombre, string especialidad, double salario, string tarjeta)
            : base(nombre)
        {
            Nombre = nombre;
            Especialidad = especialidad;
            Salario = salario;
            InicializarDatos(tarjeta);
        }

        public Farmaceutico(Farmaceutico otro)
            : this(otro.Nombre, otro.Especialidad, otro.Salario, otro.tarjetaProfesional)
        {
            horasTrabajadas = otro.horasTrabajadas;
        }

        private void InicializarDatos(string tarjeta)
        {
            tarjetaProfesional = tarjeta;
            horasTrabajadas = 0;
            Turno = "Diurno";
        }

        public void Contratar() => Console.WriteLine("Farmaceutico contratado.");
        public void Despedir() => Console.WriteLine("Farmaceutico despedido.");

        public override void MostrarDatos()
        {
            Console.WriteLine($"{NombrePersonal} - Especialidad: {Especialidad}, Salario: ${Salario}");
        }
    }

    // Clase Normal 5: Proveedor (Establecimiento + IProveedor)
    public class Proveedor : EstablecimientoBase, IProveedor
    {
        public string NombreEmpresa { get; set; }
        public string Contacto { get; set; }
        public int TiempoEntrega { get; set; }

        private double montoFacturado;
        private int pedidosRealizados;

        protected string Calificacion;

        public Proveedor() : this("Proveedor Generico", "Sin contacto", 7) { }

        public Proveedor(string empresa, string contacto)
            : this(empresa, contacto, 7) { }

        public Proveedor(string empresa, string contacto, int tiempoEntrega)
            : base(empresa)
        {
            NombreEmpresa = empresa;
            Contacto = contacto;
            TiempoEntrega = tiempoEntrega;
            InicializarDatos();
        }

        public Proveedor(Proveedor otro)
            : this(otro.NombreEmpresa, otro.Contacto, otro.TiempoEntrega)
        {
            montoFacturado = otro.montoFacturado;
        }

        private void InicializarDatos()
        {
            montoFacturado = 0;
            pedidosRealizados = 0;
            Calificacion = "A+";
        }

        public void RealizarPedido()
        {
            pedidosRealizados++;
            Console.WriteLine("Pedido realizado al proveedor.");
        }

        public void RecibirPedido()
        {
            Console.WriteLine("Pedido recibido del proveedor.");
        }

        public override void MostrarInformacion()
        {
            Console.WriteLine($"{NombreEstablecimiento} - Contacto: {Contacto}, Entrega: {TiempoEntrega} días");
        }
    }

    // ================== CLASE PRINCIPAL CON MAIN ==================

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- PRUEBA DE FARMACIA (Reutilización por :this() y :base()) ---");
            // Constructor sin parámetros
            Farmacia f1 = new Farmacia();
            // Constructor sobrecargado
            Farmacia f2 = new Farmacia("Farmacia VidaPlena", "Cra 8 #12-34", "Laura Gomez");
            // Constructor con parámetros (principal)
            Farmacia f3 = new Farmacia("Farmacia Cruz Verde", "Calle 10 #5-20", "Carlos Ruiz", 5);
            // Constructor de copia
            Farmacia f4 = new Farmacia(f2);

            f2.Abrir();
            f2.MostrarInformacion();

            Console.WriteLine("\n--- PRUEBA DE MEDICAMENTO ---");
            Medicamento m2 = new Medicamento("Acetaminofen", "Genfar", 5000);
            Medicamento m3 = new Medicamento("Dolex", "Tecnoquimicas", 6000, 200);
            Medicamento m4_copia = new Medicamento(m3);
            m4_copia.MostrarDetalles();
            m3.AgregarProducto();
            m3.MostrarDetalles();
        }
    }
}