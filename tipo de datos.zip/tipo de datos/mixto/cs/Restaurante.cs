using System;

namespace SistemaUniversitarioCompacto
{
    // ================== 5 INTERFACES (Contratos) ==================

    public interface IMatricula { void Matricular(); }
    public interface IExamenes { void Evaluar(); }
    public interface IDocumentacion { void EmitirCertificado(); }
    public interface IFinanzas { void PagarColegiatura(); }
    public interface IInvestigacion { void PublicarArticulo(); }

    
    // ================== 5 CLASES ABSTRACTAS (Bases con 4 Constructores Chained) ==================

    public abstract class UnidadAcademicaBase
    {
        public string NombreUnidad;

        // 1. Constructor sin parámetros: Delega al 3
        public UnidadAcademicaBase() : this("Unidad Generica", 0) { }

        // 2. Constructor sobrecargado (string): Delega al 3
        public UnidadAcademicaBase(string nombre) : this(nombre, 0) { }

        // 3. Constructor principal (string, int): Lógica central
        public UnidadAcademicaBase(string nombre, int codigo)
        {
            NombreUnidad = (codigo > 0) ? $"Código {codigo} - {nombre}" : nombre;
        }

        // 4. Constructor de Copia: Delega al 3
        public UnidadAcademicaBase(UnidadAcademicaBase otro) : this(otro.NombreUnidad, 0) { }

        public abstract void MostrarInformacion();
    }

    public abstract class EstudianteBase
    {
        public string NombreEstudiante;

        public EstudianteBase() : this("Estudiante Generico", 0) { }
        public EstudianteBase(string nombre) : this(nombre, 0) { }
        public EstudianteBase(string nombre, int carne)
        {
            NombreEstudiante = (carne > 0) ? $"Carne {carne} - {nombre}" : nombre;
        }
        public EstudianteBase(EstudianteBase otro) : this(otro.NombreEstudiante, 0) { }

        public abstract void MostrarProgreso();
    }

    public abstract class PersonalUniversitarioBase
    {
        public string NombrePersonal;

        public PersonalUniversitarioBase() : this("Personal sin nombre", 0) { }
        public PersonalUniversitarioBase(string nombre) : this(nombre, 0) { }
        public PersonalUniversitarioBase(string nombre, int id)
        {
            NombrePersonal = (id > 0) ? $"ID {id} - {nombre}" : nombre;
        }
        public PersonalUniversitarioBase(PersonalUniversitarioBase otro) : this(otro.NombrePersonal, 0) { }

        public abstract void MostrarDatos();
    }

    public abstract class CursoBase
    {
        public string NombreCurso;

        public CursoBase() : this("Curso Generico", "GNR") { }
        public CursoBase(string nombre) : this(nombre, "GNR") { }
        public CursoBase(string nombre, string codigo)
        {
            NombreCurso = (codigo != "GNR") ? $"{codigo} - {nombre}" : nombre;
        }
        public CursoBase(CursoBase otro) : this(otro.NombreCurso, "GNR") { }

        public abstract void MostrarTemario();
    }

    public abstract class RecursoBase
    {
        public string NombreRecurso;

        public RecursoBase() : this("Recurso Generico", 0) { }
        public RecursoBase(string nombre) : this(nombre, 0) { }
        public RecursoBase(string nombre, int capacidad)
        {
            NombreRecurso = (capacidad > 0) ? $"{nombre} (Cap: {capacidad})" : nombre;
        }
        public RecursoBase(RecursoBase otra) : this(otra.NombreRecurso, 0) { }

        public abstract void MostrarDisponibilidad();
    }


    // ================== 5 CLASES NORMALES (Implementación y Chaining) ==================

    // Clase Normal 1: Alumno
    public class Alumno : EstudianteBase, IMatricula
    {
        public string Carrera { get; set; }
        private bool matriculaActiva;

        // 1. Constructor sin parámetros: Delega al 3
        public Alumno() : this("Alumno Nuevo", "Ingeniería", 1) { }

        // 2. Constructor sobrecargado: Delega al 3
        public Alumno(string nombre) : this(nombre, "Artes", 1) { }

        // 3. Constructor principal: Inicialización única
        public Alumno(string nombre, string carrera, int semestre) : base(nombre, semestre)
        {
            Carrera = carrera;
            InicializarDatos();
        }

        // 4. Constructor de Copia: Delega al 3
        public Alumno(Alumno otro) : this(otro.NombreEstudiante, otro.Carrera, 0) { }

        private void InicializarDatos()
        {
            matriculaActiva = false;
        }

        public void Matricular()
        {
            matriculaActiva = true;
            Console.WriteLine($"[MATRICULA] {NombreEstudiante} matriculado en {Carrera}.");
        }

        public override void MostrarProgreso()
        {
            Console.WriteLine($"\tAlumno: {NombreEstudiante}, Activa: {matriculaActiva}");
        }
    }

    // Clase Normal 2: Facultad
    public class Facultad : UnidadAcademicaBase, IDocumentacion
    {
        public string Decano { get; set; }
        private int numCarreras;

        public Facultad() : this("Facultad Base", "Decano X", 5) { }
        public Facultad(string nombre) : this(nombre, "Decano Y", 5) { }
        public Facultad(string nombre, string decano, int codigo) : base(nombre, codigo)
        {
            Decano = decano;
            InicializarDatos(codigo);
        }
        public Facultad(Facultad otra) : this(otra.NombreUnidad, otra.Decano, 0) { }

        private void InicializarDatos(int codigo)
        {
            numCarreras = 5;
        }

        public void EmitirCertificado()
        {
            Console.WriteLine($"[DOCUMENTACION] {NombreUnidad} emite un certificado.");
        }

        public override void MostrarInformacion()
        {
            Console.WriteLine($"\tFacultad: {NombreUnidad}, Decano: {Decano}, Carreras: {numCarreras}");
        }
    }

    // Clase Normal 3: Materia
    public class Materia : CursoBase, IExamenes
    {
        public int Creditos { get; set; }
        private double calificacionPromedio;

        public Materia() : this("Curso Generico", 3, "G-101") { }
        public Materia(string nombre) : this(nombre, 3, "G-101") { }
        public Materia(string nombre, int creditos, string codigo) : base(nombre, codigo)
        {
            Creditos = creditos;
            InicializarDatos();
        }
        public Materia(Materia otra) : this(otra.NombreCurso, otra.Creditos, "G-101") { }

        private void InicializarDatos()
        {
            calificacionPromedio = 0.0;
        }

        public void Evaluar()
        {
            calificacionPromedio = 4.2;
            Console.WriteLine($"[EXAMENES] Evaluación realizada en {NombreCurso}. Nuevo promedio: {calificacionPromedio}");
        }

        public override void MostrarTemario()
        {
            Console.WriteLine($"\tCurso: {NombreCurso}, Créditos: {Creditos}");
        }
    }

    // Clase Normal 4: Profesor
    public class Profesor : PersonalUniversitarioBase, IInvestigacion
    {
        public string Departamento { get; set; }
        private int articulosPublicados;

        public Profesor() : this("Profesor Generico", "Matemáticas", 100) { }
        public Profesor(string nombre) : this(nombre, "Física", 100) { }
        public Profesor(string nombre, string depto, int id) : base(nombre, id)
        {
            Departamento = depto;
            InicializarDatos(id);
        }
        public Profesor(Profesor otro) : this(otro.NombrePersonal, otro.Departamento, 0) { }

        private void InicializarDatos(int id)
        {
            articulosPublicados = 2;
        }

        public void PublicarArticulo()
        {
            articulosPublicados++;
            Console.WriteLine($"[INVESTIGACION] {NombrePersonal} publicó un artículo. Total: {articulosPublicados}");
        }

        public override void MostrarDatos()
        {
            Console.WriteLine($"\tProfesor: {NombrePersonal}, Depto: {Departamento}, Publicaciones: {articulosPublicados}");
        }
    }

    // Clase Normal 5: Biblioteca
    public class Biblioteca : RecursoBase, IFinanzas
    {
        public string Ubicacion { get; set; }
        private double multasPendientes;

        public Biblioteca() : this("Biblioteca Central", "Centro", 50000) { }
        public Biblioteca(string nombre) : this(nombre, "Ala Sur", 50000) { }
        public Biblioteca(string nombre, string ubicacion, int libros) : base(nombre, libros)
        {
            Ubicacion = ubicacion;
            InicializarDatos();
        }
        public Biblioteca(Biblioteca otra) : this(otra.NombreRecurso, otra.Ubicacion, 0) { }

        private void InicializarDatos()
        {
            multasPendientes = 0.0;
        }

        public void PagarColegiatura()
        {
            multasPendientes = 0;
            Console.WriteLine($"[FINANZAS] Multas de biblioteca pagadas. Saldo: ${multasPendientes}.");
        }

        public override void MostrarDisponibilidad()
        {
            Console.WriteLine($"\tRecurso: {NombreRecurso}, Ubicación: {Ubicacion}");
        }
    }


    // CLASE PRINCIPAL CON MAIN
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== SISTEMA DE GESTIÓN UNIVERSITARIA COMPACTO ===");
           
            // --- PRUEBA ALUMNO (Clase y Constructores) ---
            Console.WriteLine("\n--- PRUEBA ALUMNO ---");
            
            // 1. Constructor sin parámetros
            Alumno a1 = new Alumno();
            // 3. Constructor principal (llama a InicializarDatos() una vez)
            Alumno a3 = new Alumno("Maria Lopez", "Arquitectura", 8);
            // 4. Constructor de copia
            Alumno a4 = new Alumno(a3);
            
            a3.Matricular();
            a3.MostrarProgreso();
            a4.MostrarProgreso(); // Muestra el estado inicial (copiado)

            // --- PRUEBA DE MODULOS ---
            Console.WriteLine("\n--- PRUEBA DE MODULOS Y CLASES ---");
            
            Profesor p1 = new Profesor("Dr. Elias Solis", "Ing. Sistemas", 450);
            p1.PublicarArticulo();
            p1.MostrarDatos();
            
            Materia m1 = new Materia("Cálculo Diferencial", 5, "CD-301");
            m1.Evaluar();
            m1.MostrarTemario();

            Biblioteca b1 = new Biblioteca("Hemeroteca Principal", "Piso 3", 15000);
            b1.PagarColegiatura();
        }
    }
}