using System;
using System.Text.Json;

namespace SistemaVehicular
{
    
    // 5 INTERFACES
    
    public interface IVehiculo
    {
        void Encender();
        void Apagar();
    }

    public interface IMantenimiento
    {
        void RealizarMantenimiento();
        void CambiarAceite();
    }

    public interface ISeguridad
    {
        void ActivarAlarma();
        void DesactivarAlarma();
    }

    public interface INavegacion
    {
        void ActivarGPS();
        void DesactivarGPS();
    }

    public interface ICombustible
    {
        void Recargar();
        void VerificarNivel();
    }

    
    // 5 CLASES ABSTRACTAS
    
    public abstract class VehiculoBase
    {
        public string NombreVehiculo;

        public VehiculoBase()
        {
            NombreVehiculo = "Vehiculo generico";
        }

        public VehiculoBase(string nombre)
        {
            NombreVehiculo = nombre;
        }

        public VehiculoBase(int codigo)
        {
            NombreVehiculo = "Vehiculo numero " + codigo;
        }

        public VehiculoBase(VehiculoBase otro)
        {
            NombreVehiculo = otro.NombreVehiculo;
        }

        public abstract void Describir();
    }

    public abstract class MotorBase
    {
        public string TipoMotor;

        public MotorBase()
        {
            TipoMotor = "Motor generico";
        }

        public MotorBase(string tipo)
        {
            TipoMotor = tipo;
        }

        public MotorBase(int cilindros)
        {
            TipoMotor = "Motor de " + cilindros + " cilindros";
        }

        public MotorBase(MotorBase otro)
        {
            TipoMotor = otro.TipoMotor;
        }

        public abstract void MostrarEspecificaciones();
    }

    public abstract class SistemaElectricoBase
    {
        public string TipoSistema;

        public SistemaElectricoBase()
        {
            TipoSistema = "Sistema electrico basico";
        }

        public SistemaElectricoBase(string tipo)
        {
            TipoSistema = tipo;
        }

        public SistemaElectricoBase(int voltaje)
        {
            TipoSistema = "Sistema de " + voltaje + " voltios";
        }

        public SistemaElectricoBase(SistemaElectricoBase otro)
        {
            TipoSistema = otro.TipoSistema;
        }

        public abstract void Diagnosticar();
    }

    public abstract class TransmisionBase
    {
        public string TipoTransmision;

        public TransmisionBase()
        {
            TipoTransmision = "Transmision generica";
        }

        public TransmisionBase(string tipo)
        {
            TipoTransmision = tipo;
        }

        public TransmisionBase(int velocidades)
        {
            TipoTransmision = "Transmision de " + velocidades + " velocidades";
        }

        public TransmisionBase(TransmisionBase otro)
        {
            TipoTransmision = otro.TipoTransmision;
        }

        public abstract void CambiarMarcha();
    }

    public abstract class SistemaFrenosBase
    {
        public string TipoFrenos;

        public SistemaFrenosBase()
        {
            TipoFrenos = "Frenos basicos";
        }

        public SistemaFrenosBase(string tipo)
        {
            TipoFrenos = tipo;
        }

        public SistemaFrenosBase(int potencia)
        {
            TipoFrenos = "Frenos potencia nivel " + potencia;
        }

        public SistemaFrenosBase(SistemaFrenosBase otro)
        {
            TipoFrenos = otro.TipoFrenos;
        }

       public abstract void VerificarEstado();
    }

    // 5 CLASES NORMALES

    // Clase Normal 1: CarroInteligente
    public class CarroInteligente : VehiculoBase, IVehiculo
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Color { get; set; }
        public double VelocidadMaxima { get; set; }
        public bool Encendido { get; set; }

        private double velocidadActual;
        private double combustible;
        private JsonDocument configuracion;
        private bool gpsActivo;
        private byte[] registroAudio;

        protected bool CinturonesAbrochados;
        protected bool LucesEncendidas;
        protected string ModoConduccion;
        protected int PuertasCerradas;
        protected double Kilometraje;

        public CarroInteligente() : base("Carro Generico")
        {
            Marca = "Generica";
            Modelo = "Base";
            Color = "Azul";
            VelocidadMaxima = 110;
            InicializarDatos();
        }

        public CarroInteligente(string marca, string modelo, string color, double velocidadMaxima) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Color = color;
            VelocidadMaxima = velocidadMaxima;
            InicializarDatos();
        }

        public CarroInteligente(string marca, string modelo, string color, double velocidadMaxima, double combustibleInicial) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Color = color;
            VelocidadMaxima = velocidadMaxima;
            InicializarDatos(combustibleInicial);
        }

        public CarroInteligente(CarroInteligente otro) 
            : base(otro.NombreVehiculo)
        {
            Marca = otro.Marca;
            Modelo = otro.Modelo;
            Color = otro.Color;
            VelocidadMaxima = otro.VelocidadMaxima;
            velocidadActual = otro.velocidadActual;
            combustible = otro.combustible;
            InicializarDatos(otro.combustible);
        }

        private void InicializarDatos(double valor = 100)
        {
            Encendido = false;
            velocidadActual = 0;
            combustible = valor;
            gpsActivo = false;
            registroAudio = Array.Empty<byte>();
            configuracion = JsonDocument.Parse("{}");
            ModoConduccion = "Normal";
            Kilometraje = 0;
            CinturonesAbrochados = false;
            LucesEncendidas = false;
            PuertasCerradas = 4;
        }

        public void Encender()
        {
            if (!Encendido)
            {
                Encendido = true;
                Console.WriteLine("El carro esta encendido.");
            }
            else
                Console.WriteLine("Ya estaba encendido.");
        }

        public void Apagar()
        {
            Encendido = false;
            velocidadActual = 0;
            Console.WriteLine("El carro fue apagado.");
        }

        public override void Describir()
        {
            Console.WriteLine($"{NombreVehiculo} - Marca: {Marca}, Modelo: {Modelo}, Color: {Color}");
        }
    }

    // Clase Normal 2: Motocicleta
    public class Motocicleta : VehiculoBase, IVehiculo
    {
        public string Marca { get; set; }
        public string Tipo { get; set; }
        public int Cilindrada { get; set; }
        public double VelocidadMaxima { get; set; }
        public bool Encendida { get; set; }

        private double velocidadActual;
        private double combustible;
        private string[] accesorios;
        private bool caballeteActivado;
        private byte[] historialReparaciones;

        protected bool CascoObligatorio;
        protected bool LucesEncendidas;
        protected string TipoManejo;
        protected int NivelCombustible;
        protected double KilometrajeTotal;

        public Motocicleta() : base("Motocicleta Generica")
        {
            Marca = "Generica";
            Tipo = "Standard";
            Cilindrada = 150;
            VelocidadMaxima = 120;
            InicializarDatos();
        }

        public Motocicleta(string marca, string tipo, int cilindrada, double velocidadMax) 
            : base(marca + " " + tipo)
        {
            Marca = marca;
            Tipo = tipo;
            Cilindrada = cilindrada;
            VelocidadMaxima = velocidadMax;
            InicializarDatos();
        }

        public Motocicleta(string marca, string tipo, int cilindrada, double velocidadMax, double combustibleInicial) 
            : base(marca + " " + tipo)
        {
            Marca = marca;
            Tipo = tipo;
            Cilindrada = cilindrada;
            VelocidadMaxima = velocidadMax;
            InicializarDatos(combustibleInicial);
        }

        public Motocicleta(Motocicleta otra) 
            : base(otra.NombreVehiculo)
        {
            Marca = otra.Marca;
            Tipo = otra.Tipo;
            Cilindrada = otra.Cilindrada;
            VelocidadMaxima = otra.VelocidadMaxima;
            velocidadActual = otra.velocidadActual;
            combustible = otra.combustible;
            InicializarDatos(otra.combustible);
        }

        private void InicializarDatos(double valor = 100)
        {
            Encendida = false;
            velocidadActual = 0;
            combustible = valor;
            accesorios = new string[0];
            caballeteActivado = true;
            historialReparaciones = Array.Empty<byte>();
            CascoObligatorio = true;
            LucesEncendidas = false;
            TipoManejo = "Ciudad";
            NivelCombustible = (int)valor;
            KilometrajeTotal = 0;
        }

        public void Encender()
        {
            if (!Encendida && combustible > 0)
            {
                Encendida = true;
                Console.WriteLine("La motocicleta esta encendida.");
            }
            else
                Console.WriteLine("No se puede encender.");
        }

        public void Apagar()
        {
            Encendida = false;
            velocidadActual = 0;
            Console.WriteLine("La motocicleta fue apagada.");
        }

        public override void Describir()
        {
            Console.WriteLine($"{NombreVehiculo} - Marca: {Marca}, Cilindrada: {Cilindrada}cc, Vel. Max: {VelocidadMaxima}km/h");
        }
    }

    // Clase Normal 3: Camion
    public class Camion : VehiculoBase, IMantenimiento
    {
        public string Marca { get; set; }
        public string TipoCarga { get; set; }
        public double CapacidadCarga { get; set; }
        public int NumeroEjes { get; set; }
        public bool EnFuncionamiento { get; set; }

        private double pesoActual;
        private double combustible;
        private string[] reparacionesPendientes;
        private bool necesitaMantenimiento;
        private byte[] documentosCarga;

        protected bool RemolqueConectado;
        protected bool SistemaHidraulico;
        protected string TipoMotor;
        protected int HorasUso;
        protected double KilometrajeTotal;

        public Camion() : base("Camion Generico")
        {
            Marca = "Generica";
            TipoCarga = "General";
            CapacidadCarga = 5000;
            NumeroEjes = 2;
            InicializarDatos();
        }

        public Camion(string marca, string tipoCarga, double capacidad, int ejes) 
            : base(marca + " Camion")
        {
            Marca = marca;
            TipoCarga = tipoCarga;
            CapacidadCarga = capacidad;
            NumeroEjes = ejes;
            InicializarDatos();
        }

        public Camion(string marca, string tipoCarga, double capacidad, int ejes, double combustibleInicial) 
            : base(marca + " Camion")
        {
            Marca = marca;
            TipoCarga = tipoCarga;
            CapacidadCarga = capacidad;
            NumeroEjes = ejes;
            InicializarDatos(combustibleInicial);
        }

        public Camion(Camion otro) 
            : base(otro.NombreVehiculo)
        {
            Marca = otro.Marca;
            TipoCarga = otro.TipoCarga;
            CapacidadCarga = otro.CapacidadCarga;
            NumeroEjes = otro.NumeroEjes;
            pesoActual = otro.pesoActual;
            combustible = otro.combustible;
            InicializarDatos(otro.combustible);
        }

        private void InicializarDatos(double valor = 200)
        {
            EnFuncionamiento = false;
            pesoActual = 0;
            combustible = valor;
            reparacionesPendientes = new string[0];
            necesitaMantenimiento = false;
            documentosCarga = Array.Empty<byte>();
            RemolqueConectado = false;
            SistemaHidraulico = true;
            TipoMotor = "Diesel";
            HorasUso = 0;
            KilometrajeTotal = 0;
        }

        public void RealizarMantenimiento()
        {
            necesitaMantenimiento = false;
            Console.WriteLine("Mantenimiento realizado al camion.");
        }

        public void CambiarAceite()
        {
            Console.WriteLine("Aceite del camion cambiado.");
        }

        public override void Describir()
        {
            Console.WriteLine($"{NombreVehiculo} - Marca: {Marca}, Capacidad: {CapacidadCarga}kg, Ejes: {NumeroEjes}");
        }
    }

    // Clase Normal 4: AutoDeportivo
    public class AutoDeportivo : VehiculoBase, ISeguridad
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Potencia { get; set; }
        public double Aceleracion { get; set; }
        public bool Encendido { get; set; }

        private double velocidadActual;
        private double nivelTurbo;
        private string[] modosDePista;
        private bool alarmaActiva;
        private byte[] telemetria;

        protected bool ModoDeportivo;
        protected bool AleronDesplegado;
        protected string SuspensionActiva;
        protected int RPMActuales;
        protected double TemperaturaMotor;

        public AutoDeportivo() : base("Auto Deportivo Generico")
        {
            Marca = "Generica";
            Modelo = "Sport";
            Potencia = 300;
            Aceleracion = 5.5;
            InicializarDatos();
        }

        public AutoDeportivo(string marca, string modelo, int potencia, double aceleracion) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Potencia = potencia;
            Aceleracion = aceleracion;
            InicializarDatos();
        }

        public AutoDeportivo(string marca, string modelo, int potencia, double aceleracion, double turboInicial) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Potencia = potencia;
            Aceleracion = aceleracion;
            InicializarDatos(turboInicial);
        }

        public AutoDeportivo(AutoDeportivo otro) 
            : base(otro.NombreVehiculo)
        {
            Marca = otro.Marca;
            Modelo = otro.Modelo;
            Potencia = otro.Potencia;
            Aceleracion = otro.Aceleracion;
            velocidadActual = otro.velocidadActual;
            nivelTurbo = otro.nivelTurbo;
            InicializarDatos(otro.nivelTurbo);
        }

        private void InicializarDatos(double turbo = 0)
        {
            Encendido = false;
            velocidadActual = 0;
            nivelTurbo = turbo;
            modosDePista = new string[] { "Circuito", "Drag", "Drift" };
            alarmaActiva = false;
            telemetria = Array.Empty<byte>();
            ModoDeportivo = false;
            AleronDesplegado = false;
            SuspensionActiva = "Confort";
            RPMActuales = 0;
            TemperaturaMotor = 20;
        }

        public void ActivarAlarma()
        {
            alarmaActiva = true;
            Console.WriteLine("Alarma del auto deportivo activada.");
        }

        public void DesactivarAlarma()
        {
            alarmaActiva = false;
            Console.WriteLine("Alarma del auto deportivo desactivada.");
        }

        public override void Describir()
        {
            Console.WriteLine($"{NombreVehiculo} - Marca: {Marca}, Potencia: {Potencia}HP, 0-100: {Aceleracion}seg");
        }
    }

    // Clase Normal 5: AutoElectrico
    public class AutoElectrico : VehiculoBase, ICombustible
    {
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public int Autonomia { get; set; }
        public double TiempoCarga { get; set; }
        public bool Encendido { get; set; }

        private double bateriaActual;
        private double eficienciaEnergetica;
        private string[] estacionesCarga;
        private bool cargandoRapido;
        private byte[] historialCargas;

        protected bool ModoEco;
        protected bool RegeneracionFrenado;
        protected string TipoBateria;
        protected int CiclosRecarga;
        protected double ConsumoPromedio;

        public AutoElectrico() : base("Auto Electrico Generico")
        {
            Marca = "Generica";
            Modelo = "EV";
            Autonomia = 300;
            TiempoCarga = 8;
            InicializarDatos();
        }

        public AutoElectrico(string marca, string modelo, int autonomia, double tiempoCarga) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Autonomia = autonomia;
            TiempoCarga = tiempoCarga;
            InicializarDatos();
        }

        public AutoElectrico(string marca, string modelo, int autonomia, double tiempoCarga, double bateriaInicial) 
            : base(marca + " " + modelo)
        {
            Marca = marca;
            Modelo = modelo;
            Autonomia = autonomia;
            TiempoCarga = tiempoCarga;
            InicializarDatos(bateriaInicial);
        }

        public AutoElectrico(AutoElectrico otro) 
            : base(otro.NombreVehiculo)
        {
            Marca = otro.Marca;
            Modelo = otro.Modelo;
            Autonomia = otro.Autonomia;
            TiempoCarga = otro.TiempoCarga;
            bateriaActual = otro.bateriaActual;
            eficienciaEnergetica = otro.eficienciaEnergetica;
            InicializarDatos(otro.bateriaActual);
        }

        private void InicializarDatos(double bateria = 100)
        {
            Encendido = false;
            bateriaActual = bateria;
            eficienciaEnergetica = 95;
            estacionesCarga = new string[0];
            cargandoRapido = false;
            historialCargas = Array.Empty<byte>();
            ModoEco = true;
            RegeneracionFrenado = true;
            TipoBateria = "Litio-Ion";
            CiclosRecarga = 0;
            ConsumoPromedio = 15;
        }

        public void Recargar()
        {
            bateriaActual = 100;
            CiclosRecarga++;
            Console.WriteLine("Auto electrico recargado completamente.");
        }

        public void VerificarNivel()
        {
            Console.WriteLine($"Nivel de bateria: {bateriaActual}%, Autonomia restante: {(Autonomia * bateriaActual / 100)}km");
        }

        public override void Describir()
        {
            Console.WriteLine($"{NombreVehiculo} - Marca: {Marca}, Autonomia: {Autonomia}km, Tiempo carga: {TiempoCarga}h");
        }
    }

    
    // CLASE PRINCIPAL CON MAIN
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("SISTEMA VEHICULAR COMPLETO");
        

            Console.WriteLine("PRUEBA DE CARRO INTELIGENTE");
            
            CarroInteligente carro1 = new CarroInteligente();
            CarroInteligente carro2 = new CarroInteligente("Toyota", "Corolla", "Rojo", 220);
            CarroInteligente carro3 = new CarroInteligente("Honda", "Civic", "Azul", 200, 75);
            CarroInteligente carro4 = new CarroInteligente(carro2);
            
            carro1.Describir();
            carro2.Describir();
            carro2.Encender();
            carro2.Apagar();

            Console.WriteLine("PRUEBA DE MOTOCICLETA");
            
            Motocicleta moto1 = new Motocicleta();
            Motocicleta moto2 = new Motocicleta("Yamaha", "Deportiva", 600, 280);
            Motocicleta moto3 = new Motocicleta("Honda", "Cruiser", 750, 180, 80);
            Motocicleta moto4 = new Motocicleta(moto2);
            
            moto1.Describir();
            moto2.Describir();
            moto2.Encender();
            moto2.Apagar();

            Console.WriteLine("PRUEBA DE CAMION");
            
            Camion camion1 = new Camion();
            Camion camion2 = new Camion("Volvo", "Carga pesada", 15000, 4);
            Camion camion3 = new Camion("Scania", "Refrigerado", 12000, 3, 250);
            Camion camion4 = new Camion(camion2);
            
            camion1.Describir();
            camion2.Describir();
            camion2.RealizarMantenimiento();
            camion2.CambiarAceite();

            Console.WriteLine("PRUEBA DE AUTO DEPORTIVO");
        
            AutoDeportivo deportivo1 = new AutoDeportivo();
            AutoDeportivo deportivo2 = new AutoDeportivo("Ferrari", "F8", 720, 2.9);
            AutoDeportivo deportivo3 = new AutoDeportivo("Porsche", "911", 650, 3.2, 50);
            AutoDeportivo deportivo4 = new AutoDeportivo(deportivo2);
            
            deportivo1.Describir();
            deportivo2.Describir();
            deportivo2.ActivarAlarma();
            deportivo2.DesactivarAlarma();

            Console.WriteLine("PRUEBA DE AUTO ELECTRICO");
    
            AutoElectrico electrico1 = new AutoElectrico();
            AutoElectrico electrico2 = new AutoElectrico("Tesla", "Model 3", 500, 6);
            AutoElectrico electrico3 = new AutoElectrico("Nissan", "Leaf", 350, 7, 85);
            AutoElectrico electrico4 = new AutoElectrico(electrico2);
            
            electrico1.Describir();
            electrico2.Describir();
            electrico2.VerificarNivel();
            electrico2.Recargar();

        }
    }
}




