using System;
using System.Text.Json;

namespace SistemaTiendaRopa
{
    // =================================================================
    // 5 INTERFACES (Contratos)
    // =================================================================
    
    public interface IComercio
    {
        void Abrir();
        void Cerrar();
    }

    public interface IVentas
    {
        void RegistrarVenta();
        void AnularVenta();
    }

    public interface IInventario
    {
        void AgregarStock();
        void ReducirStock();
    }

    public interface ICliente
    {
        void RegistrarCliente();
        void ActualizarPuntos();
    }

    public interface IProveedor
    {
        void HacerPedido();
        void RecibirMercancia();
    }

    
    // =================================================================
    // 5 CLASES ABSTRACTAS (Optimización: Encadenamiento estricto a Constructor Principal)
    // =================================================================
    
    public abstract class NegocioBase
    {
        public string NombreNegocio;

        // 1. Constructor sin parámetros: Delega al 3
        public NegocioBase() : this("Negocio gastronomico generico", 0) { }

        // 2. Constructor sobrecargado (string): Delega al 3
        public NegocioBase(string nombre) : this(nombre, 0) { }

        // 3. Constructor principal (string, int): Lógica central
        public NegocioBase(string nombre, int codigo)
        {
            NombreNegocio = (codigo > 0) ? $"Negocio numero {codigo} - {nombre}" : nombre;
        }

        // 4. Constructor de Copia: Delega al 3
        public NegocioBase(NegocioBase otro) : this(otro.NombreNegocio, 0) { }

        public abstract void MostrarInformacion();
    }

    public abstract class ProductoBase
    {
        public string NombreProducto;

        public ProductoBase() : this("Producto generico", 0) { }
        public ProductoBase(string nombre) : this(nombre, 0) { }
        public ProductoBase(string nombre, int codigo)
        {
            NombreProducto = (codigo > 0) ? $"Producto codigo {codigo} - {nombre}" : nombre;
        }
        public ProductoBase(ProductoBase otro) : this(otro.NombreProducto, 0) { }

        public abstract void MostrarDetalles();
    }

    public abstract class PersonalBase
    {
        public string NombrePersonal;

        public PersonalBase() : this("Personal sin nombre", 0) { }
        public PersonalBase(string nombre) : this(nombre, 0) { }
        public PersonalBase(string nombre, int id)
        {
            NombrePersonal = (id > 0) ? $"Personal ID {id} - {nombre}" : nombre;
        }
        public PersonalBase(PersonalBase otro) : this(otro.NombrePersonal, 0) { }

        public abstract void MostrarDatos();
    }

    public abstract class ClienteBase
    {
        public string NombreCliente;

        public ClienteBase() : this("Cliente sin nombre", 0) { }
        public ClienteBase(string nombre) : this(nombre, 0) { }
        public ClienteBase(string nombre, int id)
        {
            NombreCliente = (id > 0) ? $"Cliente ID {id} - {nombre}" : nombre;
        }
        public ClienteBase(ClienteBase otro) : this(otro.NombreCliente, 0) { }

        public abstract void MostrarPerfil();
    }

    public abstract class DistribuidorBase
    {
        public string NombreDistribuidor;

        public DistribuidorBase() : this("Distribuidor generico", 0) { }
        public DistribuidorBase(string nombre) : this(nombre, 0) { }
        public DistribuidorBase(string nombre, int id)
        {
            NombreDistribuidor = (id > 0) ? $"Distribuidor ID {id} - {nombre}" : nombre;
        }
        public DistribuidorBase(DistribuidorBase otro) : this(otro.NombreDistribuidor, 0) { }

        public abstract void MostrarInfo();
    }

    
    // =================================================================
    // 5 CLASES NORMALES (Optimización: Encadenamiento + Inicialización única)
    // =================================================================
    

    // Clase Normal 1: TiendaRopa
    public class TiendaRopa : NegocioBase, IComercio
    {
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public bool Abierta { get; set; }
        public int Empleados { get; set; }

        private double ingresosDiarios;
        private int prendasVendidas;
        private bool sistemaActivo;
        private byte[] logoTienda;
        private JsonDocument catalogoJSON;

        protected string ProveedorPrincipal;
        protected double PrecioPromedio;
        protected int StockDisponible;
        protected bool PromocionActiva;
        protected string TipoTienda;

        // Método privado: Contiene la inicialización de campos no pasados
        private void InicializarDatos(int codigo = 0)
        {
            // Inicialización de campos de estado y protegidos por defecto
            Abierta = false;
            ingresosDiarios = 0;
            prendasVendidas = 0;
            sistemaActivo = true;
            logoTienda = Array.Empty<byte>();
            // Usamos codigo para modificar el título base en el constructor
            catalogoJSON = JsonDocument.Parse("{\"catalogo\": \"Vacio\"}");
            ProveedorPrincipal = "Textiles Andina";
            StockDisponible = 300;
            TipoTienda = "Moda Casual";
        }

        // 1. Constructor sin parámetros: Delega al 3 con valores por defecto
        public TiendaRopa() 
            : this("Tienda Sin Nombre", "Sin direccion", "Sin encargado", 4)
        {
            // El nombre base se ajusta si se llama sin parámetros
            base.NombreNegocio = "Tienda Generica";
        }

        // 2. Constructor sobrecargado (3 parámetros): Delega al 3
        public TiendaRopa(string nombre, string direccion, string encargado) 
            : this(nombre, direccion, encargado, 4)
        {
        }
        
        // 3. Constructor Principal: Llama a base() y a InicializarDatos() solo aquí
        public TiendaRopa(string nombre, string direccion, string encargado, int empleados, int codigo = 0) 
            : base(nombre, codigo) // Llama al constructor base con nombre y código (si existe)
        {
            Nombre = nombre;
            Direccion = direccion;
            Encargado = encargado;
            Empleados = empleados;
            InicializarDatos(codigo); // La inicialización se llama SOLO AQUÍ
        }

        // 4. Constructor de Copia: Delega al 3, luego copia el estado interno mutable
        public TiendaRopa(TiendaRopa otra) 
            : this(otra.Nombre, otra.Direccion, otra.Encargado, otra.Empleados)
        {
            // Copia explícita de campos de estado internos (privados)
            ingresosDiarios = otra.ingresosDiarios;
            prendasVendidas = otra.prendasVendidas;
            // Otros campos privados/protegidos deben copiarse si es necesario.
        }

        // Implementación de la interfaz IComercio
        public void Abrir()
        {
            Abierta = true;
            Console.WriteLine($"{Nombre} ha abierto al publico.");
        }

        public void Cerrar()
        {
            Abierta = false;
            Console.WriteLine($"{Nombre} ha cerrado.");
        }

        public override void MostrarInformacion()
        {
            Console.WriteLine($"[Tienda] {NombreNegocio} - Encargado: {Encargado}, Tipo: {TipoTienda}");
        }

        // Método de prueba adicional
        public void MostrarEstado()
        {
             Console.WriteLine("\n--- Estado de la Tienda ---");
             Console.WriteLine($"Nombre: {Nombre}");
             Console.WriteLine($"Estado: {(Abierta ? "Abierta" : "Cerrada")}");
             Console.WriteLine($"Stock disponible: {StockDisponible}");
             Console.WriteLine($"Ingresos del dia: ${ingresosDiarios}");
        }
    }

    // Clase Normal 2: Boutique
    public class Boutique : NegocioBase, IComercio
    {
        public string Nombre { get; set; }
        public string Ubicacion { get; set; }
        public string Disenador { get; set; }
        public bool Operando { get; set; }
        public int PersonalActivo { get; set; }

        private double ventasMensuales;
        private int clientesVIP;
        protected string EstiloTienda;

        private void InicializarDatos(int codigo = 0)
        {
            Operando = false;
            ventasMensuales = 0;
            clientesVIP = 0;
            EstiloTienda = "Alta Costura";
        }

        public Boutique() : this("Boutique Sin Nombre", "Sin ubicacion", "Sin disenador", 3)
        {
            base.NombreNegocio = "Boutique Generica";
        }
        public Boutique(string nombre, string ubicacion, string disenador) 
            : this(nombre, ubicacion, disenador, 3)
        {
        }
        public Boutique(string nombre, string ubicacion, string disenador, int personal, int codigo = 0) 
            : base(nombre, codigo)
        {
            Nombre = nombre;
            Ubicacion = ubicacion;
            Disenador = disenador;
            PersonalActivo = personal;
            InicializarDatos(codigo); // Llamada única
        }
        public Boutique(Boutique otra) 
            : this(otra.Nombre, otra.Ubicacion, otra.Disenador, otra.PersonalActivo)
        {
            ventasMensuales = otra.ventasMensuales;
        }

        public void Abrir()
        {
            Operando = true;
            Console.WriteLine($"{Nombre} esta abierta.");
        }
        public void Cerrar()
        {
            Operando = false;
            Console.WriteLine($"{Nombre} esta cerrada.");
        }
        public override void MostrarInformacion()
        {
            Console.WriteLine($"[Boutique] {NombreNegocio} - Disenador: {Disenador}");
        }
    }

    // Clase Normal 3: Prenda
    public class Prenda : ProductoBase, IInventario
    {
        public string Nombre { get; set; }
        public string Categoria { get; set; }
        public string Talla { get; set; }
        public double Precio { get; set; }

        private int unidadesStock;
        protected string Material;

        private void InicializarDatos(int stock = 50, int codigo = 0)
        {
            unidadesStock = stock;
            Material = "Algodon";
        }

        public Prenda() : this("Sin nombre", "General", "M", 0, 50)
        {
            base.NombreProducto = "Prenda Generica";
        }

        public Prenda(string nombre, string categoria, string talla, double precio) 
            : this(nombre, categoria, talla, precio, 50)
        {
        }

        // Constructor Principal
        public Prenda(string nombre, string categoria, string talla, double precio, int stock, int codigo = 0) 
            : base(nombre, codigo)
        {
            Nombre = nombre;
            Categoria = categoria;
            Talla = talla;
            Precio = precio;
            InicializarDatos(stock, codigo); // Llamada única
        }

        public Prenda(Prenda otra) 
            : this(otra.Nombre, otra.Categoria, otra.Talla, otra.Precio, otra.unidadesStock)
        {
        }

        public void AgregarStock()
        {
            unidadesStock += 20;
            Console.WriteLine($"Stock de {Nombre} incrementado a {unidadesStock}.");
        }

        public void ReducirStock()
        {
            if (unidadesStock > 0)
            {
                unidadesStock--;
                Console.WriteLine($"Stock de {Nombre} reducido a {unidadesStock}.");
            }
        }

        public override void MostrarDetalles()
        {
            Console.WriteLine($"[Prenda] {NombreProducto} - Talla: {Talla}, Precio: ${Precio}, Stock: {unidadesStock}");
        }
    }

    // Clase Normal 4: Vendedor
    public class Vendedor : PersonalBase, IVentas
    {
        public string Nombre { get; set; }
        public string Turno { get; set; }
        public int Experiencia { get; set; }
        public double Salario { get; set; }

        private int ventasRealizadas;
        protected string Categoria;

        private void InicializarDatos(int id = 0)
        {
            ventasRealizadas = 0;
            Categoria = "Junior";
        }

        public Vendedor() : this("Sin nombre", "Diurno", 0, 1500000)
        {
            base.NombrePersonal = "Vendedor sin nombre";
        }
        public Vendedor(string nombre, string turno, int experiencia, double salario) 
            : this(nombre, turno, experiencia, salario, 0)
        {
        }

        // Constructor Principal
        public Vendedor(string nombre, string turno, int experiencia, double salario, int id) 
            : base(nombre, id)
        {
            Nombre = nombre;
            Turno = turno;
            Experiencia = experiencia;
            Salario = salario;
            InicializarDatos(id); // Llamada única
        }

        public Vendedor(Vendedor otro) 
            : this(otro.Nombre, otro.Turno, otro.Experiencia, otro.Salario)
        {
            ventasRealizadas = otro.ventasRealizadas;
        }

        public void RegistrarVenta()
        {
            ventasRealizadas++;
            Console.WriteLine($"{Nombre} ha registrado una venta.");
        }

        public void AnularVenta()
        {
            if (ventasRealizadas > 0)
            {
                ventasRealizadas--;
                Console.WriteLine($"{Nombre} ha anulado una venta.");
            }
        }

        public override void MostrarDatos()
        {
            Console.WriteLine($"[Vendedor] {NombrePersonal} - Turno: {Turno}, Ventas: {ventasRealizadas}");
        }
    }

    // Clase Normal 5: Proveedor
    public class Proveedor : DistribuidorBase, IProveedor
    {
        public string NombreEmpresa { get; set; }
        public string TipoMercancia { get; set; }
        public string Contacto { get; set; }
        public int TiempoEntrega { get; set; }

        private int pedidosRealizados;
        protected string CalidadProducto;

        private void InicializarDatos(int id = 0)
        {
            pedidosRealizados = 0;
            CalidadProducto = "Alta";
        }

        public Proveedor() : this("Sin nombre", "General", "Sin contacto", 5)
        {
            base.NombreDistribuidor = "Proveedor Generico";
        }
        public Proveedor(string empresa, string tipo, string contacto) 
            : this(empresa, tipo, contacto, 5)
        {
        }

        // Constructor Principal
        public Proveedor(string empresa, string tipo, string contacto, int tiempoEntrega, int id = 0) 
            : base(empresa, id)
        {
            NombreEmpresa = empresa;
            TipoMercancia = tipo;
            Contacto = contacto;
            TiempoEntrega = tiempoEntrega;
            InicializarDatos(id); // Llamada única
        }

        public Proveedor(Proveedor otro) 
            : this(otro.NombreEmpresa, otro.TipoMercancia, otro.Contacto, otro.TiempoEntrega)
        {
            pedidosRealizados = otro.pedidosRealizados;
        }

        public void HacerPedido()
        {
            pedidosRealizados++;
            Console.WriteLine($"Pedido realizado a {NombreEmpresa}.");
        }

        public void RecibirMercancia()
        {
            Console.WriteLine($"Mercancia recibida de {NombreEmpresa}.");
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"[Proveedor] {NombreDistribuidor} - Tipo: {TipoMercancia}, Pedidos: {pedidosRealizados}");
        }
    }


    // CLASE PRINCIPAL CON MAIN para probar todas las clases
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=================================================");
            Console.WriteLine("SISTEMA DE TIENDA DE ROPA (CONSTRUCTORES OPTIMIZADOS)");
            Console.WriteLine("=================================================");

            // --- PRUEBA DE TiendaRopa ---
            Console.WriteLine("\n--- PRUEBA DE TiendaRopa (Encadenamiento) ---");
            
            // 1. Constructor sin parámetros
            TiendaRopa t1 = new TiendaRopa();
            // 2. Constructor sobrecargado (3 parámetros)
            TiendaRopa t2 = new TiendaRopa("UrbanStyle", "Av. Central #45-20", "Maria Torres");
            // 3. Constructor principal (4 parámetros + 1 opcional)
            TiendaRopa t3 = new TiendaRopa("Fashion Store", "Calle 80 #10-15", "Carlos Ruiz", 8, 101); // Con código
            // 4. Constructor de copia
            TiendaRopa t4 = new TiendaRopa(t3); // Copia t3
            
            t3.Abrir();
            t3.MostrarInformacion(); 
            t3.MostrarEstado();

            Console.WriteLine("\n--- PRUEBA DE Prenda (Encadenamiento) ---");
            Prenda p1 = new Prenda();
            Prenda p2 = new Prenda("Vestido Casual", "Vestidos", "S", 150000, 30);
            Prenda p3 = new Prenda(p2); // Copia p2
            
            p2.MostrarDetalles();
            p2.AgregarStock();
            p3.MostrarDetalles(); // Muestra el stock inicial (30)

            Console.WriteLine("\n--- PRUEBA DE Vendedor y Proveedor ---");
            Vendedor v1 = new Vendedor("Laura Gomez", "Diurno", 3, 2000000, 501);
            v1.RegistrarVenta();
            v1.MostrarDatos();

            Proveedor pr1 = new Proveedor("Textiles Andina", "Telas", "contacto@textiles.com", 3, 200);
            pr1.HacerPedido();
            pr1.MostrarInfo();
        }
    }
}