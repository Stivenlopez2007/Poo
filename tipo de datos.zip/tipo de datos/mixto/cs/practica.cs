using System;

namespace SistemaHospitalarioCompacto
{
    // ================== 5 INTERFACES (Contratos) ==================

    public interface IAdmision { void Admitir(); }
    public interface ITratamiento { void Tratar(); }
    public interface IEmergencia { void Triage(); }
    public interface IRecursos { void Solicitar(); }
    public interface IHorarios { void AsignarTurno(); }

    
    // ================== 5 CLASES ABSTRACTAS (Bases con 4 Constructores Chained) ==================

    public abstract class PersonaHospitalBase
    {
        public string NombreCompleto;

        // 1. Constructor sin parámetros: Delega al 3
        public PersonaHospitalBase() : this("Anonimo", 0) { }

        // 2. Constructor sobrecargado (string): Delega al 3
        public PersonaHospitalBase(string nombre) : this(nombre, 0) { }

        // 3. Constructor principal (string, int): Lógica central
        public PersonaHospitalBase(string nombre, int id)
        {
            NombreCompleto = (id > 0) ? $"ID {id} - {nombre}" : nombre;
        }

        // 4. Constructor de Copia: Delega al 3
        public PersonaHospitalBase(PersonaHospitalBase otro) : this(otro.NombreCompleto, 0) { }

        public abstract void MostrarInfo();
    }

    public abstract class DepartamentoBase
    {
        public string NombreDepartamento;

        public DepartamentoBase() : this("Generico", "GNR") { }
        public DepartamentoBase(string nombre) : this(nombre, "GNR") { }
        public DepartamentoBase(string nombre, string codigo)
        {
            NombreDepartamento = (codigo != "GNR") ? $"{codigo} - {nombre}" : nombre;
        }
        public DepartamentoBase(DepartamentoBase otro) : this(otro.NombreDepartamento, "GNR") { }

        public abstract void MostrarProtocolos();
    }

    public abstract class EquipoMedicoBase
    {
        public string NombreEquipo;

        public EquipoMedicoBase() : this("Equipo Generico", 0) { }
        public EquipoMedicoBase(string nombre) : this(nombre, 0) { }
        public EquipoMedicoBase(string nombre, int noSerie)
        {
            NombreEquipo = (noSerie > 0) ? $"Serie {noSerie} - {nombre}" : nombre;
        }
        public EquipoMedicoBase(EquipoMedicoBase otro) : this(otro.NombreEquipo, 0) { }

        public abstract void VerificarEstado();
    }

    public abstract class MedicamentoBase
    {
        public string NombreComercial;

        public MedicamentoBase() : this("Farmaco generico", 0) { }
        public MedicamentoBase(string nombre) : this(nombre, 0) { }
        public MedicamentoBase(string nombre, int dosisMg)
        {
            NombreComercial = (dosisMg > 0) ? $"{nombre} ({dosisMg}mg)" : nombre;
        }
        public MedicamentoBase(MedicamentoBase otro) : this(otro.NombreComercial, 0) { }

        public abstract void MostrarAdvertencias();
    }

    public abstract class CamaBase
    {
        public string NumeroCama;

        public CamaBase() : this("No Asignada", 0) { }
        public CamaBase(string numero) : this(numero, 0) { }
        public CamaBase(string numero, int piso)
        {
            NumeroCama = (piso > 0) ? $"Cama {numero} - Piso {piso}" : numero;
        }
        public CamaBase(CamaBase otra) : this(otra.NumeroCama, 0) { }

        public abstract void MostrarOcupacion();
    }


    // ================== 5 CLASES NORMALES (Implementación y Chaining) ==================

    // Clase Normal 1: Paciente
    public class Paciente : PersonaHospitalBase, IAdmision
    {
        public string Sintoma { get; set; }
        private bool hospitalizado;

        // 1. Constructor sin parámetros: Delega al 3
        public Paciente() : this("Sin Nombre", "Generico", 30) { }

        // 2. Constructor sobrecargado: Delega al 3
        public Paciente(string nombre) : this(nombre, "Dolor", 30) { }

        // 3. Constructor principal: Inicialización única
        public Paciente(string nombre, string sintoma, int edad) : base(nombre, edad)
        {
            Sintoma = sintoma;
            InicializarDatos();
        }

        // 4. Constructor de Copia: Delega al 3
        public Paciente(Paciente otro) : this(otro.NombreCompleto, otro.Sintoma, 0) { }

        private void InicializarDatos()
        {
            hospitalizado = false;
        }

        public void Admitir()
        {
            hospitalizado = true;
            Console.WriteLine($"[ADMISION] {NombreCompleto} admitido por {Sintoma}.");
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"\tPaciente: {NombreCompleto}, Estado: {(hospitalizado ? "Hospitalizado" : "De Alta")}");
        }
    }

    // Clase Normal 2: Medico
    public class Medico : PersonaHospitalBase, ITratamiento
    {
        public string Especialidad { get; set; }
        private bool deTurno;

        public Medico() : this("Dr. Generico", "General", 0) { }
        public Medico(string nombre) : this(nombre, "General", 0) { }
        public Medico(string nombre, string especialidad, int pacientes) : base(nombre, pacientes)
        {
            Especialidad = especialidad;
            InicializarDatos();
        }
        public Medico(Medico otro) : this(otro.NombreCompleto, otro.Especialidad, 0) { }

        private void InicializarDatos() { deTurno = true; }

        public void Tratar()
        {
            Console.WriteLine($"[TRATAMIENTO] {NombreCompleto} ({Especialidad}) está tratando al paciente.");
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"\tMédico: {NombreCompleto}, De Turno: {deTurno}");
        }
    }

    // Clase Normal 3: SalaEmergencia
    public class SalaEmergencia : DepartamentoBase, IEmergencia
    {
        public int CamillasOcupadas { get; set; }
        private int medicosPresentes;

        public SalaEmergencia() : this("Urgencias", 0) { }
        public SalaEmergencia(string nombre) : this(nombre, 0) { }
        public SalaEmergencia(string nombre, int capacidad) : base(nombre, "EM")
        {
            CamillasOcupadas = capacidad;
            InicializarDatos();
        }
        public SalaEmergencia(SalaEmergencia otra) : this(otra.NombreDepartamento, 0) { }

        private void InicializarDatos() { medicosPresentes = 3; }

        public void Triage()
        {
            CamillasOcupadas++;
            Console.WriteLine($"[EMERGENCIA] Paciente en triage. Ocupación: {CamillasOcupadas}.");
        }

        public override void MostrarProtocolos()
        {
            Console.WriteLine($"\tDepartamento: {NombreDepartamento}. Médicos: {medicosPresentes}.");
        }
    }

    // Clase Normal 4: MonitorCardiaco
    public class MonitorCardiaco : EquipoMedicoBase, IRecursos
    {
        public string Modelo { get; set; }
        private bool encendido;

        public MonitorCardiaco() : this("Monitor", "XYZ", 0) { }
        public MonitorCardiaco(string nombre) : this(nombre, "XYZ", 0) { }
        public MonitorCardiaco(string nombre, string modelo, int bateria) : base(nombre, 0)
        {
            Modelo = modelo;
            InicializarDatos();
        }
        public MonitorCardiaco(MonitorCardiaco otro) : this(otro.NombreEquipo, otro.Modelo, 0) { }

        private void InicializarDatos() { encendido = true; }

        public void Solicitar()
        {
            Console.WriteLine($"[RECURSOS] {NombreEquipo} solicita revisión técnica.");
        }

        public override void VerificarEstado()
        {
            Console.WriteLine($"\tEquipo: {NombreEquipo}, Modelo: {Modelo}, Encendido: {encendido}.");
        }
    }

    // Clase Normal 5: Enfermera
    public class Enfermera : PersonaHospitalBase, IHorarios
    {
        public string AreaAsignada { get; set; }
        private string turno;

        public Enfermera() : this("E. Generica", "UCI", 0) { }
        public Enfermera(string nombre) : this(nombre, "UCI", 0) { }
        public Enfermera(string nombre, string area, int experiencia) : base(nombre, experiencia)
        {
            AreaAsignada = area;
            InicializarDatos();
        }
        public Enfermera(Enfermera otra) : this(otra.NombreCompleto, otra.AreaAsignada, 0) { }

        private void InicializarDatos() { turno = "Diurno"; }

        public void AsignarTurno()
        {
            turno = "Nocturno";
            Console.WriteLine($"[HORARIOS] {NombreCompleto} cambia a turno {turno}.");
        }

        public override void MostrarInfo()
        {
            Console.WriteLine($"\tEnfermera: {NombreCompleto}, Turno: {turno}, Área: {AreaAsignada}.");
        }
    }


    // CLASE PRINCIPAL CON MAIN
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== SISTEMA HOSPITALARIO COMPACTO (C#) ===");
           
            // --- PRUEBA DE CLASE CONCRETA: Paciente ---
            Console.WriteLine("\n--- PRUEBA PACIENTE (Clase y Constructores) ---");
            
            // 1. Constructor sin parámetros
            Paciente p1 = new Paciente();
            // 2. Constructor sobrecargado
            Paciente p2 = new Paciente("Sara Castro");
            // 3. Constructor principal (llama a InicializarDatos())
            Paciente p3 = new Paciente("Luis Perez", "Fiebre Alta", 58);
            // 4. Constructor de copia
            Paciente p4 = new Paciente(p3);
            
            p3.Admitir();
            p3.MostrarInfo();
            p4.MostrarInfo(); // Muestra el estado inicial (copiado)

            // --- PRUEBA DE IMPLEMENTACIÓN DE INTERFACES ---
            Console.WriteLine("\n--- PRUEBA DE MODULOS ---");
            
            Medico m1 = new Medico("Dr. Juan Valdez", "Pediatría", 10);
            m1.Tratar();
            
            SalaEmergencia s1 = new SalaEmergencia("Unidad Trauma", 4, "UT-2");
            s1.Triage();
            s1.MostrarProtocolos();

            Enfermera e1 = new Enfermera("Diana Rojas", "Quirófano", 5);
            e1.AsignarTurno();
        }
    }
}