ppackage main

import (
	"encoding/json"
	"fmt"
	"time"
)

// =================================================================
// 1. INTERFACES (Definición de Contratos)
// =================================================================

// TransactionRecorder define las operaciones para registrar movimientos.
type TransactionRecorder interface {
	RegistrarIngreso(monto float64, categoria string)
	RegistrarGasto(monto float64, categoria string)
}

// FinancialAnalyzer define las operaciones para calcular y mostrar métricas.
type FinancialAnalyzer interface {
	CalcularPromedioGasto()
	CalcularAhorroMensual()
	MostrarResumen()
}

// =================================================================
// 2. CLASE BASE (Simulando con Composición - MetricsBase)
// =================================================================

// FinancialMetricsBase actúa como la "Clase Base Abstracta", conteniendo
// las métricas financieras internas (o "protegidas").
type FinancialMetricsBase struct {
	_FechaInicio    time.Time
	_TotalGastos    float64
	_AhorroMensual  float64
	_LimiteGasto    float64
	_PromedioGasto  float64
}

// NewFinancialMetricsBase es la función factory para inicializar la base.
func NewFinancialMetricsBase() FinancialMetricsBase {
	return FinancialMetricsBase{
		_FechaInicio: time.Now(),
		_LimiteGasto: 0.0,
	}
}

// GetTiempoTranscurrido es un método de la clase base.
func (b *FinancialMetricsBase) GetTiempoTranscurrido() string {
	dias := int(time.Since(b._FechaInicio).Hours() / 24)
	return fmt.Sprintf("Tiempo de seguimiento: %d días.", dias)
}

// =================================================================
// 3. ESTRUCTURA PRINCIPAL (Simulando Clase Concreta)
// =================================================================

// SeguimientoFinancieroRefactor es la estructura principal que usa composición.
type SeguimientoFinancieroRefactor struct {
	FinancialMetricsBase // Composición (simula herencia)

	// --- Públicos ---
	NombreUsuario   string
	Moneda          string
	SaldoActual     float64
	IngresosTotales float64
	Activo          bool

	// --- Privados ---
	gastosRegistrados   []float64
	ingresosRegistrados []float64
	categoriasGasto     map[string]float64
	ultimoMovimiento    time.Time
	configuracion       map[string]interface{}
}

// =================================================================
// 4. FUNCIONES FACTORY (Simulando los 4 Constructores)
// =================================================================

// 4.1. Factory "Sin Parámetros" (NewSeguimientoFinancieroDefault)
// Inicializa con valores predeterminados.
func NewSeguimientoFinancieroDefault() *SeguimientoFinancieroRefactor {
	return &SeguimientoFinancieroRefactor{
		FinancialMetricsBase: NewFinancialMetricsBase(), // Inicializa la base
		NombreUsuario:        "Invitado",
		Moneda:               "N/A",
		SaldoActual:          0.0,
		Activo:               false,
		gastosRegistrados:    make([]float64, 0),
		ingresosRegistrados:  make([]float64, 0),
		categoriasGasto:      make(map[string]float64),
		configuracion:        make(map[string]interface{}),
		ultimoMovimiento:     time.Now(),
	}
}

// 4.2. Factory "Con Parámetros Esenciales" (NewSeguimientoFinanciero)
// Simula el constructor original, inicializando los campos clave.
func NewSeguimientoFinanciero(nombre, moneda string, saldoInicial float64) *SeguimientoFinancieroRefactor {
	// Reúsa el constructor default y lo personaliza
	s := NewSeguimientoFinancieroDefault()
	s.NombreUsuario = nombre
	s.Moneda = moneda
	s.SaldoActual = saldoInicial
	s.Activo = true
	s.ultimoMovimiento = time.Now()
	return s
}

// 4.3. Factory "Sobrecargado" / Completo (NewSeguimientoFinancieroFull)
// Inicializa con saldo, límite y configuración inicial.
func NewSeguimientoFinancieroFull(nombre, moneda string, saldoInicial, limiteGasto float64, cfg map[string]interface{}) *SeguimientoFinancieroRefactor {
	s := NewSeguimientoFinanciero(nombre, moneda, saldoInicial) // Usa el factory simple
	s.FinancialMetricsBase._LimiteGasto = limiteGasto          // Establece campo de la base
	s.configuracion = cfg
	fmt.Printf("Configuración inicial aplicada para %s.\n", nombre)
	return s
}

// 4.4. Factory "Copia" (NewSeguimientoFinancieroCopy)
// Crea una nueva instancia copiando el estado de la original.
func NewSeguimientoFinancieroCopy(original *SeguimientoFinancieroRefactor) *SeguimientoFinancieroRefactor {
	// 1. Crear una copia de la estructura (incluye FinancialMetricsBase por valor)
	copia := *original

	// 2. Realizar copias profundas de slices y maps (CRÍTICO para evitar referencias compartidas)
	copia.gastosRegistrados = append([]float64{}, original.gastosRegistrados...)
	copia.ingresosRegistrados = append([]float64{}, original.ingresosRegistrados...)

	copia.categoriasGasto = make(map[string]float64)
	for k, v := range original.categoriasGasto {
		copia.categoriasGasto[k] = v
	}
	copia.configuracion = make(map[string]interface{})
	for k, v := range original.configuracion {
		copia.configuracion[k] = v
	}

	// 3. Modificar campos de la copia para distinguirla
	copia.NombreUsuario = original.NombreUsuario + "_Auditoría"
	copia.Activo = false // La copia de auditoría es inactiva
	copia.FinancialMetricsBase._FechaInicio = time.Now() // La copia tiene su propia fecha
	copia.ultimoMovimiento = time.Now()

	return &copia
}

// =================================================================
// 5. MÉTODOS DE ACCIÓN (Implementando Interfaces)
// =================================================================

// RegistrarIngreso suma ingresos al saldo (Implementa TransactionRecorder)
func (s *SeguimientoFinancieroRefactor) RegistrarIngreso(monto float64, categoria string) {
	if !s.Activo {
		fmt.Println("[ERROR] El seguimiento financiero está inactivo. No se puede registrar el ingreso.")
		return
	}
	s.ingresosRegistrados = append(s.ingresosRegistrados, monto)
	s.SaldoActual += monto
	s.IngresosTotales += monto
	s.ultimoMovimiento = time.Now()
	fmt.Printf("Ingreso de %.2f %s registrado en '%s'.\n", monto, s.Moneda, categoria)
	s.CalcularAhorroMensual() // Recalcula las métricas al haber un cambio
}

// RegistrarGasto descuenta gastos del saldo (Implementa TransactionRecorder)
func (s *SeguimientoFinancieroRefactor) RegistrarGasto(monto float64, categoria string) {
	if !s.Activo {
		fmt.Println("[ERROR] El seguimiento financiero está inactivo. No se puede registrar el gasto.")
		return
	}
	s.gastosRegistrados = append(s.gastosRegistrados, monto)
	s.SaldoActual -= monto
	s.FinancialMetricsBase._TotalGastos += monto // Campo de la base
	s.categoriasGasto[categoria] += monto
	s.ultimoMovimiento = time.Now()
	s.CalcularPromedioGasto() // Recalcula las métricas
	s.CalcularAhorroMensual() // Recalcula las métricas
	fmt.Printf("Gasto de %.2f %s registrado en '%s'.\n", monto, s.Moneda, categoria)

	if s.FinancialMetricsBase._TotalGastos > s.FinancialMetricsBase._LimiteGasto && s.FinancialMetricsBase._LimiteGasto > 0 {
		fmt.Printf("[ALERTA] ¡Se ha superado el límite de gasto (%.2f %s)!\n", s.FinancialMetricsBase._LimiteGasto, s.Moneda)
	}
}

// CalcularPromedioGasto calcula el promedio de gasto por registro (Implementa FinancialAnalyzer)
func (s *SeguimientoFinancieroRefactor) CalcularPromedioGasto() {
	total := s.FinancialMetricsBase._TotalGastos
	if len(s.gastosRegistrados) > 0 {
		s.FinancialMetricsBase._PromedioGasto = total / float64(len(s.gastosRegistrados))
	} else {
		s.FinancialMetricsBase._PromedioGasto = 0.0
	}
}

// CalcularAhorroMensual estima el ahorro disponible (Implementa FinancialAnalyzer)
func (s *SeguimientoFinancieroRefactor) CalcularAhorroMensual() {
	s.FinancialMetricsBase._AhorroMensual = s.IngresosTotales - s.FinancialMetricsBase._TotalGastos
}

// MostrarResumen imprime un resumen financiero general (Implementa FinancialAnalyzer)
func (s *SeguimientoFinancieroRefactor) MostrarResumen() {
	fmt.Println("\n--- RESUMEN FINANCIERO ---")
	fmt.Printf("Usuario: %s | Moneda: %s | Activo: %t\n", s.NombreUsuario, s.Moneda, s.Activo)
	fmt.Printf("Saldo actual: %.2f\n", s.SaldoActual)
	fmt.Printf("Ingresos totales: %.2f | Gastos totales: %.2f\n", s.IngresosTotales, s.FinancialMetricsBase._TotalGastos)
	fmt.Printf("Ahorro neto: %.2f | Promedio gasto: %.2f\n", s.FinancialMetricsBase._AhorroMensual, s.FinancialMetricsBase._PromedioGasto)
	fmt.Printf("Límite de gasto: %.2f | Último movimiento: %s\n",
		s.FinancialMetricsBase._LimiteGasto, s.ultimoMovimiento.Format("2006-01-02"))
	fmt.Println(s.GetTiempoTranscurrido())
}

// EstablecerLimite define un límite de gasto mensual (Método auxiliar)
func (s *SeguimientoFinancieroRefactor) EstablecerLimite(limite float64) {
	s.FinancialMetricsBase._LimiteGasto = limite
	fmt.Printf("Límite de gasto mensual establecido: %.2f %s\n", limite, s.Moneda)
}

// SetConfiguracion establece la configuración (Método auxiliar)
func (s *SeguimientoFinancieroRefactor) SetConfiguracion(cfg map[string]interface{}) {
	s.configuracion = cfg
}

// MostrarConfiguracion muestra la configuración actual (Método auxiliar)
func (s *SeguimientoFinancieroRefactor) MostrarConfiguracion() {
	if len(s.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(s.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// =================================================================
// MAIN (Demostración de los 4 Constructores)
// =================================================================
func main() {
	fmt.Println("========================================")
	fmt.Println("DEMOSTRACIÓN DE FACTORIES (4 Constructores)")
	fmt.Println("========================================")

	// 1. Factory Sin Parámetros (Default)
	fmt.Println("\n--- 1. Constructor Default ---")
	gDefault := NewSeguimientoFinancieroDefault()
	gDefault.MostrarResumen() // Muestra valores predeterminados (Activo: false)

	// 2. Factory Con Parámetros Esenciales (Camila)
	fmt.Println("\n--- 2. Constructor Simple (Camila) ---")
	gCamila := NewSeguimientoFinanciero("Camila", "USD", 500.00)
	gCamila.EstablecerLimite(300.00)

	gCamila.RegistrarIngreso(200.00, "Salario")
	gCamila.RegistrarIngreso(50.00, "Regalo")
	gCamila.RegistrarGasto(80.00, "Comida")
	gCamila.RegistrarGasto(30.00, "Transporte")
	gCamila.RegistrarGasto(40.00, "Entretenimiento")
	gCamila.MostrarResumen()

	// 3. Factory Sobrecargado / Completo (Andrés)
	fmt.Println("\n--- 3. Constructor Full (Andrés) ---")
	cfgAndres := map[string]interface{}{
		"modo_ahorro": "manual_estricto",
		"resumen":     "diario",
	}
	gAndres := NewSeguimientoFinancieroFull("Andrés", "EUR", 1000.00, 500.00, cfgAndres)
	gAndres.RegistrarGasto(100.00, "Alquiler")
	gAndres.RegistrarGasto(50.00, "Internet")
	gAndres.MostrarResumen()
	gAndres.MostrarConfiguracion()

	// 4. Factory Copia (Auditoría de Camila)
	fmt.Println("\n--- 4. Constructor Copia (Camila_Auditoría) ---")
	gAuditoria := NewSeguimientoFinancieroCopy(gCamila)

	// Demostración: El clon de auditoría no puede registrar movimientos
	gAuditoria.RegistrarGasto(10.00, "Fallo") 

	// Demostración: Los datos copiados son idénticos al original antes del nuevo movimiento
	fmt.Printf("Original (Camila) Saldo: %.2f\n", gCamila.SaldoActual)
	fmt.Printf("Copia (Auditoría) Saldo: %.2f\n", gAuditoria.SaldoActual)
	fmt.Println(gAuditoria.GetTiempoTranscurrido()) // Tiene un nuevo tiempo de inicio
	gAuditoria.MostrarResumen()
}