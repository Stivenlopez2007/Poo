package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// =================================================================
// 1. INTERFACES (Contratos)
// =================================================================

// EncendidoApagado define la funcionalidad básica de control de energía.
type EncendidoApagado interface {
	EncenderCelular()
	ApagarCelular()
}

// GestionEnergia define las acciones relacionadas con la batería y el consumo.
type GestionEnergia interface {
	CargarBateria()
}

// DispositivoInteligente combina acciones de conectividad y gestión de aplicaciones.
type DispositivoInteligente interface {
	ConectarWifi(red string)
	AbrirAplicacion(nombre string)
}

// Configurable permite la gestión de ajustes (Getters y Setters).
type Configurable interface {
	SetConfiguracion(config map[string]interface{})
	GetConfiguracion() map[string]interface{}
}

// =================================================================
// 2. STRUCT BASE (Composición / "Herencia")
// =================================================================

// DispositivoBase contiene las propiedades fundamentales del hardware.
type DispositivoBase struct {
	Marca            string
	Modelo           string
	SistemaOperativo string
	Almacenamiento   int
	_VersionSoftware string // "Protegido"
}

// NewDispositivoBase es la factory principal para la base.
func NewDispositivoBase(marca, modelo, so string, almacenamiento int) DispositivoBase {
	return DispositivoBase{
		Marca:            marca,
		Modelo:           modelo,
		SistemaOperativo: so,
		Almacenamiento:   almacenamiento,
		_VersionSoftware: "1.0.0",
	}
}

// =================================================================
// 3. ESTRUCTURA PRINCIPAL (ControlCelular)
// =================================================================

// ControlCelular es el dispositivo principal que compone la base y el estado.
type ControlCelular struct {
	// Composición de la base
	DispositivoBase

	// Públicos (Estado simple)
	Encendido bool

	// Privados (no exportados)
	nivelBateria     int
	conectadoWifi    bool
	codigoDesbloqueo string
	registroBinario  []byte
	configuracion    map[string]interface{}

	// "Protegidos" (convención con _ prefijo)
	_FechaUltimaCarga  time.Time
	_ModoOscuro        bool
	_Temperatura       float64
	_ListaAplicaciones []string
}

// inicializarEstadoPrivado establece los valores predeterminados internos.
// ESTE ES EL ÚNICO PUNTO DE INICIALIZACIÓN DE ESTADO INTERNO.
func (c *ControlCelular) inicializarEstadoPrivado() {
	c.Encendido = false
	c.nivelBateria = 100
	c.conectadoWifi = false
	c.codigoDesbloqueo = "0000"
	c._ModoOscuro = false
	c._Temperatura = 28.5
	c._ListaAplicaciones = []string{"Teléfono", "Mensajes", "Cámara"}
	c.registroBinario = make([]byte, 0)
}

// =================================================================
// 4. FUNCIONES FACTORY (Constructores Encadenados/Delegados)
// =================================================================

// NuevoControlCelularFull (C3): EL CONSTRUCTOR PRINCIPAL
// Es la única función que llama a inicializarEstadoPrivado().
func NuevoControlCelularFull(marca, modelo, so string, almacenamiento int) *ControlCelular {
	cel := &ControlCelular{
		// 1. Inicializa la estructura base
		DispositivoBase: NewDispositivoBase(marca, modelo, so, almacenamiento),
	}
	// 2. Llama al método que inicializa todos los campos privados y protegidos
	cel.inicializarEstadoPrivado() 
	return cel
}

// NuevoControlCelular (C2): Delega al Constructor Principal (C3)
func NuevoControlCelular(marca, modelo, so string, almacenamiento int) *ControlCelular {
	// Reutiliza la lógica completa del constructor Full
	return NuevoControlCelularFull(marca, modelo, so, almacenamiento)
}

// NuevoControlCelularGenerico (C1): Delega al Constructor Principal (C3)
func NuevoControlCelularGenerico() *ControlCelular {
	// Reutiliza la lógica completa del constructor Full con valores genéricos
	return NuevoControlCelularFull("Generico", "Modelo Básico", "BasicOS", 64)
}

// NuevoControlCelularCopy (C4): Delega al Principal (C3) y luego copia el estado mutable
func NuevoControlCelularCopy(original *ControlCelular) *ControlCelular {
	// 1. Delega al principal (C3) para asegurar que la base y el estado se inicialicen correctamente
	copia := NuevoControlCelularFull(
		original.Marca,
		original.Modelo,
		original.SistemaOperativo,
		original.Almacenamiento,
	)

	// 2. Copia de campos específicos del estado (privados y "protegidos")
	copia.Encendido = original.Encendido
	copia.nivelBateria = original.nivelBateria
	copia.conectadoWifi = original.conectadoWifi
	copia.codigoDesbloqueo = original.codigoDesbloqueo
	copia._FechaUltimaCarga = original._FechaUltimaCarga
	copia._Temperatura = original._Temperatura
	
	// 3. Copia profunda de slices y maps
	copia.registroBinario = append([]byte{}, original.registroBinario...)
	copia._ListaAplicaciones = append([]string{}, original._ListaAplicaciones...)
	
	if original.configuracion != nil {
		copia.configuracion = make(map[string]interface{})
		for k, v := range original.configuracion {
			copia.configuracion[k] = v
		}
	}

	return copia
}

// =================================================================
// 5. MÉTODOS DE ACCIÓN (Implementan Interfaces)
// =================================================================

// EncenderCelular activa el dispositivo
func (c *ControlCelular) EncenderCelular() { // Implementa EncendidoApagado
	if c.Encendido {
		fmt.Println(" El celular ya está encendido.")
		return
	}
	c.Encendido = true
	// Accede a los campos incrustados directamente:
	fmt.Printf(" %s %s encendido correctamente.\n", c.Marca, c.Modelo)
}

// ApagarCelular apaga el dispositivo
func (c *ControlCelular) ApagarCelular() { // Implementa EncendidoApagado
	if !c.Encendido {
		fmt.Println("El celular ya está apagado.")
		return
	}
	c.Encendido = false
	fmt.Println(" El celular se ha apagado.")
}

// CargarBateria recarga la batería al 100%
func (c *ControlCelular) CargarBateria() { // Implementa GestionEnergia
	c.nivelBateria = 100
	c._FechaUltimaCarga = time.Now()
	fmt.Printf(" Batería cargada al 100%% (%s)\n",
		c._FechaUltimaCarga.Format("02-01-2006 15:04:05"))
}

// ConectarWifi simula la conexión a una red Wi-Fi
func (c *ControlCelular) ConectarWifi(red string) { // Implementa DispositivoInteligente
	c.conectadoWifi = true
	fmt.Printf("Conectado a la red Wi-Fi \"%s\".\n", red)
}

// AbrirAplicacion permite abrir una app instalada
func (c *ControlCelular) AbrirAplicacion(nombre string) { // Implementa DispositivoInteligente
	if !c.Encendido {
		fmt.Println(" No se puede abrir aplicaciones con el celular apagado.")
		return
	}

	for _, app := range c._ListaAplicaciones {
		if app == nombre {
			fmt.Printf("Abriendo la aplicación: %s...\n", nombre)
			c.nivelBateria -= 2
			return
		}
	}
	fmt.Printf(" La aplicación \"%s\" no está instalada.\n", nombre)
}

// =================================================================
// 6. MÉTODOS AUXILIARES Y GETTERS/SETTERS (Implementan Configurable)
// =================================================================

// MostrarEstado imprime un resumen del estado actual
func (c *ControlCelular) MostrarEstado() {
	fmt.Println("\n--- ESTADO DEL CELULAR ---")
	// Accede a campos incrustados de DispositivoBase:
	fmt.Printf("Marca: %s\nModelo: %s\nSO: %s\nVersión: %s\n",
		c.Marca, c.Modelo, c.SistemaOperativo, c._VersionSoftware)
	fmt.Printf("Encendido: %t | Batería: %d%% | Wi-Fi: %t\n",
		c.Encendido, c.nivelBateria, c.conectadoWifi)
	fmt.Printf("Modo oscuro: %t | Temperatura: %.1f°C\n",
		c._ModoOscuro, c._Temperatura)
}

// MostrarConfiguracion muestra los datos JSON de configuración
func (c *ControlCelular) MostrarConfiguracion() {
	if c.configuracion == nil {
		fmt.Println(" No hay configuración disponible.")
		return
	}

	data, _ := json.MarshalIndent(c.configuracion, "", "  ")
	fmt.Println(" Configuración actual:")
	fmt.Println(string(data))
}

// SetConfiguracion establece la configuración
func (c *ControlCelular) SetConfiguracion(config map[string]interface{}) { // Implementa Configurable
	c.configuracion = config
}

// GetConfiguracion devuelve la configuración
func (c *ControlCelular) GetConfiguracion() map[string]interface{} { // Implementa Configurable
	return c.configuracion
}

// =================================================================
// FUNCIÓN PRINCIPAL (MAIN)
// =================================================================

func main() {
	fmt.Println("--- PRUEBA DE CONSTRUCTORES DELEGADOS ---")
	
	// 1. Uso de constructor generico (C1) - Delega a Full
	celGen := NuevoControlCelularGenerico()
	fmt.Printf("Celular Genérico: %s %s (Almacenamiento: %d GB)\n", 
		celGen.Marca, celGen.Modelo, celGen.Almacenamiento)
        
	// 2. Creación del objeto con el constructor principal (C3) - Inicializa todo
	cel := NuevoControlCelularFull("Samsung", "Galaxy S24 Ultra", "Android 15", 512)
	fmt.Printf("Celular Principal: %s %s (Almacenamiento: %d GB)\n", 
		cel.Marca, cel.Modelo, cel.Almacenamiento)

	// 3. Creación del objeto con constructor sobrecargado (C2) - Delega a Full
	celBasico := NuevoControlCelular("Xiaomi", "Redmi 13", "HyperOS", 256)
	fmt.Printf("Celular Básico: %s %s (Almacenamiento: %d GB)\n", 
		celBasico.Marca, celBasico.Modelo, celBasico.Almacenamiento)

	// Configuración inicial (map -> JSON)
	config := map[string]interface{}{
		"idioma": "Español",
		"region": "Latinoamérica",
		"brillo": 75,
		"sonido": true,
	}
	cel.SetConfiguracion(config)

	// Flujo de acciones
	fmt.Println("\n--- FLUJO DE ACCIONES ---")
	cel.EncenderCelular()
	cel.ConectarWifi("Red_Hogar")
	cel.AbrirAplicacion("Cámara")
	cel.AbrirAplicacion("TikTok") // App no instalada
	cel.MostrarEstado()
	cel.MostrarConfiguracion()
	cel.CargarBateria()
	cel.ApagarCelular()
	
	// 4. Prueba del constructor de copia (C4) - Delega a Full y luego copia el estado
	celCopy := NuevoControlCelularCopy(cel)
	fmt.Println("\n--- PRUEBA DE COPIA ---")
	fmt.Printf("Copia de Celular: %s %s. Encendido: %t\n", celCopy.Marca, celCopy.Modelo, celCopy.Encendido)
	cel.EncenderCelular() // Celular original ya está apagado
	celCopy.EncenderCelular() // La copia sigue el estado original (apagado)

}