package main

import (
	"fmt"
	"time"
)

// =================================================================
// CONCEPTOS BASE
// =================================================================

// 1. INTERFAZ (Equivalentemente, la Interfaz)
//
// Define un contrato: cualquier struct que tenga estos métodos implementa la Interfaz.
type Ejecutable interface {
	Ejecutar() string
	VerificarEstado() string
}

// 2. CLASE ABSTRACTA (Equivalentemente, la Composición + Interfaz Mandatoria)
//
// EntidadBase actúa como la "Clase Abstracta". No debe ser instanciada directamente
// y proporciona campos comunes (por composición) y un método requerido (por interfaz).
type EntidadBase struct {
	ID            string
	FechaCreacion time.Time
}

// GetInfoBase es un método común que simula la funcionalidad de la clase abstracta.
func (e *EntidadBase) GetInfoBase() string {
	return fmt.Sprintf("ID: %s, Creado: %s", e.ID, e.FechaCreacion.Format("2006-01-02"))
}

// 3. CLASE NORMAL (Equivalentemente, el Struct)
//
// La clase que hereda/compone y da funcionalidad concreta.

// =================================================================
// EJEMPLO 1: REPORTE DE AUDITORÍA (ReporteAuditoria)
// El ejemplo principal con las 4 factories y la implementación de interfaces/composición.
// =================================================================

type ReporteAuditoria struct {
	EntidadBase // Composición (simula herencia de la clase abstracta)

	NombreAuditor string
	Sistema       string
	// Propiedad específica de la clase normal
	PuntuacionSeguridad float64
	Completado          bool
}

// Implementación de la Interfaz Ejecutable (Requerida por la "clase abstracta")
func (r *ReporteAuditoria) Ejecutar() string {
	if r.Completado {
		return fmt.Sprintf("Reporte de %s ejecutado y finalizado.", r.Sistema)
	}
	return fmt.Sprintf(" Iniciando ejecución de reporte para %s...", r.Sistema)
}

func (r *ReporteAuditoria) VerificarEstado() string {
	estado := "Pendiente"
	if r.Completado {
		estado = "Finalizado"
	}
	return fmt.Sprintf("Estado actual: %s. Puntuación: %.1f", estado, r.PuntuacionSeguridad)
}

// ----------------------------------------------------
// 4 CONSTRUCTORES (FUNCIONES FACTORY) para ReporteAuditoria
// ----------------------------------------------------

// 4.1. Factory "Sin Parámetros" (NewReporteAuditoriaDefault)
// Inicializa con valores predeterminados (default).
func NewReporteAuditoriaDefault() *ReporteAuditoria {
	return &ReporteAuditoria{
		EntidadBase: EntidadBase{
			ID:            "RPT-DEF-001",
			FechaCreacion: time.Now(),
		},
		NombreAuditor:       "Anonimo",
		Sistema:             "Sistema Generico",
		PuntuacionSeguridad: 5.0,
		Completado:          false,
	}
}

// 4.2. Factory "Con Parámetros" (NewReporteAuditoria)
// Inicializa con los parámetros esenciales.
func NewReporteAuditoria(sistema string, auditor string) *ReporteAuditoria {
	// Reúsa la lógica de la factory Default para establecer la base
	r := NewReporteAuditoriaDefault()
	r.Sistema = sistema
	r.NombreAuditor = auditor
	r.EntidadBase.ID = fmt.Sprintf("RPT-S-%s", time.Now().Format("0405"))
	return r
}

// 4.3. Factory "Sobrecargado" / Completo (NewReporteAuditoriaFull)
// Inicializa con todos los parámetros posibles, simulando la sobrecarga.
func NewReporteAuditoriaFull(sistema string, auditor string, puntuacion float64, id string, completado bool) *ReporteAuditoria {
	r := &ReporteAuditoria{
		EntidadBase: EntidadBase{
			ID:            id,
			FechaCreacion: time.Now(),
		},
		NombreAuditor:       auditor,
		Sistema:             sistema,
		PuntuacionSeguridad: puntuacion,
		Completado:          completado,
	}
	return r
}

// 4.4. Factory "Copia" (NewReporteAuditoriaCopy)
// Crea una nueva instancia copiando los valores de la original.
func NewReporteAuditoriaCopy(original *ReporteAuditoria) *ReporteAuditoria {
	// Crea una copia profunda de la estructura
	copia := *original
	// Asegura que la fecha de creación de la copia sea diferente si es necesario
	copia.EntidadBase.FechaCreacion = time.Now()
	copia.EntidadBase.ID = original.EntidadBase.ID + "-COPY"
	return &copia
}

// =================================================================
// EJEMPLOS ADICIONALES (2 a 5) - Solo Structs y Factories
// =================================================================

// EJEMPLO 2: Usuario Auditado
type UsuarioAuditado struct {
	IDUsuario string
	Nombre    string
	Rol       string
	Activo    bool
}

func NewUsuarioAuditadoDefault() *UsuarioAuditado {
	return &UsuarioAuditado{IDUsuario: "USR-000", Nombre: "Invitado", Rol: "Visitante", Activo: false}
}
func NewUsuarioAuditado(id string, nombre string) *UsuarioAuditado {
	u := NewUsuarioAuditadoDefault()
	u.IDUsuario = id
	u.Nombre = nombre
	u.Activo = true
	return u
}
func NewUsuarioAuditadoFull(id string, nombre string, rol string, activo bool) *UsuarioAuditado {
	return &UsuarioAuditado{IDUsuario: id, Nombre: nombre, Rol: rol, Activo: activo}
}
func NewUsuarioAuditadoCopy(original *UsuarioAuditado) *UsuarioAuditado {
	copia := *original
	copia.IDUsuario = original.IDUsuario + "-COPY"
	return &copia
}

// EJEMPLO 3: Requisito de Seguridad
type RequisitoSeguridad struct {
	Codigo       string
	Descripcion  string
	Gravedad     int // 1 (Baja) a 5 (Critica)
	EsObligatorio bool
}

func NewRequisitoSeguridadDefault() *RequisitoSeguridad {
	return &RequisitoSeguridad{Codigo: "REQ-000", Descripcion: "Requisito pendiente", Gravedad: 1, EsObligatorio: false}
}
func NewRequisitoSeguridad(codigo string, gravedad int) *RequisitoSeguridad {
	r := NewRequisitoSeguridadDefault()
	r.Codigo = codigo
	r.Gravedad = gravedad
	r.EsObligatorio = true
	return r
}
func NewRequisitoSeguridadFull(codigo string, desc string, grav int, oblig bool) *RequisitoSeguridad {
	return &RequisitoSeguridad{Codigo: codigo, Descripcion: desc, Gravedad: grav, EsObligatorio: oblig}
}
func NewRequisitoSeguridadCopy(original *RequisitoSeguridad) *RequisitoSeguridad {
	copia := *original
	copia.Codigo = original.Codigo + "-COPY"
	return &copia
}

// EJEMPLO 4: Prueba de Penetración
type PruebaPenetracion struct {
	Plataforma string
	Metodologia string
	TiempoEstimado time.Duration
	VulnerabilidadesEncontradas int
}

func NewPruebaPenetracionDefault() *PruebaPenetracion {
	return &PruebaPenetracion{Plataforma: "Web", Metodologia: "OSSTMM", TiempoEstimado: 24 * time.Hour, VulnerabilidadesEncontradas: 0}
}
func NewPruebaPenetracion(plataforma string, tiempo time.Duration) *PruebaPenetracion {
	p := NewPruebaPenetracionDefault()
	p.Plataforma = plataforma
	p.TiempoEstimado = tiempo
	return p
}
func NewPruebaPenetracionFull(plataforma string, metodo string, tiempo time.Duration, vuls int) *PruebaPenetracion {
	return &PruebaPenetracion{Plataforma: plataforma, Metodologia: metodo, TiempoEstimado: tiempo, VulnerabilidadesEncontradas: vuls}
}
func NewPruebaPenetracionCopy(original *PruebaPenetracion) *PruebaPenetracion {
	copia := *original
	return &copia
}

// EJEMPLO 5: Hallazgo de Fallo
type HallazgoFallo struct {
	CodigoFallo string
	Severidad   string // Baja, Media, Alta
	ComponenteAfectado string
	FechaDescubrimiento time.Time
}

func NewHallazgoFalloDefault() *HallazgoFallo {
	return &HallazgoFallo{CodigoFallo: "FALLO-000", Severidad: "Baja", ComponenteAfectado: "Desconocido", FechaDescubrimiento: time.Now()}
}
func NewHallazgoFallo(codigo string, severidad string) *HallazgoFallo {
	h := NewHallazgoFalloDefault()
	h.CodigoFallo = codigo
	h.Severidad = severidad
	return h
}
func NewHallazgoFalloFull(codigo string, severidad string, componente string, fecha time.Time) *HallazgoFallo {
	return &HallazgoFallo{CodigoFallo: codigo, Severidad: severidad, ComponenteAfectado: componente, FechaDescubrimiento: fecha}
}
func NewHallazgoFalloCopy(original *HallazgoFallo) *HallazgoFallo {
	copia := *original
	copia.CodigoFallo = original.CodigoFallo + "-COPY"
	return &copia
}

// =================================================================
// FUNCIÓN PRINCIPAL (MAIN)
// =================================================================

func main() {
	fmt.Println("===================================================================")
	fmt.Println("DEMOSTRACIÓN DE ESTRUCTURAS Y 4 TIPOS DE FACTORIES (Go Idiomático)")
	fmt.Println("===================================================================")

	// EJEMPLO 1: REPORTE DE AUDITORÍA (Clase Normal que implementa Interfaces y Abstracta)
	fmt.Println("\n--- 1. ReporteAuditoria (4 Factories) ---")

	// 1. Factory Sin Parámetros (Default)
	def := NewReporteAuditoriaDefault()
	fmt.Printf("Default: %s | Info: %s\n", def.Ejecutar(), def.GetInfoBase())

	// 2. Factory Con Parámetros (Simple)
	simple := NewReporteAuditoria("Portal Web Clientes", "Juan Perez")
	fmt.Printf("Simple: %s | Auditor: %s\n", simple.Ejecutar(), simple.NombreAuditor)

	// 3. Factory Sobrecargado (Full)
	full := NewReporteAuditoriaFull("ERP Financiero", "Laura Gómez", 9.5, "RPT-FULL-3", true)
	fmt.Printf("Full: %s | Puntuación: %.1f | Estado: %s\n", full.Ejecutar(), full.PuntuacionSeguridad, full.VerificarEstado())

	// 4. Factory Copia
	copia := NewReporteAuditoriaCopy(full)
	fmt.Printf("Copia: %s | ID Original: %s | ID Copia: %s\n", copia.Sistema, full.ID, copia.ID)

	// EJEMPLO 2: USUARIO AUDITADO
	fmt.Println("\n--- 2. UsuarioAuditado (Factories) ---")
	uFull := NewUsuarioAuditadoFull("U-450", "Elena Diaz", "Administrador", true)
	uCopy := NewUsuarioAuditadoCopy(uFull)
	fmt.Printf("Original: %s, Rol: %s | Copia: %s\n", uFull.Nombre, uFull.Rol, uCopy.IDUsuario)

	// EJEMPLO 3: REQUISITO DE SEGURIDAD
	fmt.Println("\n--- 3. RequisitoSeguridad (Factories) ---")
	rSimple := NewRequisitoSeguridad("REQ-DLP-01", 5)
	fmt.Printf("Requisito: %s, Gravedad: %d (Obligatorio: %t)\n", rSimple.Codigo, rSimple.Gravedad, rSimple.EsObligatorio)

	// EJEMPLO 4: PRUEBA DE PENETRACIÓN
	fmt.Println("\n--- 4. PruebaPenetracion (Factories) ---")
	pFull := NewPruebaPenetracionFull("Mobile", "OWASP", 72*time.Hour, 4)
	fmt.Printf("Plataforma: %s, Vulnerabilidades: %d\n", pFull.Plataforma, pFull.VulnerabilidadesEncontradas)

	// EJEMPLO 5: HALLAZGO DE FALLO
	fmt.Println("\n--- 5. HallazgoFallo (Factories) ---")
	hSimple := NewHallazgoFallo("FALLO-SQL-045", "Alta")
	fmt.Printf("Fallo: %s, Severidad: %s\n", hSimple.CodigoFallo, hSimple.Severidad)

	fmt.Println("===================================================================")
}
