package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// =================================================================
// 1. INTERFACES (Simulando Contratos)
// =================================================================

// TaskManagement define las operaciones básicas de agregar y completar tareas.
type TaskManagement interface {
	AgregarTarea(nombre string)
	CompletarTarea(nombre string)
}

// MetricsCalculator define las operaciones para evaluar y mostrar el rendimiento.
type MetricsCalculator interface {
	CalcularEficiencia()
	MostrarResumen()
}

// =================================================================
// 2. CLASE ABSTRACTA (Simulando con Composición - Base Struct)
// =================================================================

// ProjectBase actúa como la "Clase Abstracta", manejando las estadísticas internas
// y de tiempo que se consideran "protegidas".
type ProjectBase struct {
	_FechaInicio     time.Time
	_TareasPendientes int
	_PromedioDiario   float64 // No se usaba, pero se mantiene para composición
	_Eficiencia       float64 // Porcentaje de eficiencia
	_UltimaTarea      string
}

// NewProjectBase es la función factory para la base abstracta.
func NewProjectBase() ProjectBase {
	return ProjectBase{
		_FechaInicio:   time.Now(),
		_TareasPendientes: 0,
		_PromedioDiario: 0.0,
		_Eficiencia: 0.0,
		_UltimaTarea: "Ninguna",
	}
}

// GetProjectDuration es un método de la clase base.
func (b *ProjectBase) GetProjectDuration() string {
	dias := int(time.Since(b._FechaInicio).Hours() / 24)
	return fmt.Sprintf("Días de proyecto: %d", dias)
}

// =================================================================
// 3. ESTRUCTURA PRINCIPAL (Simulando Clase Concreta)
// =================================================================

// GestionTareasRefactor es la estructura principal que usa composición (ProjectBase).
type GestionTareasRefactor struct {
	ProjectBase // Composición (simula herencia)

	// --- Públicos ---
	Usuario      string
	Proyecto     string
	NumeroTareas int
	Completadas  int
	Activo       bool

	// --- Privados ---
	listaTareas         []string
	estadoTareas        map[string]bool
	ultimaActualizacion time.Time
	configuracion       map[string]interface{}
	nivelProductividad  float64 // De 1 a 5
}

// =================================================================
// 4. FUNCIONES FACTORY (Simulando los 4 Constructores)
// =================================================================

// 4.1. Factory "Sin Parámetros" (NewGestionTareasDefault)
// Inicializa con valores predeterminados (simula constructor sin parámetros).
func NewGestionTareasDefault() *GestionTareasRefactor {
	return &GestionTareasRefactor{
		ProjectBase: NewProjectBase(), // Inicializa la base
		Usuario:     "Anónimo",
		Proyecto:    "Proyecto Base",
		Activo:      false,
		listaTareas: make([]string, 0),
		estadoTareas: make(map[string]bool),
		configuracion: make(map[string]interface{}),
		ultimaActualizacion: time.Now(),
	}
}

// 4.2. Factory "Con Parámetros" (NewGestionTareas)
// Inicializa con los parámetros esenciales (simula constructor con parámetros).
func NewGestionTareas(usuario, proyecto string) *GestionTareasRefactor {
	// Reúsa el constructor default y lo personaliza
	g := NewGestionTareasDefault()
	g.Usuario = usuario
	g.Proyecto = proyecto
	g.Activo = true
	g._UltimaTarea = "Proyecto Creado" // Campo de la base abstracta
	return g
}

// 4.3. Factory "Sobrecargado" / Completo (NewGestionTareasFull)
// Inicializa con varios parámetros opcionales (simula constructor sobrecargado).
func NewGestionTareasFull(usuario, proyecto string, tareasIniciales []string, activo bool) *GestionTareasRefactor {
	g := NewGestionTareasDefault() // Usamos el default para inicializar mapas/slices
	g.Usuario = usuario
	g.Proyecto = proyecto
	g.Activo = activo
	g.listaTareas = tareasIniciales
	g.NumeroTareas = len(tareasIniciales)

	for _, tarea := range tareasIniciales {
		g.estadoTareas[tarea] = false
	}
	g._TareasPendientes = g.NumeroTareas
	g._UltimaTarea = tareasIniciales[len(tareasIniciales)-1]
	g.ultimaActualizacion = time.Now()

	// Si está activo, asume un nivel de productividad base
	if activo {
		g.nivelProductividad = 3.0
	}
	return g
}

// 4.4. Factory "Copia" (NewGestionTareasCopy)
// Crea una nueva instancia copiando el estado de la original (simula constructor copia).
func NewGestionTareasCopy(original *GestionTareasRefactor) *GestionTareasRefactor {
	// 1. Crear una copia de la estructura (incluye ProjectBase por valor)
	copia := *original

	// 2. Realizar copias profundas de slices y maps (CRÍTICO)
	copia.listaTareas = append([]string{}, original.listaTareas...)
	copia.estadoTareas = make(map[string]bool)
	for k, v := range original.estadoTareas {
		copia.estadoTareas[k] = v
	}
	copia.configuracion = make(map[string]interface{})
	for k, v := range original.configuracion {
		copia.configuracion[k] = v
	}

	// 3. Actualizar metadatos de la copia para que sea única
	copia.Usuario = original.Usuario + "_Clon"
	copia.Proyecto = original.Proyecto + "_CLONE"
	copia.ultimaActualizacion = time.Now()
	copia.ProjectBase._FechaInicio = time.Now() // La copia tiene su propia fecha de inicio

	return &copia
}

// =================================================================
// 5. MÉTODOS DE ACCIÓN (Implementan Interfaces)
// =================================================================

// AgregarTarea añade una nueva tarea a la lista (Implementa TaskManagement)
func (g *GestionTareasRefactor) AgregarTarea(nombre string) {
	if !g.Activo {
		fmt.Println("[ERROR] La gestión de tareas está inactiva.")
		return
	}
	g.listaTareas = append(g.listaTareas, nombre)
	g.estadoTareas[nombre] = false
	g.NumeroTareas++
	g._TareasPendientes++ // Campo de la clase base
	g._UltimaTarea = nombre // Campo de la clase base
	g.ultimaActualizacion = time.Now()
	fmt.Printf("Tarea agregada: '%s'\n", nombre)
}

// CompletarTarea marca una tarea como completada (Implementa TaskManagement)
func (g *GestionTareasRefactor) CompletarTarea(nombre string) {
	if _, existe := g.estadoTareas[nombre]; !existe {
		fmt.Printf("[ERROR] La tarea '%s' no existe.\n", nombre)
		return
	}
	if g.estadoTareas[nombre] {
		fmt.Printf("La tarea '%s' ya estaba completada.\n", nombre)
		return
	}
	g.estadoTareas[nombre] = true
	g.Completadas++
	g._TareasPendientes-- // Campo de la clase base
	g.ultimaActualizacion = time.Now()
	fmt.Printf("Tarea completada: '%s'\n", nombre)
	g.CalcularEficiencia()
}

// CalcularEficiencia evalúa el rendimiento (Implementa MetricsCalculator)
func (g *GestionTareasRefactor) CalcularEficiencia() {
	if g.NumeroTareas == 0 {
		g._Eficiencia = 0 // Campo de la clase base
		return
	}
	g._Eficiencia = (float64(g.Completadas) / float64(g.NumeroTareas)) * 100
	if g._Eficiencia > 80 {
		g.nivelProductividad = 5
	} else if g._Eficiencia >= 50 {
		g.nivelProductividad = 3.5
	} else {
		g.nivelProductividad = 2
	}
}

// MostrarResumen imprime el estado general del proyecto (Implementa MetricsCalculator)
func (g *GestionTareasRefactor) MostrarResumen() {
	fmt.Println("\n--- RESUMEN DE GESTIÓN DE TAREAS ---")
	fmt.Printf("Usuario: %s\nProyecto: %s\n", g.Usuario, g.Proyecto)
	fmt.Printf("Tareas: %d | Completadas: %d | Pendientes: %d\n",
		g.NumeroTareas, g.Completadas, g._TareasPendientes) // Usa campo de la base
	fmt.Printf("Eficiencia: %.1f%% | Productividad: %.1f/5\n", g._Eficiencia, g.nivelProductividad) // Usa campo de la base
	fmt.Printf("Última tarea registrada: %s\nÚltima actualización: %s\n",
		g._UltimaTarea, g.ultimaActualizacion.Format("2006-01-02 15:04")) // Usa campo de la base
	fmt.Println(g.GetProjectDuration())
}

// SetConfiguracion establece la configuración
func (g *GestionTareasRefactor) SetConfiguracion(cfg map[string]interface{}) {
	g.configuracion = cfg
}

// MostrarConfiguracion muestra la configuración actual
func (g *GestionTareasRefactor) MostrarConfiguracion() {
	if len(g.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(g.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// =================================================================
// MAIN (Demostración de los 4 Constructores)
// =================================================================
func main() {
	fmt.Println("========================================")
	fmt.Println("DEMOSTRACIÓN DE FACTORIES (4 Constructores)")
	fmt.Println("========================================")

	// 1. Factory Sin Parámetros (Default)
	fmt.Println("\n--- 1. Constructor Default ---")
	gDefault := NewGestionTareasDefault()
	fmt.Printf("Creado: %s, Activo: %t\n", gDefault.Usuario, gDefault.Activo)
	gDefault.AgregarTarea("Tarea fallida")
	gDefault.MostrarResumen()

	// 2. Factory Con Parámetros (Simple) - Simula el constructor original
	fmt.Println("\n--- 2. Constructor Simple (Andrea) ---")
	gAndrea := NewGestionTareas("Andrea", "Desarrollo Backend")
	cfg := map[string]interface{}{"modo_productivo": "estricto"}
	gAndrea.SetConfiguracion(cfg)
	gAndrea.AgregarTarea("Diseñar base de datos")
	gAndrea.AgregarTarea("Implementar API")
	gAndrea.CompletarTarea("Diseñar base de datos")
	gAndrea.MostrarResumen()

	// 3. Factory Sobrecargado (Full)
	fmt.Println("\n--- 3. Constructor Full (Marcos) ---")
	tareasMarcos := []string{"Migrar datos", "Test de carga"}
	gMarcos := NewGestionTareasFull("Marcos", "Infraestructura Cloud", tareasMarcos, true)
	fmt.Printf("Creado: %s, Tareas Iniciales: %d, Pendientes: %d\n",
		gMarcos.Usuario, gMarcos.NumeroTareas, gMarcos._TareasPendientes)
	gMarcos.CompletarTarea("Migrar datos")
	gMarcos.MostrarResumen()

	// 4. Factory Copia
	fmt.Println("\n--- 4. Constructor Copia (Andrea-Clon) ---")
	gAndreaClon := NewGestionTareasCopy(gAndrea)
	gAndreaClon.Usuario = "Andrea-Clon"
	gAndreaClon.AgregarTarea("Revisión de código") // El clon agrega una nueva tarea
	
	fmt.Printf("Original (Andrea) Tareas Totales: %d\n", gAndrea.NumeroTareas)
	fmt.Printf("Copia (Clon) Tareas Totales: %d\n", gAndreaClon.NumeroTareas)
	fmt.Println(gAndreaClon.GetProjectDuration()) // Demuestra que la copia tiene su propia duración
}