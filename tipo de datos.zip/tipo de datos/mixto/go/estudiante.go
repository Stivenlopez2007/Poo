package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// =================================================================
// 1. INTERFACES (Simulando Contratos)
// =================================================================

// EstudianteAccionable define las acciones de un estudiante activo.
type EstudianteAccionable interface {
	Estudiar(horas int)
	CompletarTema(tema string)
	MostrarEstado()
}

// Evaluador define las acciones de evaluación y certificación.
type Evaluador interface {
	Evaluar(puntaje float64)
	Certificar()
}

// =================================================================
// 2. CLASE ABSTRACTA (Simulando con Composición - Base Struct)
// =================================================================

// EstadisticasBase actúa como la "Clase Abstracta", conteniendo campos comunes.
// No debe ser instanciada directamente, sino incrustada en otras structs.
type EstadisticasBase struct {
	// "Protegidos"
	_FechaInicio  time.Time
	_DiasTotales  int
	_LenguajeBase string
}

// Inicializa la base de estadísticas.
func NewEstadisticasBase(lenguaje string) EstadisticasBase {
	return EstadisticasBase{
		_FechaInicio:  time.Now(),
		_DiasTotales:  0,
		_LenguajeBase: lenguaje,
	}
}

// =================================================================
// 3. ESTRUCTURA PRINCIPAL (Simulando Clase Concreta)
// =================================================================

// AprendiendoGoRefactor es la estructura principal que usa composición.
type AprendiendoGoRefactor struct {
	EstadisticasBase // Composición (simula herencia de la clase abstracta)

	// --- Públicos ---
	NombreEstudiante string
	NivelActual      string
	HorasEstudio     int
	AvancePorcentaje float64
	Activo           bool

	// --- Privados ---
	progresoSemanal  []int // El original no lo usaba, lo mantendremos para consistencia.
	temasCompletados []string
	calificacion     float64
	feedbackProfesor string
	configuracion    map[string]interface{}
	
	// "Protegido"
	_Certificado bool
	_UltimoTema  string
}

// Función auxiliar para inicializar campos comunes de la clase concreta.
func (a *AprendiendoGoRefactor) inicializarEstado() {
	a.NivelActual = "Básico"
	a.Activo = true
	a.temasCompletados = []string{}
	a.progresoSemanal = []int{}
	a.configuracion = make(map[string]interface{})
}

// =================================================================
// 4. FUNCIONES FACTORY (Simulando los 4 Constructores)
// =================================================================

// 4.1. Factory "Sin Parámetros" (NewAprendiendoGoDefault)
// Constructor por defecto, con valores fijos.
func NewAprendiendoGoDefault() *AprendiendoGoRefactor {
	a := &AprendiendoGoRefactor{
		EstadisticasBase: NewEstadisticasBase("Go"), // Inicializa base
		NombreEstudiante: "Estudiante Anónimo",
		HorasEstudio:     0,
		AvancePorcentaje: 0.0,
	}
	a.inicializarEstado()
	return a
}

// 4.2. Factory "Con Parámetros" (NewAprendiendoGo)
// Constructor simple, con los parámetros esenciales. Simula la firma original.
func NewAprendiendoGo(nombre string) *AprendiendoGoRefactor {
	// Reúsa el constructor default y lo personaliza
	a := NewAprendiendoGoDefault()
	a.NombreEstudiante = nombre
	return a
}

// 4.3. Factory "Sobrecargado" / Completo (NewAprendiendoGoFull)
// Constructor con todos los parámetros relevantes, simulando sobrecarga.
func NewAprendiendoGoFull(nombre string, nivel string, horas int, lenguaje string, activo bool) *AprendiendoGoRefactor {
	a := &AprendiendoGoRefactor{
		// Inicializa base con el lenguaje especificado
		EstadisticasBase: NewEstadisticasBase(lenguaje),
		NombreEstudiante: nombre,
		NivelActual:      nivel,
		HorasEstudio:     horas,
		AvancePorcentaje: float64(horas) * 2.5, // Cálculo inicial
		Activo:           activo,
	}
	a.inicializarEstado()
	return a
}

// 4.4. Factory "Copia" (NewAprendiendoGoCopy)
// Crea una nueva instancia copiando el estado de la original (copia profunda para slices/maps).
func NewAprendiendoGoCopy(original *AprendiendoGoRefactor) *AprendiendoGoRefactor {
	// Usa el constructor Full para inicializar la mayoría de los campos
	copia := NewAprendiendoGoFull(
		original.NombreEstudiante,
		original.NivelActual,
		original.HorasEstudio,
		original.EstadisticasBase._LenguajeBase,
		original.Activo,
	)

	// Copia profunda de slices y maps
	copia.temasCompletados = append([]string{}, original.temasCompletados...)
	copia.progresoSemanal = append([]int{}, original.progresoSemanal...)

	if original.configuracion != nil {
		copia.configuracion = make(map[string]interface{})
		for k, v := range original.configuracion {
			copia.configuracion[k] = v
		}
	}

	// Copia del resto del estado
	copia.AvancePorcentaje = original.AvancePorcentaje
	copia.calificacion = original.calificacion
	copia.feedbackProfesor = original.feedbackProfesor
	copia._Certificado = original._Certificado
	copia._UltimoTema = original._UltimoTema
	copia._DiasTotales = original._DiasTotales
	copia._FechaInicio = original._FechaInicio // Copia el tiempo de inicio original

	return copia
}

// =================================================================
// 5. MÉTODOS DE ACCIÓN (Implementan Interfaces)
// =================================================================

// Estudiar suma horas y aumenta el progreso (Implementa EstudianteAccionable)
func (a *AprendiendoGoRefactor) Estudiar(horas int) {
	if !a.Activo {
		fmt.Println("El estudiante no está activo.")
		return
	}
	a.HorasEstudio += horas
	a.AvancePorcentaje += float64(horas) * 2.5
	if a.AvancePorcentaje > 100 {
		a.AvancePorcentaje = 100
	}
	a._DiasTotales++ // Campo de la clase abstracta
	fmt.Printf("%s estudió %d horas. Progreso: %.1f%%\n",
		a.NombreEstudiante, horas, a.AvancePorcentaje)
}

// CompletarTema agrega un tema aprendido (Implementa EstudianteAccionable)
func (a *AprendiendoGoRefactor) CompletarTema(tema string) {
	a.temasCompletados = append(a.temasCompletados, tema)
	a._UltimoTema = tema
	fmt.Printf("Tema completado: %s\n", tema)
	if a.AvancePorcentaje > 25 && a.NivelActual == "Básico" {
		a.NivelActual = "Intermedio"
	}
}

// Evaluar simula una evaluación con calificación (Implementa Evaluador)
func (a *AprendiendoGoRefactor) Evaluar(puntaje float64) {
	a.calificacion = puntaje
	if puntaje >= 3.5 {
		a.feedbackProfesor = "Buen desempeño, sigue así."
	} else {
		a.feedbackProfesor = "Necesitas reforzar conceptos básicos."
	}
	fmt.Printf("Evaluación completada. Nota: %.1f | Feedback: %s\n",
		puntaje, a.feedbackProfesor)
}

// Certificar revisa si el estudiante alcanzó el 100% del progreso (Implementa Evaluador)
func (a *AprendiendoGoRefactor) Certificar() {
	if a.AvancePorcentaje >= 100 {
		a._Certificado = true
		fmt.Printf("Felicidades %s, has completado el curso de %s.\n",
			a.NombreEstudiante, a._LenguajeBase) // Usa campo de la clase abstracta
	} else {
		fmt.Printf("Aún no has alcanzado el 100%% de progreso en %s.\n", a._LenguajeBase)
	}
}

// MostrarEstado muestra el resumen del progreso actual (Implementa EstudianteAccionable)
func (a *AprendiendoGoRefactor) MostrarEstado() {
	fmt.Println("\n--- ESTADO DE APRENDIZAJE ---")
	fmt.Printf("Estudiante: %s\nNivel: %s\nProgreso: %.1f%%\nHoras: %d\n",
		a.NombreEstudiante, a.NivelActual, a.AvancePorcentaje, a.HorasEstudio)
	fmt.Printf("Último tema: %s\nCertificado: %t\n",
		a._UltimoTema, a._Certificado)
	fmt.Printf("Iniciado: %s (Días totales: %d, Lenguaje: %s)\n",
		a._FechaInicio.Format("2006-01-02"), a._DiasTotales, a._LenguajeBase)
}

// SetConfiguracion establece la configuración
func (a *AprendiendoGoRefactor) SetConfiguracion(config map[string]interface{}) {
	a.configuracion = config
}

// MostrarConfiguracion muestra la configuración actual
func (a *AprendiendoGoRefactor) MostrarConfiguracion() {
	if len(a.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(a.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// =================================================================
// MAIN (Demostración de los 4 Constructores)
// =================================================================
func main() {
	fmt.Println("========================================")
	fmt.Println("DEMOSTRACIÓN DE FACTORIES (4 Constructores)")
	fmt.Println("========================================")

	// 1. Factory Sin Parámetros (Default)
	fmt.Println("\n--- 1. Constructor Default ---")
	estDefault := NewAprendiendoGoDefault()
	fmt.Printf("Creado: %s, Lenguaje Base: %s\n", estDefault.NombreEstudiante, estDefault._LenguajeBase)
	estDefault.Estudiar(1) // Simular uso
	estDefault.MostrarEstado()

	// 2. Factory Con Parámetros (Simple) - Simula el constructor original
	fmt.Println("\n--- 2. Constructor Simple (Laura) ---")
	estLaura := NewAprendiendoGo("Laura")
	estLaura.SetConfiguracion(map[string]interface{}{"modo": "autodidacta", "idioma": "español"})
	estLaura.Estudiar(4)
	estLaura.CompletarTema("Sintaxis básica")
	estLaura.Evaluar(4.0)
	estLaura.MostrarEstado()
	estLaura.MostrarConfiguracion()

	// 3. Factory Sobrecargado (Full)
	fmt.Println("\n--- 3. Constructor Full (Carlos) ---")
	estCarlos := NewAprendiendoGoFull("Carlos", "Avanzado", 150, "Python", true)
	fmt.Printf("Creado: %s, Nivel: %s, Lenguaje Base: %s\n", estCarlos.NombreEstudiante, estCarlos.NivelActual, estCarlos._LenguajeBase)
	estCarlos.Estudiar(1)
	estCarlos.Certificar()

	// 4. Factory Copia
	fmt.Println("\n--- 4. Constructor Copia (Laura-Clon) ---")
	estLauraClon := NewAprendiendoGoCopy(estLaura)
	estLauraClon.NombreEstudiante = "Laura-Clon" // Distinguir el clon
	estLauraClon.Estudiar(2)                      // El clon sigue avanzando
	fmt.Printf("Original (Laura) Horas: %d\n", estLaura.HorasEstudio)
	fmt.Printf("Copia (Laura-Clon) Horas: %d\n", estLauraClon.HorasEstudio)
	estLauraClon.MostrarEstado()
}