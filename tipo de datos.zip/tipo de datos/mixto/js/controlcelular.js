
// =================================================================
// 1. INTERFACES (Simulación de Contratos)
// =================================================================

class IEncendido {
    encender() { throw new Error("Metodo 'encender' debe ser implementado."); }
    apagar() { throw new Error("Metodo 'apagar' debe ser implementado."); }
}

class IConectividad {
    conectarWifi(red) { throw new Error("Metodo 'conectarWifi' debe ser implementado."); }
    desconectarWifi() { throw new Error("Metodo 'desconectarWifi' debe ser implementado."); }
}

class IGestionAplicaciones {
    instalarAplicacion(app) { throw new Error("Metodo 'instalarAplicacion' debe ser implementado."); }
    abrirAplicacion(app) { throw new Error("Metodo 'abrirAplicacion' debe ser implementado."); }
}

class IEnergia {
    cargarBateria() { throw new Error("Metodo 'cargarBateria' debe ser implementado."); }
    verificarNivel() { throw new Error("Metodo 'verificarNivel' debe ser implementado."); }
}

class ISeguridad {
    configurarBloqueo(codigo) { throw new Error("Metodo 'configurarBloqueo' debe ser implementado."); }
    desbloquear(codigo) { throw new Error("Metodo 'desbloquear' debe ser implementado."); }
}

// =================================================================
// 2. CLASES ABSTRACTAS (Simulación con new.target)
// =================================================================

// Clase Base 1: DispositivoBase
class DispositivoBase {
    constructor(id, marca, modelo) {
        if (new.target === DispositivoBase) {
            throw new Error("No se puede instanciar la clase abstracta DispositivoBase.");
        }
        this.idDispositivo = id;
        this.marca = marca;
        this.modelo = modelo;
    }

    mostrarInfo() {
        throw new Error("Metodo abstracto 'mostrarInfo' debe ser implementado.");
    }
}

// Clase Base 2: ComponenteHardware
class ComponenteHardware {
    constructor(serial) {
        if (new.target === ComponenteHardware) {
            throw new Error("No se puede instanciar la clase abstracta ComponenteHardware.");
        }
        this.serial = serial;
    }

    diagnosticar() {
        throw new Error("Metodo abstracto 'diagnosticar' debe ser implementado.");
    }
}

// Clase Base 3: SoftwareBase
class SoftwareBase {
    constructor(version) {
        if (new.target === SoftwareBase) {
            throw new Error("No se puede instanciar la clase abstracta SoftwareBase.");
        }
        this.version = version;
    }

    actualizar() {
        throw new Error("Metodo abstracto 'actualizar' debe ser implementado.");
    }
}

// Clase Base 4: RedBase
class RedBase {
    constructor(protocolo) {
        if (new.target === RedBase) {
            throw new Error("No se puede instanciar la clase abstracta RedBase.");
        }
        this.protocolo = protocolo;
    }

    escanearRedes() {
        throw new Error("Metodo abstracto 'escanearRedes' debe ser implementado.");
    }
}

// Clase Base 5: ModuloSeguridadBase
class ModuloSeguridadBase {
    constructor(tipo) {
        if (new.target === ModuloSeguridadBase) {
            throw new Error("No se puede instanciar la clase abstracta ModuloSeguridadBase.");
        }
        this.tipo = tipo;
    }

    validarAcceso() {
        throw new Error("Metodo abstracto 'validarAcceso' debe ser implementado.");
    }
}

// =================================================================
// 3. CLASES NORMALES (Implementación y 4 "Constructores")
// =================================================================

// CLASE 1: ControlCelular (Refactorización de tu código)
class ControlCelular extends DispositivoBase {
    // Propiedades públicas
    sistemaOperativo;
    almacenamiento;
    encendido;

    // Propiedades privadas
    #nivelBateria;
    #conectadoWifi;
    #codigoDesbloqueo;
    #registroBinario;
    #configuracionJSON;

    // Propiedades protegidas
    _versionSoftware;
    _fechaUltimaCarga;
    _modoOscuro;
    _temperatura;
    _listaAplicaciones;

    // --- CONSTRUCTOR ÚNICO ---
    constructor(id, marca, modelo, sistemaOperativo, almacenamiento, encendido) {
        super(id, marca, modelo);
        this.sistemaOperativo = sistemaOperativo;
        this.almacenamiento = almacenamiento;
        this.encendido = encendido;

        // Inicialización
        this.#nivelBateria = 100;
        this.#conectadoWifi = false;
        this.#codigoDesbloqueo = "0000";
        this.#registroBinario = null;
        this.#configuracionJSON = {};
        
        this._versionSoftware = "1.0.0";
        this._fechaUltimaCarga = null;
        this._modoOscuro = false;
        this._temperatura = 25.0;
        this._listaAplicaciones = ["Telefono", "Mensajes", "Camara", "Galeria"];
    }

    // --- 4 FACTORY METHODS (Constructores) ---

    // 1. Factory Default
    static createDefault() {
        return new ControlCelular("GEN-000", "Generico", "Base", "Android", 64, false);
    }

    // 2. Factory Simple
    static createSimple(marca, modelo) {
        return new ControlCelular(`DEV-${Date.now()}`, marca, modelo, "Android", 128, false);
    }

    // 3. Factory Full
    static createFull(marca, modelo, sistema, almacenamiento, encendido) {
        return new ControlCelular(`DEV-${Date.now()}`, marca, modelo, sistema, almacenamiento, encendido);
    }

    // 4. Factory Copia
    static createCopy(otro) {
        const copia = new ControlCelular(
            otro.idDispositivo,
            otro.marca,
            otro.modelo,
            otro.sistemaOperativo,
            otro.almacenamiento,
            otro.encendido
        );
        // Copia de estado interno accesible
        copia._modoOscuro = otro._modoOscuro;
        copia._listaAplicaciones = [...otro._listaAplicaciones];
        return copia;
    }

    // --- Getters y Setters ---
    get nivelBateria() { return this.#nivelBateria; }
    
    set nivelBateria(nivel) {
        if (nivel >= 0 && nivel <= 100) {
            this.#nivelBateria = nivel;
        } else {
            console.warn("Nivel de bateria no valido");
        }
    }

    setConfiguracion(config) { this.#configuracionJSON = config; }

    // --- Implementación de Interfaces ---

    encender() {
        if (this.encendido) {
            console.log("El celular ya esta encendido.");
            return;
        }
        this.encendido = true;
        console.log(`Celular ${this.marca} ${this.modelo} ha sido encendido.`);
    }

    apagar() {
        if (!this.encendido) {
            console.log("El celular ya esta apagado.");
            return;
        }
        this.encendido = false;
        console.log("El celular se ha apagado correctamente.");
    }

    cargarBateria() {
        this._fechaUltimaCarga = new Date();
        this.#nivelBateria = 100;
        console.log(`Bateria cargada al 100%. Ultima carga: ${this._fechaUltimaCarga.toLocaleString()}`);
    }

    conectarWifi(red) {
        this.#conectadoWifi = true;
        console.log(`Conectado a la red Wi-Fi "${red}" correctamente.`);
    }

    abrirAplicacion(app) {
        if (!this.encendido) {
            console.log("No puedes abrir aplicaciones con el celular apagado.");
            return;
        }

        if (this._listaAplicaciones.includes(app)) {
            console.log(`Abriendo la aplicacion: ${app}...`);
            if (this.#nivelBateria > 3) {
                this.#nivelBateria -= 3;
            } else {
                console.log("Bateria baja, conecte el cargador.");
            }
        } else {
            console.log(`La aplicacion "${app}" no esta instalada.`);
        }
    }

    mostrarInfo() {
        console.log("\n----- Estado del Celular -----");
        console.log(`Marca: ${this.marca}`);
        console.log(`Modelo: ${this.modelo}`);
        console.log(`SO: ${this.sistemaOperativo}`);
        console.log(`Encendido: ${this.encendido}`);
        console.log(`Bateria: ${this.#nivelBateria}%`);
        console.log(`Modo oscuro: ${this._modoOscuro ? "Activado" : "Desactivado"}`);
        console.log(`Aplicaciones: ${this._listaAplicaciones.join(", ")}`);
    }
}

// CLASE 2: BateriaInteligente
class BateriaInteligente extends ComponenteHardware {
    constructor(serial, capacidadMah) {
        super(serial);
        this.capacidadMah = capacidadMah;
        this.salud = 100;
    }

    // Factories
    static createFull(serial, capacidad) { return new BateriaInteligente(serial, capacidad); }
    static createSimple(capacidad) { return new BateriaInteligente("BAT-UNK", capacidad); }
    static createDefault() { return new BateriaInteligente("BAT-GEN", 4000); }
    static createCopy(otra) { return new BateriaInteligente(otra.serial, otra.capacidadMah); }

    diagnosticar() {
        console.log(`Diagnostico de bateria: Salud ${this.salud}%, Capacidad ${this.capacidadMah}mAh.`);
    }

    verificarNivel(nivelActual) {
        console.log(`Nivel fisico actual: ${nivelActual}%`);
    }
}

// CLASE 3: SistemaOperativoMovil
class SistemaOperativoMovil extends SoftwareBase {
    constructor(version, nombre, parcheSeguridad) {
        super(version);
        this.nombre = nombre;
        this.parcheSeguridad = parcheSeguridad;
    }

    // Factories
    static createFull(ver, nom, parche) { return new SistemaOperativoMovil(ver, nom, parche); }
    static createSimple(ver, nom) { return new SistemaOperativoMovil(ver, nom, "2024-01"); }
    static createDefault() { return new SistemaOperativoMovil("1.0", "BaseOS", "None"); }
    static createCopy(otro) { return new SistemaOperativoMovil(otro.version, otro.nombre, otro.parcheSeguridad); }

    actualizar() {
        console.log(`Buscando actualizaciones para ${this.nombre} version ${this.version}...`);
    }

    instalarParche(nuevoParche) {
        this.parcheSeguridad = nuevoParche;
        console.log(`Parche de seguridad actualizado a: ${nuevoParche}`);
    }
}

// CLASE 4: ModuloWifi
class ModuloWifi extends RedBase {
    constructor(protocolo, banda) {
        super(protocolo);
        this.banda = banda;
        this.activo = false;
    }

    // Factories
    static createFull(proto, banda) { return new ModuloWifi(proto, banda); }
    static createSimple(banda) { return new ModuloWifi("802.11ax", banda); }
    static createDefault() { return new ModuloWifi("802.11n", "2.4GHz"); }
    static createCopy(otro) { return new ModuloWifi(otro.protocolo, otro.banda); }

    escanearRedes() {
        if (!this.activo) {
            console.log("El modulo WiFi esta desactivado.");
            return;
        }
        console.log(`Escaneando redes en banda ${this.banda} usando protocolo ${this.protocolo}...`);
    }

    activar() { this.activo = true; console.log("Modulo WiFi activado."); }
}

// CLASE 5: BloqueoBiometrico
class BloqueoBiometrico extends ModuloSeguridadBase {
    constructor(tipo, nivelSeguridad) {
        super(tipo);
        this.nivelSeguridad = nivelSeguridad;
    }

    // Factories
    static createFull(tipo, nivel) { return new BloqueoBiometrico(tipo, nivel); }
    static createSimple(tipo) { return new BloqueoBiometrico(tipo, "Alto"); }
    static createDefault() { return new BloqueoBiometrico("Huella", "Medio"); }
    static createCopy(otro) { return new BloqueoBiometrico(otro.tipo, otro.nivelSeguridad); }

    validarAcceso() {
        console.log(`Validando acceso mediante ${this.tipo}... Acceso concedido.`);
    }

    configurar(nuevoDato) {
        console.log(`Configurando nuevo dato biometrico para ${this.tipo}.`);
    }
}

// =================================================================
// FUNCIÓN PRINCIPAL (Ejecución)
// =================================================================

function main() {
    console.log("=== SISTEMA DE CELULAR EN JS ===");

    console.log("\n--- 1. PRUEBA CONTROL CELULAR ---");
    
    // 1. Constructor Full (via Factory)
    const miCelular = ControlCelular.createFull("Samsung", "Galaxy S24", "Android", 256, false);
    
    // Configuración
    miCelular.setConfiguracion({ idioma: "Espanol", brillo: 70 });

    // Flujo de uso
    miCelular.encender();
    miCelular.conectarWifi("RedCasa_5G");
    miCelular.abrirAplicacion("Camara");
    miCelular.mostrarInfo();
    miCelular.cargarBateria();
    
    console.log("\n--- Prueba Constructor Copia ---");
    const celularClon = ControlCelular.createCopy(miCelular);
    celularClon.apagar(); // El clon se apaga
    console.log(`Original Encendido: ${miCelular.encendido}`);
    console.log(`Copia Encendida: ${celularClon.encendido}`);

    console.log("\n--- 2. PRUEBA BATERIA INTELIGENTE ---");
    const bateria = BateriaInteligente.createFull("SN-9988", 5000);
    bateria.diagnosticar();

    console.log("\n--- 3. PRUEBA SISTEMA OPERATIVO ---");
    const os = SistemaOperativoMovil.createSimple("14.0", "Android");
    os.actualizar();
    os.instalarParche("2024-05");

    console.log("\n--- 4. PRUEBA MODULO WIFI ---");
    const wifi = ModuloWifi.createSimple("5GHz");
    wifi.activar();
    wifi.escanearRedes();

    console.log("\n--- 5. PRUEBA BIOMETRIA ---");
    const faceId = BloqueoBiometrico.createFull("Reconocimiento Facial", "Muy Alto");
    faceId.configurar();
    faceId.validarAcceso();
}

// Ejecutar Main
main();