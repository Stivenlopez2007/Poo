// =================================================================
// 1. INTERFACES (Simulación de Contratos)
// =================================================================

class IFuncionamiento {
    encender() { throw new Error("Metodo 'encender' debe ser implementado."); }
    apagar() { throw new Error("Metodo 'apagar' debe ser implementado."); }
}

class IPreparacion {
    prepararBebida(cantidad) { throw new Error("Metodo 'prepararBebida' debe ser implementado."); }
    cancelarPreparacion() { throw new Error("Metodo 'cancelarPreparacion' debe ser implementado."); }
}

class IMantenimiento {
    limpiar() { throw new Error("Metodo 'limpiar' debe ser implementado."); }
    descalcificar() { throw new Error("Metodo 'descalcificar' debe ser implementado."); }
}

class IConfiguracion {
    ajustarIntensidad(intensidad) { throw new Error("Metodo 'ajustarIntensidad' debe ser implementado."); }
    guardarPerfil() { throw new Error("Metodo 'guardarPerfil' debe ser implementado."); }
}

class IConectividad {
    conectarWifi() { throw new Error("Metodo 'conectarWifi' debe ser implementado."); }
    enviarNotificacion(mensaje) { throw new Error("Metodo 'enviarNotificacion' debe ser implementado."); }
}

// =================================================================
// 2. CLASES ABSTRACTAS (Simulación con new.target)
// =================================================================

// Clase Base 1: ElectrodomesticoBase
class ElectrodomesticoBase {
    constructor(id, marca, modelo) {
        if (new.target === ElectrodomesticoBase) {
            throw new Error("No se puede instanciar la clase abstracta ElectrodomesticoBase.");
        }
        this.idDispositivo = id;
        this.marca = marca;
        this.modelo = modelo;
    }

    mostrarFicha() {
        throw new Error("Metodo abstracto 'mostrarFicha' debe ser implementado.");
    }
}

// Clase Base 2: RecipienteBase
class RecipienteBase {
    constructor(capacidadMaxima, nivelActual = 0) {
        if (new.target === RecipienteBase) {
            throw new Error("No se puede instanciar la clase abstracta RecipienteBase.");
        }
        this.capacidadMaxima = capacidadMaxima;
        this.nivelActual = nivelActual;
    }

    llenar(cantidad) {
        throw new Error("Metodo abstracto 'llenar' debe ser implementado.");
    }
}

// Clase Base 3: ElementoCalefactorBase
class ElementoCalefactorBase {
    constructor(temperaturaObjetivo) {
        if (new.target === ElementoCalefactorBase) {
            throw new Error("No se puede instanciar la clase abstracta ElementoCalefactorBase.");
        }
        this.temperaturaObjetivo = temperaturaObjetivo;
    }

    calentar() {
        throw new Error("Metodo abstracto 'calentar' debe ser implementado.");
    }
}

// Clase Base 4: InterfazUsuarioBase
class InterfazUsuarioBase {
    constructor(tipoPantalla) {
        if (new.target === InterfazUsuarioBase) {
            throw new Error("No se puede instanciar la clase abstracta InterfazUsuarioBase.");
        }
        this.tipoPantalla = tipoPantalla;
    }

    mostrarMensaje(msg) {
        throw new Error("Metodo abstracto 'mostrarMensaje' debe ser implementado.");
    }
}

// Clase Base 5: AccesorioBase
class AccesorioBase {
    constructor(material) {
        if (new.target === AccesorioBase) {
            throw new Error("No se puede instanciar la clase abstracta AccesorioBase.");
        }
        this.material = material;
    }

    verificarEstado() {
        throw new Error("Metodo abstracto 'verificarEstado' debe ser implementado.");
    }
}

// =================================================================
// 3. CLASES NORMALES (Implementación y 4 "Constructores")
// =================================================================

// CLASE 1: ControlCafetera
class ControlCafetera extends ElectrodomesticoBase {
    // Propiedades públicas
    capacidad;
    material;
    encendida;

    // Propiedades privadas (Sintaxis # de ES2022)
    #nivelAgua = 0;
    #nivelCafe = 0;
    #temperatura = 20;
    #preparando = false;
    #configuracion = {};

    // Propiedades protegidas (simuladas con _)
    _tipoMolienda = "Media";
    _intensidadCafe = "Normal";
    _tazasPreparadas = 0;
    _ultimoUso = null;
    _recetasGuardadas = [];

    // --- CONSTRUCTOR ÚNICO (La lógica principal) ---
    constructor(id, marca, modelo, capacidad, material, encendida) {
        super(id, marca, modelo);
        this.capacidad = capacidad;
        this.material = material;
        this.encendida = encendida;
        this.#configuracion = { idioma: "Español", ahorro: true };
    }

    // --- 4 "CONSTRUCTORES" (Static Factory Methods) ---

    // 1. Factory Default
    static createDefault() {
        return new ControlCafetera("GENERICO", "Generica", "Base", 1000, "Plastico", false);
    }

    // 2. Factory Simple
    static createSimple(marca, modelo) {
        return new ControlCafetera(`DEV-${Date.now()}`, marca, modelo, 1000, "Plastico", false);
    }

    // 3. Factory Full (Principal)
    static createFull(marca, modelo, capacidad, material, encendida) {
        return new ControlCafetera(`DEV-${Date.now()}`, marca, modelo, capacidad, material, encendida);
    }

    // 4. Factory Copia
    static createCopy(otra) {
        const copia = new ControlCafetera(
            otra.idDispositivo,
            otra.marca,
            otra.modelo,
            otra.capacidad,
            otra.material,
            otra.encendida
        );
        // Copiamos estado interno relevante
        copia._intensidadCafe = otra._intensidadCafe;
        return copia;
    }

    // --- Getters y Setters ---
    get nivelAgua() { return this.#nivelAgua; }
    get nivelCafe() { return this.#nivelCafe; }
    
    setConfiguracion(config) { this.#configuracion = config; }

    // --- Métodos de Lógica ---

    llenarAgua(cantidad) {
        if (this.#nivelAgua + cantidad > this.capacidad) {
            console.log(`Capacidad maxima excedida (${this.capacidad}ml)`);
            return;
        }
        this.#nivelAgua += cantidad;
        console.log(`Agua agregada. Nivel actual: ${this.#nivelAgua}ml`);
    }

    agregarCafe(gramos) {
        this.#nivelCafe += gramos;
        console.log(`Cafe agregado: ${gramos}g. Total: ${this.#nivelCafe}g`);
    }

    ajustarIntensidad(intensidad) {
        const niveles = ["Suave", "Normal", "Fuerte"];
        if (!niveles.includes(intensidad)) {
            console.log("Intensidad invalida.");
            return;
        }
        this._intensidadCafe = intensidad;
        console.log(`Intensidad ajustada a: ${intensidad}`);
    }

    guardarReceta(nombre) {
        this._recetasGuardadas.push({ nombre, intensidad: this._intensidadCafe });
        console.log(`Receta '${nombre}' guardada.`);
    }

    // --- Implementación de Interfaces (Métodos) ---

    encender() {
        if (this.encendida) {
            console.log("La cafetera ya esta encendida.");
            return;
        }
        this.encendida = true;
        console.log(`Cafetera ${this.marca} ${this.modelo} encendida.`);
    }

    apagar() {
        if (this.#preparando) {
            console.log("No puedes apagar mientras prepara cafe.");
            return;
        }
        this.encendida = false;
        console.log("Cafetera apagada.");
    }

    prepararBebida(tazas) {
        if (!this.encendida) {
            console.log("Enciende la cafetera primero.");
            return;
        }
        const aguaNec = tazas * 150;
        const cafeNec = tazas * 10;

        if (this.#nivelAgua < aguaNec || this.#nivelCafe < cafeNec) {
            console.log("Insuficientes ingredientes.");
            return;
        }

        this.#preparando = true;
        console.log(`Preparando ${tazas} taza(s)...`);

        // Simulación
        this.#temperatura = 85;
        this.#nivelAgua -= aguaNec;
        this.#nivelCafe -= cafeNec;
        this._tazasPreparadas += tazas;
        this._ultimoUso = new Date();
        
        // Usamos setTimeout para simular asincronía
        setTimeout(() => {
            this.#preparando = false;
            console.log("Cafe listo. Disfruta tu bebida.");
        }, 1000);
    }

    cancelarPreparacion() {
        if (this.#preparando) {
            this.#preparando = false;
            console.log("Preparacion cancelada.");
        }
    }

    limpiar() {
        if (this.encendida) {
            console.log("Apaga antes de limpiar.");
            return;
        }
        this.#nivelAgua = 0;
        this.#nivelCafe = 0;
        this.#temperatura = 20;
        console.log("Cafetera limpiada correctamente.");
    }

    mostrarFicha() {
        console.log("\n----- Estado de la Cafetera -----");
        console.log(`Marca: ${this.marca} | Modelo: ${this.modelo}`);
        console.log(`Encendida: ${this.encendida ? "Si" : "No"}`);
        console.log(`Nivel Agua: ${this.#nivelAgua}ml | Cafe: ${this.#nivelCafe}g`);
        console.log(`Intensidad: ${this._intensidadCafe}`);
        console.log(`Tazas servidas: ${this._tazasPreparadas}`);
    }
}

// CLASE 2: TanqueAgua
class TanqueAgua extends RecipienteBase {
    constructor(max, actual, filtro) {
        super(max, actual);
        this.filtroLimpio = filtro;
    }

    // 4 "Constructores"
    static createFull(max, actual, filtro) { return new TanqueAgua(max, actual, filtro); }
    static createSimple(max) { return new TanqueAgua(max, 0, true); }
    static createDefault() { return new TanqueAgua(2000, 0, true); }
    static createCopy(otro) { return new TanqueAgua(otro.capacidadMaxima, otro.nivelActual, otro.filtroLimpio); }

    // Implementación
    llenar(cantidad) {
        if (this.nivelActual + cantidad <= this.capacidadMaxima) {
            this.nivelActual += cantidad;
            console.log(`Tanque llenado. Nivel: ${this.nivelActual}`);
        } else {
            console.log("Desbordamiento evitado.");
        }
    }

    limpiar() { console.log("Tanque enjuagado."); }
    descalcificar() { console.log("Descalcificacion completa."); }
}

// CLASE 3: Calentador
class Calentador extends ElementoCalefactorBase {
    constructor(temp, watts) {
        super(temp);
        this.potenciaWatts = watts;
    }

    // 4 "Constructores"
    static createFull(temp, watts) { return new Calentador(temp, watts); }
    static createSimple(watts) { return new Calentador(95.0, watts); }
    static createDefault() { return new Calentador(90.0, 1000); }
    static createCopy(otro) { return new Calentador(otro.temperaturaObjetivo, otro.potenciaWatts); }

    calentar() {
        console.log(`Calentando agua a ${this.temperaturaObjetivo}C con ${this.potenciaWatts}W.`);
    }
}

// CLASE 4: MolinoCafe
class MolinoCafe extends AccesorioBase {
    constructor(material, niveles, ajuste) {
        super(material);
        this.nivelesMolienda = niveles;
        this.ajusteActual = ajuste;
    }

    // 4 "Constructores"
    static createFull(mat, niveles, ajuste) { return new MolinoCafe(mat, niveles, ajuste); }
    static createSimple(niveles) { return new MolinoCafe("Ceramica", niveles, "Medio"); }
    static createDefault() { return new MolinoCafe("Acero", 5, "Medio"); }
    static createCopy(otro) { return new MolinoCafe(otro.material, otro.nivelesMolienda, otro.ajusteActual); }

    verificarEstado() {
        console.log(`Molino de ${this.material} listo. Ajuste: ${this.ajusteActual}`);
    }

    ajustarIntensidad(nivel) {
        this.ajusteActual = nivel;
        console.log(`Molienda ajustada a: ${nivel}`);
    }
}

// CLASE 5: PantallaTactil
class PantallaTactil extends InterfazUsuarioBase {
    constructor(tipo, wifi) {
        super(tipo);
        this.wifiActivo = wifi;
    }

    // 4 "Constructores"
    static createFull(tipo, wifi) { return new PantallaTactil(tipo, wifi); }
    static createSimple(tipo) { return new PantallaTactil(tipo, true); }
    static createDefault() { return new PantallaTactil("LED", false); }
    static createCopy(otro) { return new PantallaTactil(otro.tipoPantalla, otro.wifiActivo); }

    mostrarMensaje(msg) {
        console.log(`[PANTALLA ${this.tipoPantalla}]: ${msg}`);
    }

    conectarWifi() {
        this.wifiActivo = true;
        console.log("Conectado a WiFi.");
    }

    enviarNotificacion(mensaje) {
        if (this.wifiActivo) console.log(`Notificacion enviada: ${mensaje}`);
    }
}

// =================================================================
// FUNCIÓN PRINCIPAL (Ejecución)
// =================================================================

function main() {
    console.log("=== SISTEMA DE CAFETERA INTELIGENTE EN JS ===");

    console.log("\n--- 1. PRUEBA CONTROL CAFETERA ---");
    
    // 1. Constructor Full (via Factory)
    const miCafetera = ControlCafetera.createFull("Nespresso", "Essenza Mini", 1000, "Acero", false);
    
    // Configuración
    miCafetera.setConfiguracion({ idioma: "Espanol", ahorro: true });

    // Flujo de uso
    miCafetera.encender();
    miCafetera.llenarAgua(500);
    miCafetera.agregarCafe(50);
    miCafetera.ajustarIntensidad("Fuerte");
    miCafetera.guardarReceta("Cafe Matutino");
    miCafetera.mostrarFicha();
    
    // Simulamos preparación
    miCafetera.prepararBebida(2);

    console.log("\n--- Prueba Constructor Copia ---");
    const cafeteraClon = ControlCafetera.createCopy(miCafetera);
    cafeteraClon.apagar(); // El clon se apaga
    console.log(`Original Encendida: ${miCafetera.encendida}`);
    console.log(`Copia Encendida: ${cafeteraClon.encendida}`);

    console.log("\n--- 2. PRUEBA TANQUE AGUA ---");
    const tanque = TanqueAgua.createDefault();
    tanque.llenar(1500);
    tanque.descalcificar();

    console.log("\n--- 3. PRUEBA CALENTADOR ---");
    const boiler = Calentador.createSimple(1200);
    boiler.calentar();

    console.log("\n--- 4. PRUEBA MOLINO ---");
    const molino = MolinoCafe.createFull("Acero Inoxidable", 10, "Fino");
    molino.verificarEstado();
    molino.ajustarIntensidad("Extra Fino");

    console.log("\n--- 5. PRUEBA PANTALLA ---");
    const lcd = PantallaTactil.createFull("LCD 5 Pulgadas", false);
    lcd.conectarWifi();
    lcd.mostrarMensaje("Bienvenido");
    lcd.enviarNotificacion("Tu cafe esta listo");
}

// Ejecutar Main
main();