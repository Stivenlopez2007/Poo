// =================================================================
// 1. INTERFACES (Simulación de Contratos)
// =================================================================

class IFuncionamiento {
    encender() { throw new Error("Metodo 'encender' debe ser implementado."); }
    apagar() { throw new Error("Metodo 'apagar' debe ser implementado."); }
}

class IIluminacion {
    ajustarIntensidad(valor) { throw new Error("Metodo 'ajustarIntensidad' debe ser implementado."); }
    cambiarTemperaturaColor(kelvin) { throw new Error("Metodo 'cambiarTemperaturaColor' debe ser implementado."); }
}

class IConsumo {
    activarModoAhorro() { throw new Error("Metodo 'activarModoAhorro' debe ser implementado."); }
    registrarHorasUso(horas) { throw new Error("Metodo 'registrarHorasUso' debe ser implementado."); }
}

class IConfiguracion {
    guardarEstado() { throw new Error("Metodo 'guardarEstado' debe ser implementado."); }
    restaurarFabrica() { throw new Error("Metodo 'restaurarFabrica' debe ser implementado."); }
}

class IConectividad {
    conectarRed() { throw new Error("Metodo 'conectarRed' debe ser implementado."); }
    verificarEstadoRed() { throw new Error("Metodo 'verificarEstadoRed' debe ser implementado."); }
}

// =================================================================
// 2. CLASES ABSTRACTAS (Simulación con new.target)
// =================================================================

// Clase Base 1: DispositivoBase
class DispositivoBase {
    constructor(id, marca, ubicacion) {
        if (new.target === DispositivoBase) {
            throw new Error("No se puede instanciar la clase abstracta DispositivoBase.");
        }
        this.idDispositivo = id;
        this.marca = marca;
        this.ubicacion = ubicacion;
    }

    mostrarEstado() {
        throw new Error("Metodo abstracto 'mostrarEstado' debe ser implementado.");
    }
}

// Clase Base 2: FuenteLuzBase
class FuenteLuzBase {
    constructor(tecnologia, vidaUtilHoras) {
        if (new.target === FuenteLuzBase) {
            throw new Error("No se puede instanciar la clase abstracta FuenteLuzBase.");
        }
        this.tecnologia = tecnologia;
        this.vidaUtilHoras = vidaUtilHoras;
    }

    emitirLuz() {
        throw new Error("Metodo abstracto 'emitirLuz' debe ser implementado.");
    }
}

// Clase Base 3: ControladorBase
class ControladorBase {
    constructor(tipoControl) {
        if (new.target === ControladorBase) {
            throw new Error("No se puede instanciar la clase abstracta ControladorBase.");
        }
        this.tipoControl = tipoControl;
    }

    ejecutarComando(cmd) {
        throw new Error("Metodo abstracto 'ejecutarComando' debe ser implementado.");
    }
}

// Clase Base 4: SensorBase
class SensorBase {
    constructor(tipoSensor, rango) {
        if (new.target === SensorBase) {
            throw new Error("No se puede instanciar la clase abstracta SensorBase.");
        }
        this.tipoSensor = tipoSensor;
        this.rango = rango;
    }

    leerDatos() {
        throw new Error("Metodo abstracto 'leerDatos' debe ser implementado.");
    }
}

// Clase Base 5: ConexionBase
class ConexionBase {
    constructor(protocolo) {
        if (new.target === ConexionBase) {
            throw new Error("No se puede instanciar la clase abstracta ConexionBase.");
        }
        this.protocolo = protocolo;
    }

    establecerEnlace() {
        throw new Error("Metodo abstracto 'establecerEnlace' debe ser implementado.");
    }
}

// =================================================================
// 3. CLASES NORMALES (Implementación y 4 "Constructores")
// =================================================================

// CLASE 1: ControlLampara (Refactorización de tu código original)
class ControlLampara extends DispositivoBase {
    // Propiedades públicas
    color;
    tipo;
    encendida;

    // Propiedades privadas (Sintaxis # de ES2022)
    #intensidad = 50;
    #horasUso = 0;
    #temperaturaColor = 4000;
    #consumoWatts = 10;
    #configuracion = null;

    // Propiedades protegidas (simuladas con _)
    _vidaUtil = 10000;
    _fechaInstalacion = null;
    _modoAhorro = false;
    _tempActual = 25;
    _estadosGuardados = [];

    // --- CONSTRUCTOR ÚNICO ---
    constructor(id, marca, color, tipo, ubicacion, encendida) {
        super(id, marca, ubicacion);
        this.color = color;
        this.tipo = tipo;
        this.encendida = encendida;
        this._fechaInstalacion = new Date();
    }

    // --- 4 FACTORY METHODS (Constructores) ---

    // 1. Factory Default
    static createDefault() {
        return new ControlLampara("GEN-000", "Generica", "Blanco", "LED", "Sin Ubicacion", false);
    }

    // 2. Factory Simple
    static createSimple(marca, ubicacion) {
        return new ControlLampara(`LMP-${Date.now()}`, marca, "Blanco", "LED", ubicacion, false);
    }

    // 3. Factory Full
    static createFull(marca, color, tipo, ubicacion, encendida) {
        return new ControlLampara(`LMP-${Date.now()}`, marca, color, tipo, ubicacion, encendida);
    }

    // 4. Factory Copia
    static createCopy(otra) {
        const copia = new ControlLampara(
            otra.idDispositivo,
            otra.marca,
            otra.color,
            otra.tipo,
            otra.ubicacion,
            otra.encendida
        );
        // Copiamos estado interno accesible
        copia._vidaUtil = otra._vidaUtil;
        copia._modoAhorro = otra._modoAhorro;
        copia._fechaInstalacion = otra._fechaInstalacion;
        // Nota: Los campos privados (#) no se pueden copiar desde fuera directamente
        return copia;
    }

    // --- Getters y Setters ---
    get intensidad() { return this.#intensidad; }
    
    set intensidad(valor) {
        if (valor < 0 || valor > 100) {
            console.warn("La intensidad debe estar entre 0 y 100");
            return;
        }
        this.#intensidad = valor;
    }

    setConfiguracion(config) { this.#configuracion = config; }

    // --- Implementación de Interfaces ---

    encender() {
        if (this.encendida) {
            console.log("La lampara ya esta encendida.");
            return;
        }
        this.encendida = true;
        console.log(`Lampara ${this.marca} encendida en ${this.ubicacion}.`);
    }

    apagar() {
        if (!this.encendida) {
            console.log("La lampara ya esta apagada.");
            return;
        }
        this.encendida = false;
        console.log("Lampara apagada.");
    }

    ajustarIntensidad(valor) {
        if (!this.encendida) {
            console.log("Enciende la lampara primero.");
            return;
        }
        this.intensidad = valor;
        console.log(`Intensidad ajustada a ${this.#intensidad}%.`);
    }

    cambiarTemperaturaColor(kelvin) {
        if (kelvin < 2700 || kelvin > 6500) {
            console.log("Temperatura debe estar entre 2700K y 6500K");
            return;
        }
        this.#temperaturaColor = kelvin;
        const tipo = kelvin < 3500 ? "calida" : kelvin > 5000 ? "fria" : "neutra";
        console.log(`Luz ${tipo} (${kelvin}K).`);
    }

    activarModoAhorro() {
        this._modoAhorro = true;
        this.#intensidad = 30;
        this.#consumoWatts = 5;
        console.log("Modo ahorro activado.");
    }

    guardarEstado() {
        const estado = {
            intensidad: this.#intensidad,
            temperatura: this.#temperaturaColor,
            fecha: new Date()
        };
        this._estadosGuardados.push(estado);
        console.log("Estado guardado correctamente.");
    }

    registrarHorasUso(horas) {
        this.#horasUso += horas;
        const vidaRestante = this._vidaUtil - this.#horasUso;
        console.log(`${horas}h registradas. Vida restante: ${vidaRestante}h`);
    }

    mostrarEstado() {
        console.log("\n----- Estado de la Lampara -----");
        console.log(`Marca: ${this.marca}`);
        console.log(`Color: ${this.color}`);
        console.log(`Tipo: ${this.tipo}`);
        console.log(`Ubicacion: ${this.ubicacion}`);
        console.log(`Encendida: ${this.encendida ? "Si" : "No"}`);
        console.log(`Intensidad: ${this.#intensidad}%`);
        console.log(`Temperatura: ${this.#temperaturaColor}K`);
        console.log(`Consumo: ${this.#consumoWatts}W`);
        console.log(`Horas de uso: ${this.#horasUso}h`);
        console.log(`Modo ahorro: ${this._modoAhorro ? "Activado" : "Desactivado"}`);
    }
}

// CLASE 2: BombillaInteligente
class BombillaInteligente extends FuenteLuzBase {
    constructor(tecnologia, vidaUtil, lumensMax) {
        super(tecnologia, vidaUtil);
        this.lumensMax = lumensMax;
    }

    // Factories
    static createFull(tec, vida, lumens) { return new BombillaInteligente(tec, vida, lumens); }
    static createSimple(lumens) { return new BombillaInteligente("LED", 15000, lumens); }
    static createDefault() { return new BombillaInteligente("LED", 10000, 800); }
    static createCopy(otra) { return new BombillaInteligente(otra.tecnologia, otra.vidaUtilHoras, otra.lumensMax); }

    emitirLuz() {
        console.log(`Emitiendo luz con tecnologia ${this.tecnologia} hasta ${this.lumensMax} lumens.`);
    }

    verificarVidaUtil() {
        console.log(`Vida util restante estimada: ${this.vidaUtilHoras} horas.`);
    }
}

// CLASE 3: DimmerDigital
class DimmerDigital extends ControladorBase {
    constructor(tipoControl, pasos) {
        super(tipoControl);
        this.pasos = pasos;
        this.nivelActual = 0;
    }

    // Factories
    static createFull(tipo, pasos) { return new DimmerDigital(tipo, pasos); }
    static createSimple(pasos) { return new DimmerDigital("Tactil", pasos); }
    static createDefault() { return new DimmerDigital("Rotativo", 100); }
    static createCopy(otro) { return new DimmerDigital(otro.tipoControl, otro.pasos); }

    ejecutarComando(cmd) {
        console.log(`Ejecutando comando '${cmd}' en dimmer ${this.tipoControl}.`);
    }

    subirNivel() {
        if (this.nivelActual < this.pasos) this.nivelActual++;
        console.log(`Nivel dimmer: ${this.nivelActual}/${this.pasos}`);
    }
}

// CLASE 4: SensorMovimiento
class SensorMovimiento extends SensorBase {
    constructor(tipo, rango, sensibilidad) {
        super(tipo, rango);
        this.sensibilidad = sensibilidad;
    }

    // Factories
    static createFull(tipo, rango, sens) { return new SensorMovimiento(tipo, rango, sens); }
    static createSimple(rango) { return new SensorMovimiento("PIR", rango, "Media"); }
    static createDefault() { return new SensorMovimiento("PIR", "5m", "Baja"); }
    static createCopy(otro) { return new SensorMovimiento(otro.tipoSensor, otro.rango, otro.sensibilidad); }

    leerDatos() {
        console.log(`Leyendo sensor ${this.tipoSensor} en rango ${this.rango}.`);
        return "Sin movimiento";
    }

    detectar() {
        console.log("Movimiento detectado. Enviando señal...");
    }
}

// CLASE 5: ModuloWifi
class ModuloWifi extends ConexionBase {
    constructor(protocolo, banda) {
        super(protocolo);
        this.banda = banda;
        this.conectado = false;
    }

    // Factories
    static createFull(proto, banda) { return new ModuloWifi(proto, banda); }
    static createSimple(banda) { return new ModuloWifi("WPA3", banda); }
    static createDefault() { return new ModuloWifi("WPA2", "2.4GHz"); }
    static createCopy(otro) { return new ModuloWifi(otro.protocolo, otro.banda); }

    establecerEnlace() {
        this.conectado = true;
        console.log(`Enlace establecido usando ${this.protocolo} en banda ${this.banda}.`);
    }

    desconectar() {
        this.conectado = false;
        console.log("Modulo desconectado.");
    }
}

// =================================================================
// FUNCIÓN PRINCIPAL (Ejecución)
// =================================================================

function main() {
    console.log("=== SISTEMA DE ILUMINACION INTELIGENTE EN JS ===");

    console.log("\n--- 1. PRUEBA CONTROL LAMPARA ---");
    
    // 1. Constructor Full (via Factory)
    const lamparaSala = ControlLampara.createFull("Philips", "Blanco", "LED", "Sala", false);
    
    // Configuración
    lamparaSala.setConfiguracion({ programacion: "Automatica", sensor: "Movimiento" });

    // Flujo de uso
    lamparaSala.encender();
    lamparaSala.ajustarIntensidad(80);
    lamparaSala.cambiarTemperaturaColor(3000);
    lamparaSala.guardarEstado();
    lamparaSala.activarModoAhorro();
    lamparaSala.registrarHorasUso(5);
    lamparaSala.mostrarEstado();
    
    console.log("\n--- Prueba Constructor Copia ---");
    const lamparaClon = ControlLampara.createCopy(lamparaSala);
    lamparaClon.apagar(); // El clon se apaga
    console.log(`Original Encendida: ${lamparaSala.encendida}`);
    console.log(`Copia Encendida: ${lamparaClon.encendida}`);

    console.log("\n--- 2. PRUEBA BOMBILLA INTELIGENTE ---");
    const bombilla = BombillaInteligente.createSimple(1200);
    bombilla.emitirLuz();
    bombilla.verificarVidaUtil();

    console.log("\n--- 3. PRUEBA DIMMER DIGITAL ---");
    const dimmer = DimmerDigital.createFull("Panel Tactil", 10);
    dimmer.ejecutarComando("Encender Suave");
    dimmer.subirNivel();

    console.log("\n--- 4. PRUEBA SENSOR MOVIMIENTO ---");
    const sensor = SensorMovimiento.createSimple("8m");
    sensor.leerDatos();
    sensor.detectar();

    console.log("\n--- 5. PRUEBA MODULO WIFI ---");
    const wifi = ModuloWifi.createFull("WPA3", "5GHz");
    wifi.establecerEnlace();
    wifi.desconectar();
}

// Ejecutar Main
main();