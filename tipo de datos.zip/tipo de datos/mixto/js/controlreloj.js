c//=================================================================
// 1. INTERFACES (Simulación de Contratos)
// =================================================================

class IRelojeria {
    ajustarHora(h, m) { throw new Error("Metodo 'ajustarHora' debe ser implementado."); }
    mostrarHora() { throw new Error("Metodo 'mostrarHora' debe ser implementado."); }
}

class IAlarma {
    configurarAlarma(h, m) { throw new Error("Metodo 'configurarAlarma' debe ser implementado."); }
    verificarAlarma() { throw new Error("Metodo 'verificarAlarma' debe ser implementado."); }
}

class IFuncionamiento {
    verificarBateria() { throw new Error("Metodo 'verificarBateria' debe ser implementado."); }
    activarFuncionamiento() { throw new Error("Metodo 'activarFuncionamiento' debe ser implementado."); }
}

class ICronometro {
    iniciarCronometro() { throw new Error("Metodo 'iniciarCronometro' debe ser implementado."); }
    detenerCronometro() { throw new Error("Metodo 'detenerCronometro' debe ser implementado."); }
}

class IAspecto {
    activarLuz() { throw new Error("Metodo 'activarLuz' debe ser implementado."); }
    cambiarFormato() { throw new Error("Metodo 'cambiarFormato' debe ser implementado."); }
}

// =================================================================
// 2. CLASES ABSTRACTAS (Simulación con new.target)
// =================================================================

// Clase Base 1: DispositivoBase
class DispositivoBase {
    constructor(id, marca, tipo) {
        if (new.target === DispositivoBase) {
            throw new Error("No se puede instanciar la clase abstracta DispositivoBase.");
        }
        this.idDispositivo = id;
        this.marca = marca;
        this.tipo = tipo;
    }

    mostrarInfo() {
        throw new Error("Metodo abstracto 'mostrarInfo' debe ser implementado.");
    }
}

// Clase Base 2: MecanismoBase
class MecanismoBase {
    constructor(material, color) {
        if (new.target === MecanismoBase) {
            throw new Error("No se puede instanciar la clase abstracta MecanismoBase.");
        }
        this.material = material;
        this.color = color;
    }

    diagnosticar() {
        throw new Error("Metodo abstracto 'diagnosticar' debe ser implementado.");
    }
}

// Clase Base 3: SoftwareRelojBase
class SoftwareRelojBase {
    constructor(version) {
        if (new.target === SoftwareRelojBase) {
            throw new Error("No se puede instanciar la clase abstracta SoftwareRelojBase.");
        }
        this.version = version;
    }

    procesarComando(comando) {
        throw new Error("Metodo abstracto 'procesarComando' debe ser implementado.");
    }
}

// Clase Base 4: PantallaBase
class PantallaBase {
    constructor(tipoPantalla) {
        if (new.target === PantallaBase) {
            throw new Error("No se puede instanciar la clase abstracta PantallaBase.");
        }
        this.tipoPantalla = tipoPantalla;
    }

    mostrarVisual() {
        throw new Error("Metodo abstracto 'mostrarVisual' debe ser implementado.");
    }
}

// Clase Base 5: SensorBase
class SensorBase {
    constructor(tipoSensor) {
        if (new.target === SensorBase) {
            throw new Error("No se puede instanciar la clase abstracta SensorBase.");
        }
        this.tipoSensor = tipoSensor;
    }

    capturarInput() {
        throw new Error("Metodo abstracto 'capturarInput' debe ser implementado.");
    }
}

// =================================================================
// 3. CLASES NORMALES (Implementación y 4 "Constructores")
// =================================================================

// CLASE 1: ControlReloj (Refactorización del código original)
class ControlReloj extends DispositivoBase {
    // Propiedades públicas
    color;
    material;
    funcionando;

    // Propiedades privadas
    #hora = 12;
    #minutos = 0;
    #alarma = null;
    #bateria = 100;
    #configuracion = null;

    // Propiedades protegidas (simuladas con _)
    _formato24h = true;
    _alarmasGuardadas = [];
    _cronometro = 0;
    _luz = false;
    _sonidoAlarma = "Beep";
    #intervaloCronometro = null;

    // --- CONSTRUCTOR ÚNICO ---
    constructor(id, marca, tipo, color, material, funcionando = true) {
        super(id, marca, tipo);
        this.color = color;
        this.material = material;
        this.funcionando = funcionando;
    }

    // --- 4 FACTORY METHODS (Constructores) ---

    // 1. Factory Default
    static createDefault() {
        return new ControlReloj("GEN-000", "Generico", "Digital", "Negro", "Plastico", true);
    }

    // 2. Factory Simple (Marca y Material)
    static createSimple(marca, material) {
        return new ControlReloj(`RLJ-${Date.now()}`, marca, "Analogico", "Dorado", material, true);
    }

    // 3. Factory Full
    static createFull(marca, tipo, color, material) {
        return new ControlReloj(`RLJ-${Date.now()}`, marca, tipo, color, material, true);
    }

    // 4. Factory Copia
    static createCopy(otro) {
        const copia = new ControlReloj(
            otro.idDispositivo,
            otro.marca,
            otro.tipo,
            otro.color,
            otro.material,
            otro.funcionando
        );
        // Copia de estado interno accesible (protegido)
        copia._formato24h = otro._formato24h;
        copia._sonidoAlarma = otro._sonidoAlarma;
        copia._alarmasGuardadas = [...otro._alarmasGuardadas];
        return copia;
    }

    // --- Getters y Setters ---
    get bateria() { return this.#bateria; }
    
    set bateria(nivel) {
        if (nivel < 0 || nivel > 100) {
            console.warn("Bateria debe estar entre 0 y 100");
            return;
        }
        this.#bateria = nivel;
    }

    setConfiguracion(config) { this.#configuracion = config; }

    // --- Implementación de IRelojeria ---
    ajustarHora(hora, minutos) {
        if (hora < 0 || hora > 23 || minutos < 0 || minutos > 59) {
            console.log("Hora o minutos invalidos");
            return;
        }
        this.#hora = hora;
        this.#minutos = minutos;
        console.log(`Hora ajustada: ${this.mostrarHora()}`);
    }

    mostrarHora() {
        const h = this._formato24h ? this.#hora : this.#hora % 12 || 12;
        const m = this.#minutos.toString().padStart(2, '0');
        const periodo = !this._formato24h ? (this.#hora >= 12 ? ' PM' : ' AM') : '';
        return `${h}:${m}${periodo}`;
    }

    // --- Implementación de IAlarma ---
    configurarAlarma(hora, minutos) {
        this.#alarma = { hora, minutos };
        this._alarmasGuardadas.push({ hora, minutos, activa: true });
        console.log(`Alarma configurada para las ${hora}:${minutos.toString().padStart(2, '0')}`);
    }

    verificarAlarma() {
        if (this.#alarma && this.#hora === this.#alarma.hora && this.#minutos === this.#alarma.minutos) {
            console.log(`!!! ALARMA: ${this._sonidoAlarma} !!!`);
            this.#alarma = null; // Desactivar despues de sonar
            return true;
        }
        return false;
    }

    // --- Implementación de IFuncionamiento ---
    verificarBateria() {
        console.log(`Nivel de bateria actual: ${this.#bateria}%`);
        return this.#bateria;
    }

    activarFuncionamiento() {
        if (this.#bateria > 0) {
            this.funcionando = true;
            console.log("Reloj en funcionamiento.");
        } else {
            this.funcionando = false;
            console.log("Bateria agotada. No puede funcionar.");
        }
    }

    // --- Implementación de ICronometro ---
    iniciarCronometro() {
        if (this.#intervaloCronometro) {
            this.detenerCronometro();
        }
        this._cronometro = 0;
        console.log("Cronometro iniciado (simulacion de 10 segundos).");
        
        this.#intervaloCronometro = setInterval(() => {
            this._cronometro++;
            console.log(`... ${this._cronometro}s`);
            if (this._cronometro >= 10) {
                this.detenerCronometro();
                console.log(`Cronometro detenido en ${this._cronometro}s`);
            }
        }, 1000);
    }

    detenerCronometro() {
        if (this.#intervaloCronometro) {
            clearInterval(this.#intervaloCronometro);
            this.#intervaloCronometro = null;
            console.log(`Cronometro en pausa. Tiempo: ${this._cronometro}s`);
        }
    }

    // --- Implementación de IAspecto ---
    activarLuz() {
        this._luz = !this._luz;
        this.#bateria = Math.max(0, this.#bateria - 2);
        console.log(`Luz ${this._luz ? "encendida" : "apagada"}. Bateria: ${this.#bateria}%`);
    }

    cambiarFormato() {
        this._formato24h = !this._formato24h;
        const formato = this._formato24h ? "24 horas" : "12 horas (AM/PM)";
        console.log(`Formato cambiado a: ${formato}`);
    }
    
    // --- Metodo Abstracto Implementado ---
    mostrarInfo() {
        console.log("\n----- Estado del Reloj -----");
        console.log(`Marca: ${this.marca}`);
        console.log(`Tipo: ${this.tipo}`);
        console.log(`Hora actual: ${this.mostrarHora()}`);
        console.log(`Bateria: ${this.#bateria}%`);
        console.log(`Luz: ${this._luz ? "Encendida" : "Apagada"}`);
        console.log(`Alarmas guardadas: ${this._alarmasGuardadas.length}`);
    }
}

// CLASE 2: MecanismoPila
class MecanismoPila extends MecanismoBase {
    constructor(material, color, voltaje) {
        super(material, color);
        this.voltaje = voltaje;
        this.vidaEstimada = "1 año";
    }

    // Factories
    static createFull(mat, col, volt) { return new MecanismoPila(mat, col, volt); }
    static createSimple(volt) { return new MecanismoPila("Plastico", "Gris", volt); }
    static createDefault() { return new MecanismoPila("Metal", "Plata", "1.5V"); }
    static createCopy(otro) { return new MecanismoPila(otro.material, otro.color, otro.voltaje); }

    diagnosticar() {
        console.log(`Diagnostico de Pila: Voltaje ${this.voltaje}. Cambio recomendado en ${this.vidaEstimada}.`);
    }
}

// CLASE 3: ModuloAlarma
class ModuloAlarma extends SoftwareRelojBase {
    constructor(version, melodia) {
        super(version);
        this.melodia = melodia;
        this.activo = false;
    }

    // Factories
    static createFull(ver, melodia) { return new ModuloAlarma(ver, melodia); }
    static createSimple(melodia) { return new ModuloAlarma("1.0.0", melodia); }
    static createDefault() { return new ModuloAlarma("1.0.0", "Beep Estandar"); }
    static createCopy(otro) { return new ModuloAlarma(otro.version, otro.melodia); }

    procesarComando(comando) {
        if (comando === "Silenciar") {
            this.activo = false;
            console.log(`Comando '${comando}' procesado. Alarma silenciada.`);
        }
    }
}

// CLASE 4: DisplayDigital
class DisplayDigital extends PantallaBase {
    constructor(tipoPantalla, colorFondo) {
        super(tipoPantalla);
        this.colorFondo = colorFondo;
    }

    // Factories
    static createFull(tipo, color) { return new DisplayDigital(tipo, color); }
    static createSimple(tipo) { return new DisplayDigital(tipo, "Negro"); }
    static createDefault() { return new DisplayDigital("LCD", "Negro"); }
    static createCopy(otro) { return new DisplayDigital(otro.tipoPantalla, otro.colorFondo); }

    mostrarVisual() {
        console.log(`Renderizando visual en pantalla ${this.tipoPantalla} con fondo ${this.colorFondo}.`);
    }

    cambiarBrillo(nivel) {
        console.log(`Brillo de pantalla ajustado a ${nivel}.`);
    }
}

// CLASE 5: BotoneraControl
class BotoneraControl extends SensorBase {
    constructor(tipoSensor, numBotones) {
        super(tipoSensor);
        this.numBotones = numBotones;
        this.pulsaciones = 0;
    }

    // Factories
    static createFull(tipo, num) { return new BotoneraControl(tipo, num); }
    static createSimple(num) { return new BotoneraControl("Mecanico", num); }
    static createDefault() { return new BotoneraControl("Touch", 4); }
    static createCopy(otro) { return new BotoneraControl(otro.tipoSensor, otro.numBotones); }

    capturarInput() {
        this.pulsaciones++;
        console.log(`Input capturado por ${this.tipoSensor}. Total pulsaciones: ${this.pulsaciones}`);
    }

    simularPresion(boton) {
        console.log(`Boton '${boton}' presionado.`);
        this.capturarInput();
    }
}

// =================================================================
// FUNCIÓN PRINCIPAL (Ejecución)
// =================================================================

function main() {
    console.log("=== SISTEMA DE RELOJ DIGITAL EN JS ===");

    console.log("\n--- 1. PRUEBA CONTROL RELOJ (FACTORY FULL) ---");
    
    const miReloj = ControlReloj.createFull("Casio", "Digital", "Negro", "Plastico");
    
    miReloj.setConfiguracion({ zona: "GMT-5", idioma: "Espanol" });

    miReloj.ajustarHora(14, 30);
    miReloj.configurarAlarma(7, 0);
    miReloj.activarLuz();
    miReloj.cambiarFormato();
    miReloj.mostrarInfo();
    
    // Simulación de cronometro (toma 10s)
    miReloj.iniciarCronometro();

    // Detección de alarma simulada (la hora no coincide, por lo que no sonara)
    miReloj.verificarAlarma();

    // Detener y resetear el cronometro al final (para limpiar el intervalo)
    setTimeout(() => {
        miReloj.detenerCronometro();
        console.log("\n--- 2. PRUEBA MODULOS AUXILIARES ---");

        const pila = MecanismoPila.createSimple("3.0V");
        pila.diagnosticar();

        const alarma = ModuloAlarma.createSimple("Sonido de Ave");
        alarma.procesarComando("Silenciar");

        const display = DisplayDigital.createDefault();
        display.mostrarVisual();
        display.cambiarBrillo(50);
        
        const botonera = BotoneraControl.createFull("Tactil", 6);
        botonera.simularPresion("SET");

    }, 11000); 
}

// Ejecutar Main
main();